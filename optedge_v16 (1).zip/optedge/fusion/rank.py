"""Signal fusion + ranking.

Long-only philosophy:
  - Buy calls when underlying multi-factor view is BULLISH and the call
    is at-or-below fair value
  - Buy puts when underlying multi-factor view is BEARISH and the put
    is at-or-below fair value
  - Buy shares for small caps when multi-factor view is bullish but
    options aren't liquid enough to trade

No selling, no credit spreads, no shorting. Maximum diversity (1 idea/ticker).
"""
from __future__ import annotations
import logging
from typing import Dict, Any, List
import math

import numpy as np
import pandas as pd

from config import (
    SIGNAL_WEIGHTS, TOP_N_CALLS, TOP_N_PUTS, TOP_N_SHARES,
    MAX_PER_TICKER, SHARES_MIN_SCORE,
)
from utils import zscore, winsor, safe_int

log = logging.getLogger("optedge.fusion")


# -------- Helpers ------------------------------------------------------
def _confidence(aligned_score: float) -> int:
    """Map an action-aligned score to 0–100. Positive aligned = high conf."""
    return int(max(0, min(100, 50 + aligned_score * 22)))


def _option_signal_label(side: str, vol_premium: float) -> str:
    if side == "call":
        return "Long Call (cheap)" if vol_premium < 0 else "Long Call (fair)"
    return "Long Put (cheap)" if vol_premium < 0 else "Long Put (fair)"


def _option_reasoning(row: pd.Series) -> str:
    pieces = []
    vp = row.get("vol_premium", 0.0)
    pieces.append(
        f"IV {row['iv_market']*100:.1f}% vs HV30 {row['fair_vol']*100:.1f}% "
        f"({'cheap' if vp < 0 else 'rich'} by {abs(vp)*100:.1f} vol pts)."
    )
    miss_pct = row.get("mispricing_pct", 0.0) * 100
    if abs(miss_pct) > 3:
        pieces.append(f"Market mid is {miss_pct:+.1f}% vs theo (BS @ HV30).")
    iv_rank = row.get("iv_rank")
    if iv_rank is not None and not (isinstance(iv_rank, float) and math.isnan(iv_rank)):
        pieces.append(f"IV-rank proxy {iv_rank:.0f}.")
    skew = row.get("skew_25d")
    if skew is not None and not (isinstance(skew, float) and math.isnan(skew)):
        pieces.append(f"25Δ skew (puts−calls): {skew*100:+.1f} vol pts.")
    s_d = row.get("sentiment_delta", 0.0) or 0.0
    mentions = row.get("mentions", 0) or 0
    if mentions and abs(s_d) > 0.05:
        direction = "rising" if s_d > 0 else "falling"
        pieces.append(f"Reddit Δsentiment {direction} ({s_d:+.2f}, {int(mentions)} mentions).")
    fund = row.get("fund_score")
    if fund is not None and abs(fund) > 0.5:
        cls = row.get("classification", "")
        pieces.append(f"Fundamentals {fund:+.1f} ({cls}).")
    insider = row.get("insider_score", 0) or 0
    if abs(insider) > 0.5:
        n_buys = safe_int(row.get("n_buys"))
        n_sells = safe_int(row.get("n_sells"))
        pieces.append(f"Insider net {insider:+.1f} ({n_buys}P / {n_sells}S, last 90d).")
    # News
    n24 = row.get("n_24h", 0) or 0
    nd = row.get("news_delta", 0) or 0
    if n24 >= 1 and abs(nd) > 0.05:
        direction = "positive" if nd > 0 else "negative"
        pieces.append(f"News: {int(n24)} headlines/24h, sentiment {direction} ({nd:+.2f}).")
    # Earnings catalyst
    dte_e = row.get("days_to_earnings")
    if dte_e is not None and 0 <= dte_e <= 30:
        sup = row.get("last_eps_surprise_pct")
        sup_str = f", last EPS {sup*100:+.1f}%" if sup is not None else ""
        pieces.append(f"Earnings in {int(dte_e)}d{sup_str}.")
    macro_tilt = row.get("macro_tilt", 0.0)
    regime = row.get("regime", "neutral")
    pieces.append(f"Macro: {regime} (tilt {macro_tilt:+.2f}).")
    return " ".join(pieces)


def _option_risks(row: pd.Series) -> str:
    risks = []
    if row.get("spread_pct", 0) > 0.08:
        risks.append(f"Wide spread {row['spread_pct']*100:.1f}%")
    if row.get("dte", 0) <= 21:
        risks.append("Short DTE: theta decay accelerates")
    if row.get("open_interest", 0) < 500:
        risks.append("Low OI: exit liquidity risk")
    earn = row.get("earnings_date")
    if earn:
        risks.append(f"Earnings {earn} — IV crush risk")
    if row.get("regime") == "risk_off" and row["side"] == "call":
        risks.append("Long call against risk-off macro")
    if row.get("regime") == "risk_on" and row["side"] == "put":
        risks.append("Long put against risk-on macro")
    if row.get("vol_premium", 0) > 0:
        risks.append("Buying above fair vol — needs realised vol to rise")
    if not risks:
        risks.append("Standard option drawdown risk")
    return "; ".join(risks)


def _share_reasoning(row: pd.Series) -> str:
    pieces = []
    s_d = row.get("sentiment_delta", 0.0) or 0.0
    mentions = row.get("mentions", 0) or 0
    if mentions and s_d > 0.05:
        pieces.append(f"Reddit Δsentiment rising (+{s_d:.2f}, {safe_int(mentions)} mentions, velocity {safe_int(row.get('velocity')):+d}).")
    fund = row.get("fund_score") or 0
    if fund > 0.3:
        cls = row.get("classification", "")
        pieces.append(f"Fundamentals +{fund:.1f} ({cls}, rev growth {(row.get('rev_growth') or 0)*100:+.0f}%).")
    insider = row.get("insider_score") or 0
    if insider > 0.5:
        n_buys = safe_int(row.get("n_buys"))
        pieces.append(f"Insider net buying +{insider:.1f} ({n_buys} open-market purchases).")
    # News
    n24 = row.get("n_24h", 0) or 0
    nd = row.get("news_delta", 0) or 0
    if n24 >= 1 and nd > 0.05:
        pieces.append(f"News: {int(n24)} headlines/24h, sentiment +{nd:.2f}.")
    # Earnings
    dte_e = row.get("days_to_earnings")
    if dte_e is not None and 0 <= dte_e <= 30:
        pieces.append(f"Earnings in {int(dte_e)}d.")
    pieces.append(f"Macro: {row.get('regime','neutral')} (tilt {row.get('macro_tilt',0):+.2f}).")
    return " ".join(pieces) or "Multi-factor bullish signal."


def _share_risks(row: pd.Series) -> str:
    risks = []
    mcap = row.get("market_cap")
    if mcap and mcap < 1e9:
        risks.append("Sub-$1B mcap: thin liquidity")
    cls = row.get("classification") or ""
    if cls == "distressed":
        risks.append("Distressed financials — binary outcome risk")
    if cls == "speculative":
        risks.append("Speculative classification — narrative-driven")
    earn = row.get("earnings_date")
    if earn:
        risks.append(f"Earnings {earn}")
    if row.get("regime") == "risk_off":
        risks.append("Small-cap long against risk-off macro")
    if not risks:
        risks.append("Standard equity drawdown risk")
    return "; ".join(risks)


# -------- Joining ------------------------------------------------------
def _join_per_ticker(contracts: pd.DataFrame, mp_summary: pd.DataFrame,
                     sentiment: pd.DataFrame, fundamentals: pd.DataFrame,
                     insider: pd.DataFrame, macro: Dict[str, Any],
                     news: pd.DataFrame = None, earnings: pd.DataFrame = None,
                     congress: pd.DataFrame = None,
                     social: pd.DataFrame = None,
                     analyst: pd.DataFrame = None) -> pd.DataFrame:
    """Common merge logic — used by both options and shares tracks."""
    df = contracts.copy() if contracts is not None and not contracts.empty else pd.DataFrame()
    if not df.empty and not mp_summary.empty:
        df = df.merge(mp_summary[["ticker", "iv_rank", "skew_25d", "term_slope"]],
                      on="ticker", how="left")
    if not df.empty and sentiment is not None and not sentiment.empty:
        df = df.merge(sentiment[["ticker", "mentions", "sentiment_now",
                                 "sentiment_delta", "velocity"]],
                      on="ticker", how="left")
    elif not df.empty:
        for c in ["mentions", "sentiment_now", "sentiment_delta", "velocity"]:
            df[c] = 0.0
    if not df.empty and fundamentals is not None and not fundamentals.empty:
        df = df.merge(fundamentals[["ticker", "fund_score", "classification",
                                    "earnings_date", "rev_growth", "op_margin", "pe",
                                    "market_cap"]],
                      on="ticker", how="left")
    elif not df.empty:
        for c in ["fund_score", "classification", "earnings_date",
                  "rev_growth", "op_margin", "pe", "market_cap"]:
            df[c] = None
    if not df.empty and insider is not None and not insider.empty:
        df = df.merge(insider[["ticker", "insider_score", "n_buys", "n_sells",
                               "buys_value", "sells_value"]],
                      on="ticker", how="left")
    elif not df.empty:
        for c in ["insider_score", "n_buys", "n_sells", "buys_value", "sells_value"]:
            df[c] = 0.0
    # News
    if not df.empty and news is not None and not news.empty:
        df = df.merge(news[["ticker", "n_24h", "n_7d", "news_sent_24h",
                            "news_sent_7d", "news_delta", "news_velocity",
                            "top_headline"]], on="ticker", how="left")
    elif not df.empty:
        for c in ["n_24h", "n_7d", "news_sent_24h", "news_sent_7d",
                  "news_delta", "news_velocity"]:
            df[c] = 0.0
        df["top_headline"] = ""
    # Earnings
    if not df.empty and earnings is not None and not earnings.empty:
        df = df.merge(earnings[["ticker", "next_earnings_date",
                                "days_to_earnings", "last_eps_surprise_pct",
                                "earnings_score"]], on="ticker", how="left")
    elif not df.empty:
        for c in ["next_earnings_date", "days_to_earnings",
                  "last_eps_surprise_pct", "earnings_score"]:
            df[c] = None

    # Congress
    if not df.empty and congress is not None and not congress.empty:
        df = df.merge(congress[["ticker", "congress_score", "congress_buys_n",
                                "congress_sells_n", "congress_buys_dollar",
                                "congress_n_reps", "congress_n_sens",
                                "congress_top_buyer"]],
                      on="ticker", how="left")
    elif not df.empty:
        for c in ["congress_score", "congress_buys_n", "congress_sells_n",
                  "congress_buys_dollar", "congress_n_reps", "congress_n_sens"]:
            df[c] = 0
        df["congress_top_buyer"] = ""

    # Social (StockTwits + Trump)
    if not df.empty and social is not None and not social.empty:
        df = df.merge(social[["ticker", "social_score", "stocktwits_n",
                              "stocktwits_avg_sent", "stocktwits_n_bull",
                              "stocktwits_n_bear", "trump_n", "trump_avg_sent",
                              "trump_excerpt"]],
                      on="ticker", how="left")
    elif not df.empty:
        for c in ["social_score", "stocktwits_n", "stocktwits_avg_sent",
                  "stocktwits_n_bull", "stocktwits_n_bear", "trump_n",
                  "trump_avg_sent"]:
            df[c] = 0
        df["trump_excerpt"] = ""

    # Analyst (Finnhub recommendations)
    if not df.empty and analyst is not None and not analyst.empty:
        df = df.merge(analyst[["ticker", "analyst_score", "analyst_strong_buy",
                                "analyst_buy", "analyst_hold", "analyst_sell",
                                "analyst_strong_sell", "analyst_total",
                                "analyst_avg", "analyst_momentum"]],
                      on="ticker", how="left")
    elif not df.empty:
        for c in ["analyst_score", "analyst_strong_buy", "analyst_buy",
                  "analyst_hold", "analyst_sell", "analyst_strong_sell",
                  "analyst_total", "analyst_avg", "analyst_momentum"]:
            df[c] = 0

    if not df.empty:
        df["macro_tilt"] = macro.get("macro_tilt", 0.0)
        df["regime"] = macro.get("regime", "neutral")

    return df


# -------- Options track -----------------------------------------------
def fuse_options(contracts: pd.DataFrame, mp_summary: pd.DataFrame,
                 sentiment: pd.DataFrame, fundamentals: pd.DataFrame,
                 insider: pd.DataFrame, macro: Dict[str, Any],
                 news: pd.DataFrame = None, earnings: pd.DataFrame = None,
                 value: pd.DataFrame = None,
                 congress: pd.DataFrame = None,
                 social: pd.DataFrame = None,
                 analyst: pd.DataFrame = None) -> pd.DataFrame:
    """Long-only option ranking. Returns one DataFrame with both calls and puts."""
    if contracts is None or contracts.empty:
        return pd.DataFrame()

    df = _join_per_ticker(contracts, mp_summary, sentiment, fundamentals, insider, macro,
                          news=news, earnings=earnings, congress=congress, social=social,
                          analyst=analyst)
    # Merge value
    if value is not None and not value.empty:
        df = df.merge(value[["ticker", "value_score", "value_bucket", "earnings_yield",
                             "fcf_yield", "graham_score"]], on="ticker", how="left")
    else:
        for c in ["value_score", "value_bucket", "earnings_yield",
                  "fcf_yield", "graham_score"]:
            df[c] = 0.0 if c == "value_score" else None

    # ---- Signal extraction ------------------------------------------
    df["vol_premium"] = df["iv_market"] - df["fair_vol"]
    # Mispricing: positive => undervalued => good to buy (we want this aligned)
    df["mispricing_signal"] = -df["vol_premium"]
    # IV rank: low IV-rank favours BUYING premium, high disfavours
    df["iv_rank_signal"] = -((df["iv_rank"].fillna(50) - 50) / 50)

    # Side multiplier — secondary signals are bullish-tilted; align to side
    side_mult = np.where(df["side"] == "call", 1.0, -1.0)

    df["sentiment_aligned"] = df["sentiment_delta"].fillna(0) * side_mult
    df["fund_aligned"] = df["fund_score"].fillna(0) * side_mult
    df["insider_aligned"] = df["insider_score"].fillna(0) * side_mult
    df["macro_aligned"] = df["macro_tilt"].fillna(0) * side_mult
    # Skew: high put skew → puts richer / calls relatively cheap → boosts calls
    df["skew_aligned"] = df["skew_25d"].fillna(0) * side_mult
    # News Δsentiment, side-aligned (positive news → bullish → boosts calls)
    df["news_aligned"] = df["news_delta"].fillna(0) * side_mult
    # Earnings catalyst, side-aligned (positive surprise + imminent → boost call/dampen put)
    df["earnings_aligned"] = df["earnings_score"].fillna(0) * side_mult
    # Value, side-aligned (cheap stock → bullish → boost call ideas)
    df["value_aligned"] = df.get("value_score", pd.Series(0.0, index=df.index)).fillna(0) * side_mult
    # Congress, side-aligned (Congressional buying → bullish → boost call ideas)
    df["congress_aligned"] = df.get("congress_score", pd.Series(0.0, index=df.index)).fillna(0) * side_mult
    # Social, side-aligned (positive Trump/StockTwits → bullish → boost calls)
    df["social_aligned"] = df.get("social_score", pd.Series(0.0, index=df.index)).fillna(0) * side_mult
    # Analyst, side-aligned (analyst momentum bullish → bullish → boost calls)
    df["analyst_aligned"] = df.get("analyst_score", pd.Series(0.0, index=df.index)).fillna(0) * side_mult

    # Cross-sectional z-scores
    df["z_mispricing"] = zscore(winsor(df["mispricing_signal"]))
    df["z_iv_rank"] = zscore(df["iv_rank_signal"])
    df["z_skew"] = zscore(df["skew_aligned"])
    df["z_sent"] = zscore(df["sentiment_aligned"])
    df["z_fund"] = zscore(df["fund_aligned"])
    df["z_insider"] = zscore(df["insider_aligned"])
    df["z_macro"] = zscore(df["macro_aligned"])
    df["z_news"] = zscore(df["news_aligned"])
    df["z_earnings"] = zscore(df["earnings_aligned"])
    df["z_value"] = zscore(df["value_aligned"])
    df["z_congress"] = zscore(df["congress_aligned"])
    df["z_social"] = zscore(df["social_aligned"])
    df["z_analyst"] = zscore(df["analyst_aligned"])

    # Weighted fusion → directional buy score
    w = SIGNAL_WEIGHTS
    df["fused_score"] = (
        w["mispricing"]    * df["z_mispricing"]
        + w["iv_rank"]     * df["z_iv_rank"]
        + w["skew"]        * df["z_skew"]
        + w["sentiment_d"] * df["z_sent"]
        + w["fundamentals"]* df["z_fund"]
        + w["insider"]     * df["z_insider"]
        + w["macro"]       * df["z_macro"]
        + w.get("news", 0) * df["z_news"]
        + w.get("earnings", 0) * df["z_earnings"]
        + w.get("value", 0) * df["z_value"]
        + w.get("congress", 0) * df["z_congress"]
        + w.get("social", 0) * df["z_social"]
        + w.get("analyst", 0) * df["z_analyst"]
    )

    # Long-only: drop everything with negative buy score
    df = df[df["fused_score"] > 0].copy()
    if df.empty:
        return df

    df["confidence"] = df["fused_score"].apply(_confidence)
    df["signal"] = df.apply(lambda r: _option_signal_label(r["side"], r["vol_premium"]), axis=1)
    df["reasoning"] = df.apply(_option_reasoning, axis=1)
    df["risks"] = df.apply(_option_risks, axis=1)
    df["contract"] = df.apply(
        lambda r: f"{r['ticker']} {r['expiry']} {'C' if r['side']=='call' else 'P'} {r['strike']:g}",
        axis=1,
    )
    df["rank_score"] = df["fused_score"]
    df = df.sort_values("rank_score", ascending=False).reset_index(drop=True)
    return df


def top_options(df: pd.DataFrame, max_calls: int = TOP_N_CALLS,
                max_puts: int = TOP_N_PUTS) -> pd.DataFrame:
    """Pick top calls and top puts with diversity (1 per ticker, max)."""
    if df.empty:
        return df
    seen = set()
    calls, puts = [], []
    for _, r in df.iterrows():
        if r["ticker"] in seen:
            continue
        if r["side"] == "call" and len(calls) < max_calls:
            calls.append(r); seen.add(r["ticker"])
        elif r["side"] == "put" and len(puts) < max_puts:
            puts.append(r); seen.add(r["ticker"])
        if len(calls) >= max_calls and len(puts) >= max_puts:
            break
    out = pd.DataFrame(calls + puts).reset_index(drop=True)
    return out


# -------- Shares track ------------------------------------------------
def fuse_shares(small_cap_universe: List[str], sentiment: pd.DataFrame,
                fundamentals: pd.DataFrame, insider: pd.DataFrame,
                macro: Dict[str, Any], excluded_tickers: set = None,
                news: pd.DataFrame = None, earnings: pd.DataFrame = None,
                value: pd.DataFrame = None,
                congress: pd.DataFrame = None) -> pd.DataFrame:
    """Score small caps for long shares.

    Built from the multi-factor stack only (no option pricing). Bullish-aligned
    only — small caps where Δsentiment, fundamentals, insiders, and macro all
    line up positive.
    """
    excluded_tickers = excluded_tickers or set()
    seen = set()
    rows = []
    for t in small_cap_universe:
        if t in excluded_tickers or t in seen:
            continue
        seen.add(t)
        rows.append({"ticker": t})
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows)

    if sentiment is not None and not sentiment.empty:
        df = df.merge(sentiment[["ticker", "mentions", "sentiment_now",
                                 "sentiment_delta", "velocity"]],
                      on="ticker", how="left")
    else:
        for c in ["mentions", "sentiment_now", "sentiment_delta", "velocity"]:
            df[c] = 0.0
    if fundamentals is not None and not fundamentals.empty:
        df = df.merge(fundamentals[["ticker", "fund_score", "classification",
                                    "earnings_date", "rev_growth", "op_margin", "pe",
                                    "market_cap"]],
                      on="ticker", how="left")
    else:
        for c in ["fund_score", "classification", "earnings_date",
                  "rev_growth", "op_margin", "pe", "market_cap"]:
            df[c] = None
    if insider is not None and not insider.empty:
        df = df.merge(insider[["ticker", "insider_score", "n_buys", "n_sells",
                               "buys_value", "sells_value"]],
                      on="ticker", how="left")
    else:
        for c in ["insider_score", "n_buys", "n_sells", "buys_value", "sells_value"]:
            df[c] = 0.0

    # Merge news + earnings if available
    if news is not None and not news.empty:
        df = df.merge(news[["ticker", "news_delta", "news_velocity", "top_headline",
                            "n_24h"]], on="ticker", how="left")
    else:
        df["news_delta"] = 0.0
        df["news_velocity"] = 0.0
        df["top_headline"] = ""
        df["n_24h"] = 0
    if earnings is not None and not earnings.empty:
        df = df.merge(earnings[["ticker", "next_earnings_date", "days_to_earnings",
                                "earnings_score"]], on="ticker", how="left")
    else:
        df["next_earnings_date"] = None
        df["days_to_earnings"] = None
        df["earnings_score"] = 0.0

    if value is not None and not value.empty:
        df = df.merge(value[["ticker", "value_score", "value_bucket"]], on="ticker", how="left")
    else:
        df["value_score"] = 0.0
        df["value_bucket"] = None

    if congress is not None and not congress.empty:
        df = df.merge(congress[["ticker", "congress_score", "congress_buys_n",
                                "congress_n_reps", "congress_n_sens", "congress_top_buyer"]],
                      on="ticker", how="left")
    else:
        df["congress_score"] = 0.0
        df["congress_buys_n"] = 0
        df["congress_n_reps"] = 0
        df["congress_n_sens"] = 0
        df["congress_top_buyer"] = ""

    df["macro_tilt"] = macro.get("macro_tilt", 0.0)
    df["regime"] = macro.get("regime", "neutral")

    # Cross-sectional z-scores (no side multiplier — shares are inherently long bullish)
    df["z_sent"] = zscore(df["sentiment_delta"].fillna(0))
    df["z_fund"] = zscore(df["fund_score"].fillna(0))
    df["z_insider"] = zscore(df["insider_score"].fillna(0))
    df["z_velocity"] = zscore(df["velocity"].fillna(0))
    df["z_news"] = zscore(df["news_delta"].fillna(0))
    df["z_earnings"] = zscore(df["earnings_score"].fillna(0))
    df["z_value"] = zscore(df["value_score"].fillna(0))
    df["z_congress"] = zscore(df["congress_score"].fillna(0))

    # Bullish-tilt fusion (shares-only)
    df["share_score"] = (
        0.16 * df["z_sent"]
        + 0.14 * df["z_fund"]
        + 0.14 * df["z_insider"]
        + 0.05 * df["z_velocity"]
        + 0.06 * df["macro_tilt"]
        + 0.09 * df["z_news"]
        + 0.09 * df["z_earnings"]
        + 0.15 * df["z_value"]
        + 0.12 * df["z_congress"]
    )

    # Long-only: keep bullish-aligned above threshold
    df = df[df["share_score"] >= SHARES_MIN_SCORE].copy()
    if df.empty:
        return df

    df["confidence"] = df["share_score"].apply(lambda s: int(min(100, 50 + s * 22)))
    df["signal"] = "Long Shares (small cap)"
    df["reasoning"] = df.apply(_share_reasoning, axis=1)
    df["risks"] = df.apply(_share_risks, axis=1)
    df["rank_score"] = df["share_score"]
    df = df.sort_values("rank_score", ascending=False).reset_index(drop=True)
    return df


def top_shares(df: pd.DataFrame, n: int = TOP_N_SHARES) -> pd.DataFrame:
    if df.empty:
        return df
    return df.head(n).reset_index(drop=True)


# -------- TradingView watchlist export -------------------------------
def to_tv_watchlist(calls: pd.DataFrame, puts: pd.DataFrame, shares: pd.DataFrame) -> str:
    """Emit a TradingView-compatible watchlist file.

    Format: one symbol per line, with section headers. Importable via TV's
    watchlist 'Import file' on the right-hand panel.
    """
    lines = ["###Optedge Long Calls"]
    if calls is not None and not calls.empty:
        for _, r in calls.iterrows():
            lines.append(f"NASDAQ:{r['ticker']}")
    lines.append("###Optedge Long Puts")
    if puts is not None and not puts.empty:
        for _, r in puts.iterrows():
            lines.append(f"NASDAQ:{r['ticker']}")
    lines.append("###Optedge Long Shares (small cap)")
    if shares is not None and not shares.empty:
        for _, r in shares.iterrows():
            lines.append(f"NASDAQ:{r['ticker']}")
    return "\n".join(lines) + "\n"
