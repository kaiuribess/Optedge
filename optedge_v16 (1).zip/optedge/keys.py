"""Local API keys. Gitignored — never committed to a repo.

Code reads OS env vars first, then falls back to these defaults.
Override either way:
  setx FRED_API_KEY "your_key"     # Windows persistent
  set  FRED_API_KEY=your_key        # cmd.exe one-shot
  $env:FRED_API_KEY="your_key"      # PowerShell one-shot
"""
import os

FRED_API_KEY    = os.environ.get("FRED_API_KEY",    "e1bc03311d9b97f55e728cad410cc179")
FINNHUB_API_KEY = os.environ.get("FINNHUB_API_KEY", "d7qruj9r01qudminajegd7qruj9r01qudminajf0")


def get_fred() -> str:
    return FRED_API_KEY


def get_finnhub() -> str:
    return FINNHUB_API_KEY
