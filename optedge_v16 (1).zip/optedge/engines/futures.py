"""Futures engine — Optedge v16. Multi-factor self-learning futures recommender.

Key changes vs v15:
  - Pulls every relevant signal already computed by the wider stack and maps
    them per asset class (equity-index uses top SPY/QQQ-component sentiment +
    news + congress + earnings + Trump posts on Fed; metals use DXY-inverse +
    real-yields-inverse; energy uses OPEC/Russia/Iran news + Trump on energy;
    crypto uses crypto-sub sentiment + risk-on macro flag, etc).
  - Emits real, executable trade tickets: micro-contract default (MES, MNQ,
    MYM, M2K, MGC, SIL, MCL, MNG, MBT, MET) sized to bankroll, ATR-based
    stops, explicit entry/stop/target with $ risk + reward + R:R + margin.
  - Score = sum(w_i * z_i) with weights from engines.learning per asset class
    (auto-tunes via Lasso/IC over time; falls back to hand-crafted priors).

The engine accepts the OTHER engines' DataFrames as inputs so it can build
asset-class-specific factor vectors. run() is backwards-compatible — every
DataFrame argument is optional and defaults to empty.
"""
from __future__ import annotations
import logging
import math
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Any, Optional, Tuple

import numpy as np
import pandas as pd

import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import data_provider
from utils import safe_float
from engines import learning

log = logging.getLogger("optedge.futures")


# ---------------------------------------------------------------------------
# Universe — full-size symbols + per-symbol micro mapping + contract specs
# ---------------------------------------------------------------------------
FUTURES = [
    # Equity index
    {"symbol": "ES=F", "name": "S&P 500 E-mini",   "etf": "SPY", "kind": "equity"},
    {"symbol": "NQ=F", "name": "Nasdaq-100 E-mini", "etf": "QQQ", "kind": "equity"},
    {"symbol": "YM=F", "name": "Dow E-mini",       "etf": "DIA", "kind": "equity"},
    {"symbol": "RTY=F","name": "Russell 2000 E-mini","etf":"IWM","kind": "equity"},
    # Volatility / treasury
    {"symbol": "^VIX", "name": "CBOE Volatility",   "etf": "VXX", "kind": "vol"},
    {"symbol": "ZB=F", "name": "30Y Treasury Bond", "etf": "TLT", "kind": "bond"},
    {"symbol": "ZN=F", "name": "10Y Treasury Note", "etf": "IEF", "kind": "bond"},
    # Commodities — metal
    {"symbol": "GC=F", "name": "Gold",              "etf": "GLD",  "kind": "commodity"},
    {"symbol": "SI=F", "name": "Silver",            "etf": "SLV",  "kind": "commodity"},
    {"symbol": "CL=F", "name": "Crude Oil WTI",     "etf": "USO",  "kind": "commodity"},
    {"symbol": "NG=F", "name": "Natural Gas",       "etf": "UNG",  "kind": "commodity"},
    {"symbol": "HG=F", "name": "Copper",            "etf": "CPER", "kind": "commodity"},
    {"symbol": "PL=F", "name": "Platinum",          "etf": "PPLT", "kind": "commodity"},
    {"symbol": "ZC=F", "name": "Corn",              "etf": "CORN", "kind": "agri"},
    {"symbol": "ZS=F", "name": "Soybeans",          "etf": "SOYB", "kind": "agri"},
    {"symbol": "ZW=F", "name": "Wheat",             "etf": "WEAT", "kind": "agri"},
    # Currency
    {"symbol": "DX=F", "name": "US Dollar Index",   "etf": "UUP",  "kind": "fx"},
    # Crypto
    {"symbol": "BTC=F","name": "Bitcoin",           "etf": "IBIT", "kind": "crypto"},
    {"symbol": "ETH=F","name": "Ether",             "etf": "ETHA", "kind": "crypto"},
]


# Full-size → micro mapping with point value, tick size, initial margin (USD).
# Margin is approximate — broker-specific. Used for sizing math, not authoritative.
MICRO_MAP: Dict[str, Dict[str, Any]] = {
    # Equity index
    "ES=F":  {"micro": "MES",  "point_value": 5.0,   "tick": 0.25,  "margin": 1320,
              "full_point_value": 50.0,  "full_margin": 13200},
    "NQ=F":  {"micro": "MNQ",  "point_value": 2.0,   "tick": 0.25,  "margin": 1760,
              "full_point_value": 20.0,  "full_margin": 17600},
    "YM=F":  {"micro": "MYM",  "point_value": 0.50,  "tick": 1.0,   "margin": 660,
              "full_point_value": 5.0,   "full_margin": 6600},
    "RTY=F": {"micro": "M2K",  "point_value": 5.0,   "tick": 0.10,  "margin": 480,
              "full_point_value": 50.0,  "full_margin": 4800},
    # Treasuries
    "ZB=F":  {"micro": None,   "point_value": 1000,  "tick": 1/32,  "margin": 4400},
    "ZN=F":  {"micro": None,   "point_value": 1000,  "tick": 0.5/32,"margin": 1800},
    # Metals
    "GC=F":  {"micro": "MGC",  "point_value": 10.0,  "tick": 0.10,  "margin": 1150,
              "full_point_value": 100.0, "full_margin": 11500},
    "SI=F":  {"micro": "SIL",  "point_value": 1000,  "tick": 0.005, "margin": 4000,
              "full_point_value": 5000,  "full_margin": 18000},
    "PL=F":  {"micro": None,   "point_value": 50.0,  "tick": 0.10,  "margin": 4200},
    "HG=F":  {"micro": None,   "point_value": 250.0, "tick": 0.0005,"margin": 5500},
    # Energy
    "CL=F":  {"micro": "MCL",  "point_value": 100.0, "tick": 0.01,  "margin": 540,
              "full_point_value": 1000,  "full_margin": 5400},
    "NG=F":  {"micro": "MNG",  "point_value": 1000,  "tick": 0.005, "margin": 1200,
              "full_point_value": 10000, "full_margin": 5000},
    # Agri
    "ZC=F":  {"micro": None,   "point_value": 50.0,  "tick": 0.0025,"margin": 1500},
    "ZS=F":  {"micro": None,   "point_value": 50.0,  "tick": 0.0025,"margin": 2300},
    "ZW=F":  {"micro": None,   "point_value": 50.0,  "tick": 0.0025,"margin": 1800},
    # Currency
    "DX=F":  {"micro": None,   "point_value": 1000,  "tick": 0.005, "margin": 1700},
    # Crypto
    "BTC=F": {"micro": "MBT",  "point_value": 0.10,  "tick": 5.0,   "margin": 850,
              "full_point_value": 5.0,   "full_margin": 17000},
    "ETH=F": {"micro": "MET",  "point_value": 0.10,  "tick": 0.25,  "margin": 1200,
              "full_point_value": 50.0,  "full_margin": 8000},
}


# ATR multipliers (conservative / aggressive)
ATR_STOP_MULT      = 1.5
ATR_TARGET_MULT    = 3.0
ATR_STOP_MULT_AGG  = 2.0
ATR_TARGET_MULT_AGG= 4.0


# ---------------------------------------------------------------------------
# Component lookup tables — top SPY/QQQ holdings used for equity-index aggs.
# ---------------------------------------------------------------------------
SPY_TOP_30 = [
    "AAPL","MSFT","NVDA","AMZN","GOOGL","GOOG","META","TSLA","BRK-B","AVGO",
    "JPM","XOM","UNH","V","LLY","WMT","PG","JNJ","MA","HD",
    "COST","ABBV","NFLX","BAC","CRM","ORCL","KO","CVX","WFC","ADBE",
]
QQQ_TOP_25 = [
    "AAPL","MSFT","NVDA","AMZN","GOOGL","GOOG","META","TSLA","AVGO","COST",
    "NFLX","ADBE","AMD","PEP","CSCO","INTC","QCOM","TMUS","CMCSA","INTU",
    "AMGN","TXN","HON","BKNG","ISRG",
]
DIA_TOP_15 = [
    "UNH","GS","MSFT","HD","CAT","CRM","V","MCD","AMGN","AXP",
    "AAPL","BA","JPM","TRV","HON",
]
IWM_TOP_15 = [
    "SMCI","COIN","CVNA","HOOD","RKLB","CELH","PLTR","MSTR","RIVN","TXG",
    "AFRM","CRWD","DDOG","NET","ROKU",
]

INDEX_COMPONENTS = {
    "ES=F": SPY_TOP_30,
    "NQ=F": QQQ_TOP_25,
    "YM=F": DIA_TOP_15,
    "RTY=F": IWM_TOP_15,
}


# Crypto-adjacent equity proxies (sentiment leak from crypto-equities → futures)
CRYPTO_PROXY = ["MSTR","COIN","MARA","RIOT","CLSK","HUT","WULF","CIFR","CORZ","BITF"]
ENERGY_PROXY = ["XOM","CVX","COP","OXY","EOG","SLB","MPC","VLO","PSX","HAL","FANG","DVN"]
METAL_PROXY  = ["GDX","NEM","GOLD","AEM","WPM","FNV","HMY","BTG","AU","RGLD","KGC"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _hv(close: pd.Series, n: int) -> Optional[float]:
    if close is None or len(close) < n + 1:
        return None
    rets = np.log(close / close.shift(1)).dropna().tail(n)
    if rets.empty:
        return None
    return float(rets.std() * math.sqrt(252))


def _atr14(h: pd.DataFrame, n: int = 14) -> Optional[float]:
    """Average True Range from high/low/close history. Returns ATR in price units."""
    try:
        if h is None or h.empty or len(h) < n + 1:
            return None
        if not all(c in h.columns for c in ("High","Low","Close")):
            return None
        high = h["High"]; low = h["Low"]; close = h["Close"]
        prev_close = close.shift(1)
        tr = pd.concat([
            (high - low),
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ], axis=1).max(axis=1)
        atr = tr.rolling(n).mean().iloc[-1]
        return float(atr) if not pd.isna(atr) else None
    except Exception:
        return None


def _trend_zscore(ret_20d: Optional[float]) -> float:
    """Map 20d return to z. ±13% return → ±1z (so ±26% maxes ±2z)."""
    if ret_20d is None:
        return 0.0
    return float(max(-3.0, min(3.0, ret_20d / 0.13)))


def _momentum_zscore(ret_5d: Optional[float]) -> float:
    if ret_5d is None:
        return 0.0
    return float(max(-3.0, min(3.0, ret_5d / 0.04)))


def _range_pos_z(range_pos: Optional[float]) -> float:
    """Mean-reversion z. Below 25% → +0.8z, above 85% → -0.6z, linear in between."""
    if range_pos is None:
        return 0.0
    if range_pos < 0.25:
        return float((0.25 - range_pos) * 3.2)
    if range_pos > 0.85:
        return float((0.85 - range_pos) * 4.0)
    return 0.0


def _trend_of(symbol: str, lookback: int = 20) -> float:
    """+1 / -1 / 0 trend label from N-day return."""
    try:
        h = data_provider.get_history(symbol, period="3mo", cache_age=3600)
        if h is None or h.empty or len(h) < lookback + 1:
            return 0.0
        c = h["Close"].dropna()
        ret = c.iloc[-1] / c.iloc[-lookback - 1] - 1
        if ret > 0.02:  return 1.0
        if ret < -0.02: return -1.0
        return 0.0
    except Exception:
        return 0.0


# ---------------------------------------------------------------------------
# Macro alignment per asset class
# ---------------------------------------------------------------------------
def _macro_align_for(symbol: str, kind: str, macro: Dict[str, Any],
                     vix_trend: float = 0.0,
                     dxy_trend: float = 0.0,
                     yield_trend: float = 0.0) -> float:
    """Return [-1.5, +1.5] alignment given macro state. Sign = bullish for the contract."""
    if not macro:
        return 0.0
    vix = macro.get("vix") or 20.0
    cpi = macro.get("cpi_yoy")
    hy  = macro.get("hy_spread")
    m2  = macro.get("m2_yoy")
    yld = macro.get("yield_10y")
    t10y3m = macro.get("t10y3m")

    if kind in ("equity", "vol"):
        score = 0.0
        if vix is not None:
            score += max(-1.0, min(1.0, (20 - vix) / 10.0))
        score -= 0.5 * vix_trend
        if cpi is not None:
            score -= 0.5 * max(-1.0, min(1.0, (cpi - 0.025) / 0.02))
        if hy is not None:
            score -= 0.4 * max(-1.0, min(1.0, (hy - 4.0) / 1.5))
        if t10y3m is not None and t10y3m < 0:
            score -= 0.3
        if kind == "vol":
            score = -score
        return float(max(-1.5, min(1.5, score)))

    if kind == "bond":
        score = 0.0
        if cpi is not None:
            score -= 0.6 * max(-1.0, min(1.0, (cpi - 0.025) / 0.02))
        if macro.get("initial_claims") and macro["initial_claims"] > 250_000:
            score += 0.4
        if t10y3m is not None and t10y3m < -0.3:
            score += 0.3
        score -= 0.5 * yield_trend
        return float(max(-1.5, min(1.5, score)))

    if kind == "commodity" and symbol in ("GC=F","SI=F","PL=F","HG=F"):
        score = 0.0
        score -= 0.7 * dxy_trend
        if yld is not None:
            score -= 0.4 * max(-1.0, min(1.0, (yld - 4.0) / 1.5))
        if vix is not None:
            score += 0.2 * max(-1.0, min(1.0, (vix - 15) / 10))
        if hy is not None and hy > 5:
            score += 0.3
        if m2 is not None and m2 > 0.05:
            score += 0.2
        return float(max(-1.5, min(1.5, score)))

    if kind == "commodity" and symbol in ("CL=F","NG=F"):
        score = 0.0
        score -= 0.4 * dxy_trend
        if macro.get("industrial_prod_yoy") is not None:
            score += 0.3 * max(-1.0, min(1.0, macro["industrial_prod_yoy"] / 0.03))
        return float(max(-1.5, min(1.5, score)))

    if kind == "fx":
        score = 0.0
        if yld is not None:
            score += 0.4 * max(-1.0, min(1.0, (yld - 4.0) / 1.5))
        if cpi is not None:
            score += 0.3 * max(-1.0, min(1.0, (cpi - 0.025) / 0.02))
        score += 0.3 * yield_trend
        return float(max(-1.5, min(1.5, score)))

    if kind == "crypto":
        score = 0.0
        if vix is not None:
            score += max(-1.0, min(1.0, (20 - vix) / 10.0))
        if hy is not None:
            score += 0.4 * max(-1.0, min(1.0, (4 - hy) / 1.5))
        if m2 is not None:
            score += 0.4 * max(-1.0, min(1.0, m2 / 0.05))
        return float(max(-1.5, min(1.5, score)))

    if kind == "agri":
        score = 0.0
        score -= 0.3 * dxy_trend
        return float(max(-1.0, min(1.0, score)))

    return 0.0


# ---------------------------------------------------------------------------
# Component aggregation
# ---------------------------------------------------------------------------
def _aggregate_component_score(component_tickers: List[str],
                                df: Optional[pd.DataFrame],
                                col: str) -> float:
    """Mean of `col` across components when present in df."""
    if df is None or df.empty or "ticker" not in df.columns or col not in df.columns:
        return 0.0
    sub = df[df["ticker"].isin(component_tickers)]
    if sub.empty:
        return 0.0
    vals = pd.to_numeric(sub[col], errors="coerce").dropna()
    if vals.empty:
        return 0.0
    return float(vals.mean())


def _trump_relevance(symbol: str, kind: str, social_df: Optional[pd.DataFrame]) -> float:
    """Approximate Trump-post relevance for a futures contract."""
    if social_df is None or social_df.empty:
        return 0.0
    if "trump_n" not in social_df.columns or "trump_avg_sent" not in social_df.columns:
        return 0.0
    sub = social_df[social_df["trump_n"] > 0]
    if sub.empty:
        return 0.0

    rel: List[str] = []
    if kind in ("equity", "vol"):
        rel = SPY_TOP_30 + ["DJT", "DIA", "SPY", "QQQ"]
    elif kind == "bond":
        rel = ["TLT", "IEF", "JPM", "BAC"]
    elif kind == "fx":
        rel = ["UUP"]
    elif symbol in ("GC=F","SI=F","PL=F","HG=F"):
        rel = METAL_PROXY + ["GLD","SLV"]
    elif symbol in ("CL=F","NG=F"):
        rel = ENERGY_PROXY + ["XLE", "USO"]
    elif kind == "crypto":
        rel = CRYPTO_PROXY + ["IBIT","ETHA","DJT"]
    elif kind == "agri":
        rel = ["DE", "ADM", "BG", "MOS", "CF"]

    sub = sub[sub["ticker"].isin(rel)]
    if sub.empty:
        return 0.0
    weighted = (sub["trump_avg_sent"].astype(float) * sub["trump_n"].astype(float)).sum()
    total_n = float(sub["trump_n"].sum())
    if total_n == 0:
        return 0.0
    return float(max(-1.5, min(1.5, weighted / total_n * 1.5)))


def _geo_news_score(kind: str, symbol: str, news_df: Optional[pd.DataFrame]) -> float:
    """Aggregate news flow on commodity-sensitive proxies."""
    if news_df is None or news_df.empty:
        return 0.0
    if "ticker" not in news_df.columns or "news_delta" not in news_df.columns:
        return 0.0

    if symbol in ("CL=F","NG=F"):
        rel = ENERGY_PROXY
    elif symbol in ("GC=F","SI=F","PL=F","HG=F"):
        rel = METAL_PROXY
    elif kind == "agri":
        rel = ["DE","ADM","BG","MOS","CF"]
    else:
        return 0.0

    sub = news_df[news_df["ticker"].isin(rel)]
    if sub.empty:
        return 0.0
    delta = pd.to_numeric(sub["news_delta"], errors="coerce").dropna()
    if delta.empty:
        return 0.0
    return float(max(-1.5, min(1.5, delta.mean() * 5.0)))


def _fred_panel_score(macro: Dict[str, Any], kind: str, symbol: str) -> float:
    """Sign-adjusted z of relevant FRED variables per bucket."""
    if not macro:
        return 0.0
    cpi = macro.get("cpi_yoy")
    hy = macro.get("hy_spread")
    m2 = macro.get("m2_yoy")
    claims = macro.get("initial_claims")

    if kind in ("equity","vol"):
        s = 0.0
        if cpi is not None: s -= max(-1.0, min(1.0, (cpi - 0.025) / 0.015))
        if hy is not None:  s -= max(-1.0, min(1.0, (hy - 4.0) / 1.5))
        if m2 is not None:  s += max(-0.5, min(0.5, m2 / 0.05))
        if claims is not None and claims > 250_000: s -= 0.3
        return float(max(-1.5, min(1.5, s)))

    if kind == "bond":
        s = 0.0
        if cpi is not None: s -= max(-1.0, min(1.0, (cpi - 0.025) / 0.015))
        if claims is not None: s += max(-0.5, min(1.0, (claims - 220_000) / 50_000))
        return float(max(-1.5, min(1.5, s)))

    if symbol in ("GC=F","SI=F","PL=F"):
        s = 0.0
        if cpi is not None: s += max(-0.5, min(1.0, (cpi - 0.025) / 0.015))
        if hy is not None:  s += max(-0.5, min(1.0, (hy - 4.0) / 1.5))
        if m2 is not None:  s += max(-0.5, min(0.5, m2 / 0.05))
        return float(max(-1.5, min(1.5, s)))

    if kind == "crypto":
        s = 0.0
        if hy is not None: s -= max(-1.0, min(0.5, (hy - 4.0) / 1.5))
        if m2 is not None: s += max(-0.5, min(0.5, m2 / 0.05))
        return float(max(-1.5, min(1.5, s)))

    if kind == "fx":
        s = 0.0
        if cpi is not None: s += max(-0.5, min(0.5, (cpi - 0.025) / 0.02))
        return float(max(-0.5, min(0.5, s)))

    return 0.0


def _components_for(symbol: str, kind: str) -> List[str]:
    if symbol in INDEX_COMPONENTS:
        return INDEX_COMPONENTS[symbol]
    if symbol in ("GC=F","SI=F","PL=F","HG=F"):
        return METAL_PROXY
    if symbol in ("CL=F","NG=F"):
        return ENERGY_PROXY
    if kind == "crypto":
        return CRYPTO_PROXY
    return []


# ---------------------------------------------------------------------------
# Main per-contract worker
# ---------------------------------------------------------------------------
def _process(meta: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    """Build full factor row + score + recommended trade for one contract."""
    sym = meta["symbol"]
    bankroll = float(context.get("bankroll", 25000) or 25000)
    aggressive = bool(context.get("aggressive", False))

    bucket = learning.bucket_for_futures_row(meta)
    out = {**meta, "bucket": bucket, "futures_score": 0.0}

    try:
        h = data_provider.get_history(sym, period="1y")
        if h is None or h.empty or "Close" not in h.columns:
            return out
        close = h["Close"].dropna()
        if close.empty:
            return out
        spot = float(close.iloc[-1])

        ret_5d = float(close.iloc[-1] / close.iloc[-6] - 1) if len(close) > 6 else None
        ret_20d = float(close.iloc[-1] / close.iloc[-21] - 1) if len(close) > 21 else None
        ret_60d = float(close.iloc[-1] / close.iloc[-61] - 1) if len(close) > 61 else None
        hv20 = _hv(close, 20)
        atr = _atr14(h)

        last = close.tail(252) if len(close) > 252 else close
        hi, lo = float(last.max()), float(last.min())
        range_pos = (spot - lo) / (hi - lo) if hi > lo else 0.5

        # ATR regime: ATR vs 60-day median (vol expansion proxy)
        atr_regime = 0.0
        if atr is not None and "High" in h.columns and "Low" in h.columns:
            try:
                tail = h.tail(60)
                tr = pd.concat([
                    (tail["High"] - tail["Low"]),
                    (tail["High"] - tail["Close"].shift(1)).abs(),
                    (tail["Low"] - tail["Close"].shift(1)).abs(),
                ], axis=1).max(axis=1)
                med = tr.rolling(14).mean().median()
                if med and med > 0:
                    atr_regime = float(np.log((atr or med) / med))
            except Exception:
                pass

        # IV-rank proxy from realized vol percentile (1y window)
        iv_rank_proxy = 0.0
        if hv20 is not None and len(close) > 60:
            rolling_hv = close.pct_change().rolling(20).std() * math.sqrt(252)
            rolling_hv = rolling_hv.dropna()
            if len(rolling_hv) > 30:
                pct = float((rolling_hv <= hv20).mean())
                iv_rank_proxy = float((pct - 0.5) * 2.0)

        kind = meta.get("kind","")

        # Macro state + cross-asset trend overlays
        macro = context.get("macro") or {}
        vix_trend = _trend_of("^VIX", 20)
        dxy_trend = _trend_of("DX=F", 20)
        yld_trend = _trend_of("^TNX", 20)

        macro_align = _macro_align_for(sym, kind, macro,
                                       vix_trend=vix_trend,
                                       dxy_trend=dxy_trend,
                                       yield_trend=yld_trend)

        # Component aggregation across the user's 13-engine stack
        comps = _components_for(sym, kind)
        sentiment_d = _aggregate_component_score(comps, context.get("sentiment_df"),
                                                  "sentiment_delta")
        news_score = _aggregate_component_score(comps, context.get("news_df"),
                                                 "news_delta")
        congress_score = _aggregate_component_score(comps, context.get("congress_df"),
                                                     "congress_score")
        # Earnings catalyst: mean earnings_score across components
        earn_score = 0.0
        earn_df = context.get("earn_df")
        if comps and earn_df is not None and not earn_df.empty:
            sub = earn_df[earn_df["ticker"].isin(comps)]
            if not sub.empty and "earnings_score" in sub.columns:
                vals = pd.to_numeric(sub["earnings_score"], errors="coerce").dropna()
                if not vals.empty:
                    earn_score = float(vals.mean())

        social_relevance = _trump_relevance(sym, kind, context.get("social_df"))

        # Geopolitical news bucket on top of component news for energy/metals/agri
        geo = _geo_news_score(kind, sym, context.get("news_df"))
        news_total = (news_score + geo) / 2.0 if abs(geo) > 0.01 else news_score

        fred_score = _fred_panel_score(macro, kind, sym)

        # Term-structure proxy: divergence of 5d momentum vs 20d trend
        term_structure = 0.0
        if ret_5d is not None and ret_20d is not None:
            term_structure = float(max(-1.0, min(1.0, (ret_5d * 4 - ret_20d) * 5)))

        # Build factor matrix row (z-units, all factors clamped to reasonable ranges)
        factors = {
            "trend":          _trend_zscore(ret_20d),
            "momentum":       _momentum_zscore(ret_5d),
            "range_pos":      _range_pos_z(range_pos),
            "macro_align":    macro_align,
            "components":     float(max(-2.0, min(2.0, sentiment_d * 2))),
            "news":           float(max(-2.0, min(2.0, news_total * 2))),
            "earnings":       float(max(-1.5, min(1.5, earn_score * 1.5))),
            "social":         social_relevance,
            "congress":       float(max(-1.5, min(1.5, congress_score * 1.5))),
            "fred_panel":     fred_score,
            "iv_rank":        iv_rank_proxy,
            "atr_regime":     float(max(-1.5, min(1.5, atr_regime))),
            "term_structure": term_structure,
            "sentiment_d":    float(max(-2.0, min(2.0, sentiment_d * 2))),
        }

        # Score via per-bucket weights from learning module
        weights = learning.load_weights(bucket)
        score = 0.0
        for k, w in weights.items():
            if k in factors:
                score += w * factors[k]

        # Direction: long if score > 0
        is_long = score > 0
        side_label = "LONG" if is_long else "SHORT"

        # ------ Trade ticket sizing ------
        spec = MICRO_MAP.get(sym, {})
        micro_sym = spec.get("micro") or sym.replace("=F", "")
        point_value = spec.get("point_value", 1.0)
        margin = spec.get("margin", 1000)

        # ATR-based stops (volatility-units, what actually keeps futures alive)
        stop_mult = ATR_STOP_MULT_AGG if aggressive else ATR_STOP_MULT
        target_mult = ATR_TARGET_MULT_AGG if aggressive else ATR_TARGET_MULT
        atr_pts = atr if atr is not None else (spot * 0.01)

        if is_long:
            entry = spot
            stop_price = entry - stop_mult * atr_pts
            target_price = entry + target_mult * atr_pts
        else:
            entry = spot
            stop_price = entry + stop_mult * atr_pts
            target_price = entry - target_mult * atr_pts

        stop_pts = abs(entry - stop_price)
        target_pts = abs(target_price - entry)
        dollar_risk_per_contract = stop_pts * point_value
        dollar_reward_per_contract = target_pts * point_value
        rr = dollar_reward_per_contract / dollar_risk_per_contract if dollar_risk_per_contract > 0 else 0

        # Score-scaled Kelly cap
        max_pct = 0.20 if aggressive else 0.12
        score_strength = max(0.0, min(1.5, abs(score)))
        kelly_pct_raw = score_strength / 3.0
        kelly_pct = min(max_pct, kelly_pct_raw * (0.5 if aggressive else 0.25))

        target_dollar_risk = bankroll * kelly_pct
        n_contracts = int(max(0, math.floor(target_dollar_risk / max(1.0, dollar_risk_per_contract))))
        if n_contracts == 0 and abs(score) >= 0.6 and margin <= bankroll * max_pct:
            n_contracts = 1

        actual_dollar_risk = n_contracts * dollar_risk_per_contract
        actual_dollar_reward = n_contracts * dollar_reward_per_contract
        margin_required = n_contracts * margin
        pct_bankroll = (margin_required / bankroll) if bankroll > 0 else 0
        expected_pnl = (n_contracts * dollar_reward_per_contract * 0.5) - (n_contracts * dollar_risk_per_contract * 0.5)

        out.update({
            "spot": round(spot, 2),
            "ret_5d": round(ret_5d, 4) if ret_5d is not None else None,
            "ret_20d": round(ret_20d, 4) if ret_20d is not None else None,
            "ret_60d": round(ret_60d, 4) if ret_60d is not None else None,
            "hv20": round(hv20, 4) if hv20 else None,
            "atr14": round(atr, 3) if atr is not None else None,
            "range_pos": round(range_pos, 3),

            # Factor row — preserved verbatim, used by the learner
            **{f"factor_{k}": round(v, 4) for k, v in factors.items()},

            "futures_score": round(float(score), 3),
            "side": side_label,
            "is_long": bool(is_long),
            "macro_align": round(float(macro_align), 3),

            # Trade ticket
            "micro_symbol": micro_sym,
            "point_value": point_value,
            "margin_per_contract": margin,
            "stop_atr_mult": stop_mult,
            "target_atr_mult": target_mult,
            "entry": round(float(entry), 4),
            "stop_price": round(float(stop_price), 4),
            "target_price": round(float(target_price), 4),
            "stop_pts": round(float(stop_pts), 4),
            "target_pts": round(float(target_pts), 4),
            "dollar_risk_per_contract": round(dollar_risk_per_contract, 2),
            "dollar_reward_per_contract": round(dollar_reward_per_contract, 2),
            "n_contracts": int(n_contracts),
            "actual_dollar_risk": round(actual_dollar_risk, 2),
            "actual_dollar_reward": round(actual_dollar_reward, 2),
            "rr": round(rr, 2),
            "kelly_pct": round(float(kelly_pct), 4),
            "margin_required": round(margin_required, 2),
            "pct_bankroll": round(float(pct_bankroll), 4),
            "expected_pnl": round(expected_pnl, 2),
        })
        return out
    except Exception as e:
        log.debug("futures fail %s: %s", sym, e)
        return out


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def run(max_workers: int = 6,
        bankroll: float = 25000,
        aggressive: bool = False,
        macro: Optional[Dict[str, Any]] = None,
        sentiment_df: Optional[pd.DataFrame] = None,
        news_df: Optional[pd.DataFrame] = None,
        congress_df: Optional[pd.DataFrame] = None,
        social_df: Optional[pd.DataFrame] = None,
        earn_df: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    """Run multi-factor futures scoring across the universe.

    All optional DataFrames default to empty for backwards compatibility.
    Pass them in via run.py for the full self-learning experience.
    """
    log.info("futures: %d contracts (parallel, %d workers)", len(FUTURES), max_workers)

    learning.initialize_priors(force=False)

    context = {
        "bankroll": bankroll,
        "aggressive": aggressive,
        "macro": macro or {},
        "sentiment_df": sentiment_df,
        "news_df": news_df,
        "congress_df": congress_df,
        "social_df": social_df,
        "earn_df": earn_df,
    }
    rows = []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs = {ex.submit(_process, m, context): m for m in FUTURES}
        for fut in as_completed(futs):
            try:
                rows.append(fut.result())
            except Exception as e:
                log.debug("futures worker fail: %s", e)
    df = pd.DataFrame(rows)
    if "futures_score" in df.columns:
        df = df.sort_values("futures_score", ascending=False).reset_index(drop=True)
    return df
