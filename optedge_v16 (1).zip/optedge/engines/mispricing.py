"""Options mispricing engine.

For each ticker:
  1. Pull options chain via data_provider (uses curl_cffi + caching).
  2. Get spot, dividend yield, historical vol (HV30, HV60, HV252).
  3. For each contract:
       - solve implied vol from market mid
       - compute theoretical price using HV30 as fair vol
       - compute mispricing in $ and σ terms
       - compute IV rank, liquidity & spread metrics
  4. Detect skew (25-delta put IV vs 25-delta call IV).
  5. Detect term-structure slope.
"""
from __future__ import annotations
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional

import numpy as np
import pandas as pd

import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import data_provider
from config import (
    MIN_OPEN_INTEREST, MIN_DAILY_VOLUME, MAX_BID_ASK_SPREAD_PCT,
    MIN_OPTION_PRICE, MIN_DTE, MAX_DTE, RISK_FREE_RATE_DEFAULT,
    WORKERS_MISPRICING,
)
from utils import bs_price, bs_implied_vol, bs_delta, retry, safe, safe_int, safe_float

log = logging.getLogger("optedge.mispricing")


# -------- Helpers ------------------------------------------------------
def _historical_vol(close: pd.Series, n: int) -> Optional[float]:
    if close is None or len(close) < n + 1:
        return None
    rets = np.log(close / close.shift(1)).dropna().tail(n)
    if rets.empty:
        return None
    return float(rets.std() * np.sqrt(252))


def _years_to_expiry(expiry_str: str, asof: datetime) -> float:
    try:
        exp = datetime.strptime(expiry_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        days = (exp - asof).total_seconds() / 86400
        return max(days / 365.25, 1 / 365.25)
    except Exception:
        return 0.0


def _fetch_blob(ticker: str) -> Dict[str, Any]:
    """Pull spot, HV stats, dividend yield, and chain in DTE window."""
    chain_data = data_provider.get_options_chain(ticker)
    if not chain_data or not chain_data.get("expirations"):
        return {}

    spot = chain_data["spot"]
    div_yield = chain_data["div_yield"]

    # Historical vol — needs price history
    hist = data_provider.get_history(ticker, period="1y", interval="1d")
    close = hist["Close"] if not hist.empty else pd.Series(dtype=float)
    hv30 = _historical_vol(close, 30) or 0.30
    hv60 = _historical_vol(close, 60) or hv30
    hv252 = _historical_vol(close, 252) or hv30

    asof = datetime.now(timezone.utc)
    chains = []
    for exp, df in chain_data["chains"].items():
        T = _years_to_expiry(exp, asof)
        dte = T * 365.25
        if dte < MIN_DTE or dte > MAX_DTE:
            continue
        df = df.copy()
        df["expiry"] = exp
        df["dte"] = dte
        df["T"] = T
        chains.append(df)

    if not chains:
        return {}

    chain_df = pd.concat(chains, ignore_index=True)
    return {
        "ticker": ticker,
        "spot": spot,
        "hv30": hv30,
        "hv60": hv60,
        "hv252": hv252,
        "div_yield": div_yield,
        "chain": chain_df,
    }


def _enrich_chain(blob: Dict[str, Any], r: float = RISK_FREE_RATE_DEFAULT) -> pd.DataFrame:
    """Compute theoretical price, IV, mispricing, liquidity flags."""
    if not blob:
        return pd.DataFrame()
    df = blob["chain"]
    spot = blob["spot"]
    q = blob["div_yield"]
    hv30 = blob["hv30"]

    out_rows = []
    bad_rows = 0
    for _, row in df.iterrows():
        try:
            bid = safe_float(row.get("bid"))
            ask = safe_float(row.get("ask"))
            last = safe_float(row.get("lastPrice"))
            if bid > 0 and ask > 0 and ask >= bid:
                mid = (bid + ask) / 2
                spread = (ask - bid) / mid if mid > 0 else 1.0
            else:
                mid = last
                spread = 1.0  # treat as untradeable
            if mid < MIN_OPTION_PRICE:
                continue

            is_call = row["side"] == "call"
            T = safe_float(row.get("T"))
            K = safe_float(row.get("strike"))
            if T <= 0 or K <= 0:
                continue
            oi = safe_int(row.get("openInterest"))
            vol = safe_int(row.get("volume"))

            iv_market = bs_implied_vol(mid, spot, K, T, r, q, call=is_call)
            if iv_market is None or iv_market <= 0:
                continue

            fair_vol = hv30
            theo = bs_price(spot, K, T, r, fair_vol, q, call=is_call)
            delta = bs_delta(spot, K, T, r, iv_market, q, call=is_call)

            mispricing_dollar = mid - theo
            mispricing_pct = (mid - theo) / theo if theo > 0 else 0.0
            vol_premium = iv_market - fair_vol

            out_rows.append({
                "ticker": blob["ticker"],
                "expiry": row["expiry"],
                "dte": safe_int(row.get("dte")),
                "side": row["side"],
                "strike": K,
                "spot": spot,
                "bid": bid,
                "ask": ask,
                "mid": mid,
                "last": last,
                "spread_pct": spread,
                "open_interest": oi,
                "volume": vol,
                "iv_market": iv_market,
                "fair_vol": fair_vol,
                "vol_premium": vol_premium,
                "theo_price": theo,
                "mispricing_dollar": mispricing_dollar,
                "mispricing_pct": mispricing_pct,
                "delta": delta,
                "moneyness": K / spot,
            })
        except Exception as e:
            bad_rows += 1
            log.debug("skip bad row in %s: %s", blob.get("ticker"), e)
            continue
    if bad_rows:
        log.debug("%s: skipped %d malformed rows", blob.get("ticker"), bad_rows)
    return pd.DataFrame(out_rows)


def _apply_filters(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    f = df[
        (df["open_interest"] >= MIN_OPEN_INTEREST) &
        (df["volume"] >= MIN_DAILY_VOLUME) &
        (df["spread_pct"] <= MAX_BID_ASK_SPREAD_PCT) &
        (df["mid"] >= MIN_OPTION_PRICE)
    ].copy()
    return f


def _per_ticker_summary(df: pd.DataFrame, blob: Dict[str, Any]) -> Dict[str, Any]:
    if df.empty:
        return {}

    # Skew: 25-delta put vs 25-delta call IV (front-month)
    front = df[df["dte"] == df["dte"].min()].copy()
    skew_25d = None
    if not front.empty:
        calls = front[front["side"] == "call"]
        puts = front[front["side"] == "put"]
        if not calls.empty and not puts.empty:
            call25 = calls.iloc[(calls["delta"] - 0.25).abs().argsort()[:1]]
            put25 = puts.iloc[(puts["delta"] + 0.25).abs().argsort()[:1]]
            if not call25.empty and not put25.empty:
                skew_25d = float(put25["iv_market"].iloc[0] - call25["iv_market"].iloc[0])

    # Term structure: front ATM IV vs back ATM IV
    term_slope = None
    front_atm = front[(front["side"] == "call")]
    if not front_atm.empty:
        front_atm = front_atm.iloc[(front_atm["moneyness"] - 1).abs().argsort()[:1]]
    back = df[df["dte"] == df["dte"].max()]
    back_atm = back[back["side"] == "call"]
    if not back_atm.empty:
        back_atm = back_atm.iloc[(back_atm["moneyness"] - 1).abs().argsort()[:1]]
    if not front_atm.empty and not back_atm.empty:
        term_slope = float(back_atm["iv_market"].iloc[0] - front_atm["iv_market"].iloc[0])

    iv_rank = 50.0
    hv30 = blob["hv30"]
    hv252 = blob["hv252"]
    if hv252 > 0:
        ratio = hv30 / hv252
        iv_rank = float(min(100, max(0, 50 + (ratio - 1) * 100)))

    return {
        "ticker": blob["ticker"],
        "spot": blob["spot"],
        "hv30": blob["hv30"],
        "hv252": blob["hv252"],
        "iv_rank": iv_rank,
        "skew_25d": skew_25d,
        "term_slope": term_slope,
    }


def _process_ticker(t: str) -> Dict[str, Any]:
    """One ticker → {filtered_contracts: DataFrame|None, summary: dict|None}."""
    try:
        blob = _fetch_blob(t)
        if not blob:
            return {"filtered": None, "summary": None}
        enriched = _enrich_chain(blob)
        filtered = _apply_filters(enriched)
        return {"filtered": filtered if not filtered.empty else None,
                "summary": _per_ticker_summary(enriched, blob)}
    except Exception as e:
        log.warning("mispricing fail %s: %s", t, str(e)[:120])
        return {"filtered": None, "summary": None, "error": str(e)[:120]}


def run(universe: List[str], max_workers: int = None) -> Dict[str, Any]:
    """Parallel per-ticker processing. yfinance is rate-sensitive, so keep
    workers low (default 6)."""
    workers = max_workers or WORKERS_MISPRICING
    rows = []
    summaries = []
    failures = 0
    completed = 0
    log.info("fetching chains for %d tickers (parallel, %d workers)",
             len(universe), workers)

    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = {ex.submit(_process_ticker, t): t for t in universe}
        for fut in as_completed(futures):
            t = futures[fut]
            try:
                r = fut.result()
                if r.get("error"):
                    failures += 1
                if r.get("filtered") is not None:
                    rows.append(r["filtered"])
                if r.get("summary"):
                    summaries.append(r["summary"])
            except Exception as e:
                failures += 1
                log.warning("mispricing worker fail %s: %s", t, str(e)[:120])
            completed += 1
            if completed % 25 == 0 or completed == len(universe):
                log.info("[%d/%d]", completed, len(universe))

    if failures > len(universe) * 0.5:
        log.error("MORE THAN HALF the tickers failed (%d/%d). Yahoo may be rate-limiting "
                  "your IP. Wait 15 min and retry, or use --demo, or run setup_check.py.",
                  failures, len(universe))

    contracts = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()
    summary = pd.DataFrame([s for s in summaries if s])
    return {"contracts": contracts, "summary": summary}
