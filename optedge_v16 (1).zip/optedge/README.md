# Optedge — Free Self-Improving Quant Cockpit (v16)

Multi-factor screener that ranks **long calls**, **long puts**, **small-cap shares**, **value plays**, and **futures** using free public data. Auto-retrains weights per trade type from realized P&L. Sizes positions via Kelly. Auto-opens an interactive dashboard. **Run all day with `--loop`.**

### What's new in v16

- **Earnings panel collapsible** — click the arrow to expand/collapse; default closed. Saves a ton of vertical scroll.
- **Multi-factor self-learning futures** — futures cards now use *every* signal optedge already pulls (sentiment, news, congress, earnings, social, macro, FRED), mapped per-asset-class. Equity index uses top-30 SPY/QQQ component sentiment + Trump posts on Fed; metals use DXY-inverse + real-yields; energy uses OPEC/Russia/Iran news + Trump on energy; crypto uses crypto-subreddit sentiment + risk-on macro flag.
- **Real recommended-trade tickets** — micro-contract default (MES, MNQ, MYM, M2K, MGC, SIL, MCL, MNG, MBT, MET) sized to your bankroll, ATR-based stops (1.5×/2.0× ATR14), explicit entry / stop / target with $ risk, $ reward, R:R, margin %.
- **Self-learning across the whole stack** — options, shares, and 7 futures asset classes each have their own weight bucket that auto-tunes via Lasso refit (≥50 outcomes) or IC bootstrap (≥20 outcomes). Per-bucket files in `data/weights/{bucket}.json`. Buckets: `options_call`, `options_put`, `shares_long`, `futures_equity`, `futures_treasury`, `futures_metal`, `futures_energy`, `futures_crypto`, `futures_currency`, `futures_agri`.
- **Walk-forward backtest module** — out-of-sample stats per bucket: win rate, profit factor, Sharpe, max DD, equity curve, top-factor PnL attribution. Persists `data/backtest_summary.json` each cycle.
- **Forward-test extended** — explicit cohort tracking, target/stop/time-stop replay matching the actual trade tickets, rolling 30/60/90d hit rate per bucket.
- **3 new dashboard panels** — 🧠 Self-Learning Status, 📊 Backtest, 🔬 Forward Test (all collapsible). See exactly which factors are working per bucket and how the live model is evolving over time.

**Files preserved across upgrade** (extract v16 zip over your existing folder): `config_runtime.py`, `data/predictor_coefs.json`, `data/last_ic.parquet`, `data/weights/*.json`, `data/backtest_summary.json`, `data/forward_test_status.parquet`, `data/forward_outcomes_*.parquet`, `logs/signals_*.parquet`, `logs/futures_signals_*.parquet`, `keys.py`, `data/_cache/`.

## ⚡ One-time setup (Windows)

Double-click **`install.bat`**. It auto-detects Python 3.13/3.12 (refuses 3.14 since wheels aren't ready), creates a venv, installs deps, runs setup_check.

Or manually:
```bash
python -m venv venv && venv\Scripts\activate
pip install -r requirements.txt
python setup_check.py
```

## ⚡ Daily use

```bash
# Single run, auto-opens dashboard
python run.py

# AGGRESSIVE mode — ½ Kelly, 10% per option / 15% per share caps
python run.py --aggressive

# Run all day — auto-refresh every 30 minutes
python run.py --aggressive --bankroll 25000 --loop 30

# Continuous + skip slow engines (fastest loop)
python run.py --loop 15 --fast-insider --skip-wsb --aggressive
```

In loop mode, the dashboard opens once on iteration 1 and refreshes every cycle (just reload the browser tab). Logs accumulate in `logs/` so the auto-retrain gets smarter every day. Ctrl+C anytime to stop.

## What you get on every run

| Section | What's there |
|---|---|
| **Macro banner** | Regime (risk-on / off / neutral), VIX, 10Y-3M slope, SPY 3M |
| **Stats panel** | Run time, universe size, idea counts |
| **News flow** | Top headlines by velocity × Δsentiment |
| **Earnings calendar** | Next 14 days of earnings + last surprise |
| **Performance Tracking** | Win rate, avg P&L, by-confidence stats from prior runs |
| **Insider heatmap** | Top buyers / sellers from real SEC EDGAR data |
| **WSB trending** | Live-discovered tickers from Reddit |
| **Long Calls** | Cheap calls aligned with bullish multi-factor stack |
| **Long Puts** | Cheap puts aligned with bearish multi-factor stack |
| **Long Shares** | Small-caps where options aren't liquid |
| **💎 Value Plays** | Magic Formula + Graham composite cheap & quality |
| **📈 Futures** | /ES /NQ /GC /CL /BTC etc. with momentum + range pos |
| **Ranked tables** | Full snapshots, all ideas |
| **TradingView watchlist** | Importable file |
| **Methodology appendix** | All weights + thresholds explained |

Every card shows:
- Confidence (0-100, fused 10-factor score)
- Predicted % return (from auto-retrained Lasso predictor)
- EV % (predictor's expected value)
- ¼ or ½ Kelly % of bankroll
- Suggested $ allocation + contract count
- 🛑 Stop trigger / 🎯 Target trigger
- Why (multi-factor reasoning) + Risks

## Interactive controls

The sticky control bar lets you in real-time:
- 🔍 **Search** — type a ticker, only its cards show
- **Sort** — by rank / confidence / predicted / EV / Kelly / ticker A-Z
- **Filter chips** — calls only, puts only, shares only, conf ≥ 70, EV > 0, Kelly > 0
- **Live counter** shows visible-card count

## Self-improvement loop

```
Daily run → logs signals → forward test re-prices old signals → Lasso refit on
realized P&L → updates config_runtime.py (overrides default weights) →
predictor coefs updated → next run uses fresh weights and predicted returns
```

After 30 days of `--loop` running you'll have **~10,000+ logged signals** and the Lasso refit will replace the IC-bootstrap with actual P&L-derived weights.

## Free data sources

| Engine | Source | Auth |
|---|---|---|
| Options chains, prices, fundamentals, futures | yfinance | none |
| Sentiment + WSB trending | Reddit public JSON | none |
| Insider | SEC EDGAR Form 4 | none |
| News | Google News RSS | none |
| Macro | yfinance + optional FRED | FRED key optional, free |

## Sizing math (the important part)

**Default** (¼ Kelly): conservative, ~75% of long-run growth with half the drawdown.
- Per-option cap: 5% of bankroll
- Per-share cap: 8% of bankroll
- Total options cap: 30% of bankroll

**Aggressive** (½ Kelly with `--aggressive`): faster compounding, ~3x bigger drawdowns.
- Per-option cap: 10% of bankroll
- Per-share cap: 15% of bankroll
- Total options cap: 60% of bankroll

Negative Kelly = predictor disagrees with rank → marked as **skip** on the dashboard. Don't override.

## Exit triggers

Built into every card so you have a complete plan before entering:

**Options:**
- 🛑 Stop = 50% of entry price (max 50% loss)
- 🎯 Target = 200% of entry price (double = exit half, let rest run)

**Shares:**
- 🛑 Stop = -8% (default) / -10% (aggressive)
- 🎯 Target = +20% (default) / +30% (aggressive)

These are starting heuristics — adjust in `backtest/sizing.py` to match your style.

## Common workflows

```bash
# Pure overnight setup: kick this off and walk away
python run.py --loop 60 --aggressive --bankroll 20000

# Pre-market scan (fast)
python run.py --fast-insider --skip-wsb --skip-news

# After-hours research mode (full universe, no rush)
python run.py --max-calls 30 --max-puts 20

# One-time IC backtest (run once a week)
python run.py --backtest

# Forward test summary (after several days of logs)
python run.py --forward
```

## Troubleshooting

### `python run.py` exits silently

Make sure `run.py` is the v10 version — first thing it prints is "Optedge starting…". If you see nothing, re-extract from the v10 zip.

### Yahoo rate-limit (429)

Common from datacenter / VPN IPs. Wait 15-30 min, ensure you're not on a VPN, or use `--demo` while you sort it.

### Reddit 403

System auto-skips sentiment when blocked. No action needed.

### Loop mode opens 50 browser tabs

Bug — fixed in v10. Each loop iteration sets `OPTEDGE_NO_OPEN=1` after the first open.

### Want to revert auto-retrained weights

Delete `config_runtime.py`. The system will recreate it next run.

## Architecture

```
optedge/
├── install.bat / install.sh   ← one-click setup
├── setup_check.py             ← health check
├── config.py                  ← universe, weights, filters
├── utils.py                   ← BS pricing, NaN-safe primitives
├── data_provider.py           ← curl_cffi wrapper + disk cache
├── run.py                     ← orchestrator (with --loop)
├── demo_data.py               ← synthetic fallback
├── engines/
│   ├── mispricing.py          ← BS + Brent IV solver
│   ├── sentiment.py           ← Reddit + VADER
│   ├── fundamentals.py        ← yfinance fundamentals
│   ├── insider.py             ← SEC EDGAR Form 4
│   ├── macro.py               ← VIX + yields + regime
│   ├── wsb_trending.py        ← live ticker discovery
│   ├── news.py                ← Google News RSS + VADER
│   ├── earnings.py            ← calendar + EPS surprise
│   ├── value.py               ← Magic Formula + Graham
│   └── futures.py             ← /ES /NQ /GC /CL /BTC etc.
├── fusion/
│   └── rank.py                ← 10-factor weighted fusion
├── backtest/
│   ├── track.py               ← signal log + LassoCV retrain
│   ├── forward.py             ← replay logged signals → realized P&L
│   ├── historical.py          ← IC analysis
│   ├── predictor.py           ← Lasso predictor + auto-retrain
│   └── sizing.py              ← EV + Kelly + exit triggers
└── dashboard/
    └── build.py               ← interactive HTML cockpit
```

## Philosophy

- **Long-only**: cheap directional optionality + multi-factor confirmation
- **Confluence over single signals**: 10 factors must roughly agree
- **Diversity**: max one option idea per ticker
- **Self-improvement**: weights + predictions retrain from your own log
- **Explainable**: every trade has reasoning + risks + exit triggers
- **Free**: every data source is free, no paywalls
- **Aggressive optional**: ½ Kelly when you want it

Not investment advice. Trade options at your own risk.
