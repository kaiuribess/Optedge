"""Optedge — config & shared constants."""
from datetime import datetime, timezone

# ---- Universe ----------------------------------------------------------
# Wide coverage. Pulled from S&P 500 + Russell 2000 popular constituents +
# WSB trending names. WSB trending is added DYNAMICALLY at runtime.

LARGE_CAPS = [
    # ETFs
    "SPY", "QQQ", "IWM", "DIA", "ARKK", "ARKG", "ARKW", "XLF", "XLE", "XLK",
    "XLV", "XLY", "XLU", "XLI", "XLP", "XLB", "XLRE", "XOP", "GDX", "SLV",
    "GLD", "TLT", "HYG", "LQD", "EEM", "EFA", "VEA", "VWO",
    # Mega tech
    "AAPL", "MSFT", "NVDA", "AMZN", "GOOGL", "GOOG", "META", "TSLA", "AVGO", "ORCL",
    # Large tech / semis / cloud
    "AMD", "INTC", "NFLX", "CRM", "ADBE", "CSCO", "IBM", "QCOM", "TXN", "MU",
    "NOW", "INTU", "PANW", "ANET", "ADI", "LRCX", "KLAC", "MRVL", "ON", "MCHP",
    "AMAT", "ASML", "TSM",
    "SNOW", "CRWD", "NET", "MDB", "DDOG", "WDAY", "SHOP", "TEAM", "ZS", "OKTA",
    "DOCU", "TWLO", "ZM", "FSLY", "DOCN",
    # Banks / fintech
    "JPM", "BAC", "WFC", "C", "GS", "MS", "USB", "PNC", "SCHW", "COF",
    "AXP", "V", "MA", "PYPL", "BLK", "BX", "KKR", "TROW", "STT", "BK",
    # Insurers
    "MET", "PRU", "AFL", "ALL", "TRV", "CB", "AIG",
    # Energy
    "XOM", "CVX", "COP", "OXY", "EOG", "SLB", "MPC", "VLO", "PSX", "HAL",
    "FANG", "DVN", "PXD", "BKR", "WMB", "KMI", "ENB", "ET",
    # Industrials
    "BA", "CAT", "DE", "HON", "GE", "MMM", "RTX", "LMT", "NOC", "GD",
    "UPS", "FDX", "EMR", "ETN", "ITW", "PH", "ROK", "JCI", "CMI", "PCAR",
    "CSX", "NSC", "UNP", "WM", "RSG",
    # Consumer (staples + discretionary)
    "WMT", "COST", "TGT", "HD", "LOW", "NKE", "SBUX", "MCD", "KO", "PEP",
    "PG", "CL", "KMB", "MO", "PM", "EL", "CHD", "CLX", "GIS",
    "DG", "DLTR", "BBY", "TJX", "ROST", "ULTA", "LULU", "DECK",
    "YUM", "CMG", "QSR", "DPZ",
    # Healthcare / pharma / biotech (large)
    "UNH", "LLY", "JNJ", "PFE", "MRK", "ABBV", "BMY", "GILD", "AMGN", "MDT",
    "TMO", "DHR", "CVS", "ABT", "ISRG", "REGN", "VRTX", "BIIB", "ZTS", "BSX",
    "EW", "CI", "ELV", "HCA", "HUM",
    # Auto (large)
    "F", "GM", "TM", "STLA",
    # Travel / hospitality
    "DAL", "AAL", "UAL", "LUV", "BKNG", "ABNB", "MAR", "HLT", "MGM", "WYNN",
    "LVS", "CCL", "RCL", "NCLH",
    # Telecom / media
    "T", "VZ", "TMUS", "CMCSA", "DIS", "WBD", "NFLX", "PARA", "FOX", "FOXA",
    # Real estate
    "AMT", "EQIX", "PLD", "SPG", "O", "CCI", "PSA", "SBAC", "DLR", "VICI",
    # Materials / chemicals
    "LIN", "APD", "SHW", "ECL", "FCX", "NEM", "AA", "X", "CLF", "STLD", "NUE",
]

SMALL_MID_CAPS_OPTIONS = [
    # Speculative growth / fintech / consumer tech
    "PLTR", "SOFI", "HOOD", "COIN", "AFRM", "UPST", "RBLX", "U", "PINS", "SNAP",
    "DASH", "UBER", "LYFT", "ABNB", "BMBL", "MTCH", "RIVN", "LCID",
    # Crypto-adjacent
    "MARA", "RIOT", "CLSK", "MSTR", "HUT", "WULF", "CIFR", "CORZ", "BITF", "HIVE",
    "GBTC", "IBIT", "ETHA", "BITO",
    # AI / data / quantum
    "SMCI", "IONQ", "RGTI", "QBTS", "QUBT", "ARQQ", "AI", "PATH", "BBAI", "SOUN",
    "VRNT", "DOMO", "CXM", "GTLB",
    # New space / mobility
    "ASTS", "JOBY", "ACHR", "LUNR", "RKLB", "BLDE", "SPCE", "EVTL", "GOEV",
    # Cannabis
    "TLRY", "CGC", "CRON", "ACB", "CURLF", "TCNNF", "GTBIF", "TRUL", "CRLBF", "GRWG",
    # Meme / retail favourites
    "GME", "AMC", "BB", "BBBY", "KOSS", "EXPR", "ATER", "PRTY", "REV",
    # Chinese ADRs
    "BABA", "JD", "PDD", "BIDU", "NIO", "XPEV", "LI", "TME", "BILI", "NTES",
    "WB", "TAL", "EDU", "DIDI",
    # EV / auto (small)
    "NKLA", "FSR", "MULN", "FFIE", "LCID",
    # Solar / clean energy
    "ENPH", "FSLR", "RUN", "SHLS", "ARRY", "PLUG", "BLDP", "BE", "FCEL", "BEEM",
    "MAXN", "STEM", "NRGV", "NOVA",
    # Healthcare / biotech (mid)
    "MRNA", "BNTX", "NVAX", "OCGN", "VKTX", "SAVA", "SRPT", "BLUE", "FATE",
    "CRSP", "EDIT", "NTLA", "BEAM", "VRTX", "REGN",
    # Streaming / media (small)
    "ROKU", "SPOT", "FUBO", "SIRI",
    # Sports betting / gaming
    "DKNG", "PENN", "FLUT",
    # Other consumer tech
    "CHWY", "ETSY", "PTON", "BYND", "WBA", "OPEN",
    # Insurance disruptors
    "ROOT", "LMND", "OSCR",
    # Niche tech
    "BAND", "FSLY", "APP", "INTA", "FROG", "CFLT", "GRAB",
    # Semis (small)
    "AEHR", "VECO", "WOLF", "ALGM", "ICHR", "CRDO", "AEIS",
    # Industrial specialty
    "NPO", "ESE", "ROCK",
    # 3D printing
    "DDD", "SSYS", "MTLS", "VLD",
    # Other speculative
    "BBAI", "PHUN", "SPRT", "BFRG", "AXTI", "INDI",
]

SMALL_CAPS_SHARES = [
    # Small biotech
    "TVTX", "AKBA", "VANI", "ANIP", "PRTA", "CRDF", "IOVA", "EDIT", "NTLA",
    "BEAM", "BLUE", "FATE", "ARWR", "HALO", "EXEL", "INSM",
    # Small fintech / consumer
    "OPFI", "PAYO", "ENVA", "WRBY", "FTCH", "REAL", "VRT", "CART", "INST",
    # Small industrials / specialty
    "TILE", "ATR", "GFF", "AEIS", "CRS", "ALSN", "SPXC",
    # Small energy / mining
    "MP", "ALB", "URA", "UEC", "CCJ", "SBSW", "HL", "AG", "EXK", "PAAS",
    "NEM", "GOLD", "HMY", "BTG", "AU", "RGLD", "WPM", "EQX", "FNV",
    "NXE", "DNN", "URG", "LEU",
    # Quantum / AI / sci-fi
    "QUBT", "ARQQ", "INVZ", "OUST", "CGNT", "IRDM",
    # Niche tech
    "DOCN", "BAND", "FSLY", "APP", "INTA", "FROG", "GTLB",
    # Small EV / mobility
    "EVTL", "GOEV", "FSR", "MULN", "ZEV", "NUVB",
    # Small mining / commodities
    "FCEL", "BEEM", "GEVO", "MNTV",
    # Other speculative growth
    "SDIG", "BTBT", "BITF", "HIVE", "GBTC", "PRPL", "AOUT",
    "GENI", "PHUN", "SPRT", "ATER", "REV", "PRTY", "EXPR",
    "BFRG", "NUKK", "AXTI", "INDI", "MTLS",
    # Healthcare / cannabis
    "GTBIF", "TCNNF", "CURLF", "TRUL", "CRLBF", "GRWG",
    # Solar / battery / energy storage small
    "SHLS", "MAXN", "BWXT", "SMR", "OKLO",
    # Misc fintech and software
    "WULF", "BTG", "HUT", "LXRX", "SAVA", "VKTX",
    # Small space / aerospace
    "MNTS", "ASTL", "PLNT", "HLNE", "BMRC",
    # Cybersecurity small
    "S", "TENB", "RPD", "QLYS",
    # Misc growth
    "TWST", "GH", "LRN", "CDLX", "GDOT", "WK",
]

UNIVERSE_OPTIONS = list(dict.fromkeys(LARGE_CAPS + SMALL_MID_CAPS_OPTIONS))
UNIVERSE_SHARES = list(dict.fromkeys(SMALL_MID_CAPS_OPTIONS + SMALL_CAPS_SHARES))
UNIVERSE = list(dict.fromkeys(UNIVERSE_OPTIONS + UNIVERSE_SHARES))

# ---- WSB trending discovery -------------------------------------------
WSB_TRENDING_TOP_N = 30        # extra tickers added at runtime
WSB_TRENDING_MIN_MENTIONS = 3  # threshold to be considered "trending"

# ---- Risk / liquidity floors ------------------------------------------
MIN_OPEN_INTEREST = 100
MIN_DAILY_VOLUME = 25
MAX_BID_ASK_SPREAD_PCT = 0.15
MIN_OPTION_PRICE = 0.10
MIN_DTE = 14
MAX_DTE = 60

# ---- Pricing ----------------------------------------------------------
RISK_FREE_RATE_DEFAULT = 0.045

# ---- Sentiment --------------------------------------------------------
SUBREDDITS = ["wallstreetbets", "stocks", "investing", "options", "smallstreetbets"]
SENTIMENT_LOOKBACK_HOURS = 48
USER_AGENT = "optedge-research/0.1 (research@optedge.local)"

# ---- Insider ----------------------------------------------------------
INSIDER_LOOKBACK_DAYS = 90
INSIDER_PRIORITY_TITLES = {"CEO", "CFO", "COO", "PRES", "CHAIRMAN", "DIR", "10%"}
INSIDER_MAX_FILINGS_PER_TICKER = 6    # tight cap = much faster; covers most active names
INSIDER_FAST_MODE = False              # if True, skip XML parsing and use Form 4 counts only

# ---- News (Google News RSS, no key needed) ----------------------------
NEWS_LOOKBACK_DAYS = 7
NEWS_MAX_HEADLINES_PER_TICKER = 30

# ---- Earnings ---------------------------------------------------------
EARNINGS_LOOKAHEAD_DAYS = 30           # how far out to consider for catalyst boosts

# ---- Concurrency ------------------------------------------------------
# Per-engine worker pool. yfinance is more rate-sensitive — keep this lower.
WORKERS_MISPRICING = 6
WORKERS_FUNDAMENTALS = 8
WORKERS_INSIDER = 16                   # SEC tolerates ~10 req/sec; 16 concurrent ≈ 8/sec
WORKERS_NEWS = 8
WORKERS_EARNINGS = 6
WORKERS_VALUE = 8
WORKERS_FUTURES = 6
WORKERS_CONGRESS = 1
WORKERS_SOCIAL = 6
WORKERS_ANALYST = 6    # Finnhub: 60/min limit, capped here for headroom

# ---- Congress -----------------------------------------------------
CONGRESS_LOOKBACK_DAYS = 90

# ---- Social (StockTwits + Trump Truth Social) ---------------------
SOCIAL_TOP_ST_TICKERS = 30   # how many tickers to query StockTwits for per run
ENGINE_CONCURRENT = True   # run all engines in parallel

# ---- Macro / regime ---------------------------------------------------
VIX_RISK_OFF = 25.0
VIX_RISK_ON = 15.0

# ---- Fusion -----------------------------------------------------------
SIGNAL_WEIGHTS = {
    "mispricing":   0.13,
    "iv_rank":      0.05,
    "skew":         0.04,
    "sentiment_d":  0.10,
    "fundamentals": 0.08,
    "insider":      0.08,
    "macro":        0.07,    # boosted with FRED data
    "news":         0.08,
    "earnings":     0.08,
    "value":        0.10,
    "congress":     0.06,    # paid-tier only, often 0 — kept low
    "social":       0.05,
    "analyst":      0.08,    # Finnhub analyst recommendations momentum
}

# ---- Analyst (Finnhub) -----------------------------------------------
ANALYST_TOP_N = 80   # query Finnhub for top N tickers

# ---- Value / futures --------------------------------------------------
TOP_N_VALUE = 12        # value plays shown on dashboard
TOP_N_FUTURES = 10      # futures plays shown on dashboard

# ---- Output -----------------------------------------------------------
TOP_N_CALLS = 15
TOP_N_PUTS = 10
TOP_N_SHARES = 15
MAX_PER_TICKER = 1
SHARES_MIN_SCORE = 0.6

ASOF = datetime.now(timezone.utc)
