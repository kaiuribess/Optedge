"""Expected Value (EV) + Kelly Criterion position sizing.

Two related calculations per trade:

  1. **EV (% and $)** — what's the expected outcome of this trade?
     Long option (binary-ish):
       prob_win = |delta|  (proxy for P(ITM) at expiration)
       avg_win  = pred_option_return_pct (from the trained predictor)
       avg_loss = -1.0  (worst case: option expires worthless)
       ev_pct   = prob_win × avg_win + (1 - prob_win) × avg_loss
       ev_dollar = ev_pct × premium × 100  (per contract)

     Long shares:
       ev_pct = pred_stock_return_pct   (predictor — already a probability-weighted mean)
       ev_dollar = ev_pct × spot × shares

  2. **Kelly fraction** — what % of bankroll to risk?
     Standard Kelly: f* = (b·p - q) / b
       p = prob of profit
       q = 1 - p
       b = avg_win / avg_loss  (payoff ratio)
     We always use **quarter Kelly** (× 0.25) per the research consensus.
     Hard cap at 5% per option trade and 8% per share trade — single-trade risk limit.

Reference: research from FlashAlpha, Option Alpha, IntraAlpha — fractional Kelly
is the consensus approach for retail traders to avoid drawdowns.
"""
from __future__ import annotations
import math
import logging
from typing import Dict, Any, Tuple

import numpy as np
import pandas as pd

log = logging.getLogger("optedge.sizing")

# Kelly fraction multipliers. Default = conservative quarter Kelly.
# Aggressive mode = half Kelly + larger caps + bigger total exposure.
KELLY_FRACTION = 0.25
MAX_PER_OPTION_TRADE = 0.05
MAX_PER_SHARE_TRADE  = 0.08
TOTAL_OPTIONS_CAP    = 0.30

# Aggressive overrides — set when --aggressive flag is passed
KELLY_FRACTION_AGGRESSIVE = 0.50
MAX_PER_OPTION_TRADE_AGGRESSIVE = 0.10
MAX_PER_SHARE_TRADE_AGGRESSIVE  = 0.15
TOTAL_OPTIONS_CAP_AGGRESSIVE    = 0.60

DEFAULT_BANKROLL = 10_000


def get_sizing_params(aggressive: bool = False):
    """Return (kelly_fraction, max_option_pct, max_share_pct, total_cap)."""
    if aggressive:
        return (KELLY_FRACTION_AGGRESSIVE, MAX_PER_OPTION_TRADE_AGGRESSIVE,
                MAX_PER_SHARE_TRADE_AGGRESSIVE, TOTAL_OPTIONS_CAP_AGGRESSIVE)
    return (KELLY_FRACTION, MAX_PER_OPTION_TRADE,
            MAX_PER_SHARE_TRADE, TOTAL_OPTIONS_CAP)


def compute_option_ev_and_kelly(row: pd.Series, aggressive: bool = False) -> Dict[str, float]:
    """Per-row EV and Kelly fraction for a long option."""
    pred_raw = row.get("pred_option_return_pct")
    has_prediction = pred_raw is not None and not (isinstance(pred_raw, float) and math.isnan(pred_raw))
    pred = float(pred_raw or 0)
    delta = float(row.get("delta") or 0.5)
    mid = float(row.get("mid") or 0)
    prob_win = max(0.10, min(0.90, abs(delta)))

    if mid <= 0 or not has_prediction:
        return {"ev_pct": float("nan"), "ev_dollar_per_contract": float("nan"),
                "kelly_full": float("nan"), "kelly_pct": float("nan"),
                "prob_win": prob_win}

    # EV = predictor's expected return directly (already a probability-weighted mean).
    ev_pct = pred
    ev_dollar = ev_pct * mid * 100

    if pred <= 0:
        # Predictor disagrees with the rank — skip (Kelly = 0)
        return {"ev_pct": ev_pct, "ev_dollar_per_contract": ev_dollar,
                "kelly_full": 0.0, "kelly_pct": 0.0, "prob_win": prob_win}

    # Kelly with realistic option payoff assumptions:
    # - Winners average ~2x the predicted size (or 50% min, whichever is larger)
    # - Losers average 60% loss (mix of partial losses + theta + full losses)
    avg_win = max(0.50, abs(pred) * 2)
    avg_loss = 0.60
    b = avg_win / avg_loss
    p = prob_win
    q = 1 - p
    kelly_full = max(0.0, (b * p - q) / b)
    frac, cap, _, _ = get_sizing_params(aggressive)
    kelly_quarter = min(kelly_full * frac, cap)

    return {
        "ev_pct": ev_pct,
        "ev_dollar_per_contract": ev_dollar,
        "kelly_full": kelly_full,
        "kelly_pct": kelly_quarter,
        "prob_win": prob_win,
    }


def compute_share_ev_and_kelly(row: pd.Series, hv_proxy: float = 0.30,
                                aggressive: bool = False) -> Dict[str, float]:
    """Per-row EV and Kelly fraction for a long share buy."""
    pred_raw = row.get("pred_stock_return_pct")
    has_prediction = pred_raw is not None and not (isinstance(pred_raw, float) and math.isnan(pred_raw))
    if not has_prediction:
        return {"ev_pct": float("nan"), "kelly_full": float("nan"), "kelly_pct": float("nan")}
    pred = float(pred_raw or 0)
    if pred <= 0:
        return {"ev_pct": pred, "kelly_full": 0.0, "kelly_pct": 0.0}

    # For shares, use a more graceful loss model: realized vol acts as the std-dev
    # of outcomes. Average loser ~ 1×hv (one standard-deviation move down over the holding period).
    hv = hv_proxy   # default 30% annualized vol
    # Probability of profit estimated from predicted return / vol via normal approx
    prob_win = 0.5 + max(-0.4, min(0.4, pred / max(hv, 0.05)))
    avg_win = max(pred, hv * 0.5)                  # bullish baseline
    avg_loss = hv * 0.5                            # 0.5 sigma down move proxy

    ev_pct = prob_win * avg_win - (1 - prob_win) * avg_loss

    b = avg_win / avg_loss if avg_loss > 0 else 1.0
    kelly_full = (b * prob_win - (1 - prob_win)) / b
    kelly_full = max(0.0, kelly_full)
    frac, _, share_cap, _ = get_sizing_params(aggressive)
    kelly_quarter = min(kelly_full * frac, share_cap)

    return {
        "ev_pct": ev_pct,
        "kelly_full": kelly_full,
        "kelly_pct": kelly_quarter,
        "prob_win": prob_win,
    }


def add_sizing_to_options(df: pd.DataFrame, bankroll: float = DEFAULT_BANKROLL,
                            aggressive: bool = False) -> pd.DataFrame:
    """Compute EV + Kelly + suggested dollars + contract count + exit triggers."""
    if df is None or df.empty:
        return df
    out = df.copy()
    rows = [compute_option_ev_and_kelly(r, aggressive=aggressive) for _, r in out.iterrows()]
    res = pd.DataFrame(rows, index=out.index)
    out = pd.concat([out, res], axis=1)
    out["suggested_dollars"] = (out["kelly_pct"] * bankroll).round(0)
    cost_per_contract = (out["mid"].fillna(0) * 100).replace(0, np.nan)
    out["suggested_contracts"] = np.floor(out["suggested_dollars"] / cost_per_contract).fillna(0).astype(int)
    out["actual_dollars"] = out["suggested_contracts"] * cost_per_contract.fillna(0)
    # Exit triggers — simple, robust rules
    # Stop: option price drops to 50% of entry (lock max loss at -50%)
    # Target: option price reaches 100% gain (double = exit half, let rest run)
    out["stop_price"] = (out["mid"].fillna(0) * 0.50).round(2)
    out["target_price"] = (out["mid"].fillna(0) * 2.00).round(2)
    return out


def add_sizing_to_shares(df: pd.DataFrame, bankroll: float = DEFAULT_BANKROLL,
                          aggressive: bool = False) -> pd.DataFrame:
    """Compute EV + Kelly + suggested dollars + exit triggers for shares."""
    if df is None or df.empty:
        return df
    out = df.copy()
    rows = [compute_share_ev_and_kelly(r, aggressive=aggressive) for _, r in out.iterrows()]
    res = pd.DataFrame(rows, index=out.index)
    out = pd.concat([out, res], axis=1)
    out["suggested_dollars"] = (out["kelly_pct"] * bankroll).round(0)
    # Stop -8% from current, target +20% (aggressive: -10%/+30%)
    stop_pct = -0.10 if aggressive else -0.08
    target_pct = 0.30 if aggressive else 0.20
    out["stop_pct"] = stop_pct
    out["target_pct"] = target_pct
    return out
