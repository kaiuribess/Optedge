"""Return predictor + auto-retrain.

Two jobs:
  1. fit_return_predictor() — given historical price returns + factor z-scores,
     fit a Lasso regression that maps factor z's to expected forward return.
     Saves the coefficient vector to data/predictor_coefs.json.
  2. update_runtime_weights() — given forward test data (realized P&L) and
     backtest IC analysis, refits SIGNAL_WEIGHTS via Lasso and writes them
     to config_runtime.py (which run.py auto-loads if present).

Bootstrap path: when no forward-test data exists, seed the predictor from
the backtest IC × Q5-Q1 spread. The system is therefore calibrated FROM DAY
ONE — it doesn't need 30 days of logs to start predicting returns.
"""
from __future__ import annotations
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

import numpy as np
import pandas as pd

import sys
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

log = logging.getLogger("optedge.predictor")
COEFS_PATH = ROOT / "data" / "predictor_coefs.json"
LAST_IC_PATH = ROOT / "data" / "last_ic.parquet"
RUNTIME_CONFIG_PATH = ROOT / "config_runtime.py"


def cache_ic(ic_df: pd.DataFrame):
    """Persist the latest IC analysis so subsequent runs can use it as fallback."""
    if ic_df is None or ic_df.empty:
        return
    try:
        LAST_IC_PATH.parent.mkdir(exist_ok=True)
        ic_df.to_parquet(LAST_IC_PATH, index=False)
    except Exception as e:
        log.debug("failed to cache IC: %s", e)


def load_cached_ic() -> Optional[pd.DataFrame]:
    if not LAST_IC_PATH.exists():
        return None
    try:
        return pd.read_parquet(LAST_IC_PATH)
    except Exception:
        return None

# Default horizon for option-buying predictions (matches typical 14-30 DTE picks).
DEFAULT_HORIZON_DAYS = 14

# Z-score columns we predict from
Z_COLS = [
    "z_mispricing", "z_iv_rank", "z_skew",
    "z_sent", "z_fund", "z_insider",
    "z_macro", "z_news", "z_earnings", "z_value",
]

# Map factor name (used in IC) to its z-column in fusion output
FACTOR_TO_ZCOL = {
    "value_score":     "z_value",
    "fund_score":      "z_fund",
    "sentiment_delta": "z_sent",
    "insider_score":   "z_insider",
}


def _bootstrap_coefs_from_ic(ic_df: pd.DataFrame, horizon: int = DEFAULT_HORIZON_DAYS) -> Dict[str, float]:
    """Seed coefficients from backtest IC × Q5-Q1 spread when no forward data exists.

    Logic: a Q5-Q1 spread of S% spans roughly 4 z-units (top 20% mean ≈ +1.3z,
    bottom 20% mean ≈ -1.3z). So per-z-unit return ≈ S / 2.6.
    """
    if ic_df is None or ic_df.empty:
        return {c: 0.0 for c in Z_COLS}

    # Pick the closest horizon row available
    available = sorted(ic_df["horizon_days"].unique())
    target_h = min(available, key=lambda h: abs(h - horizon)) if available else horizon

    coefs: Dict[str, float] = {c: 0.0 for c in Z_COLS}
    sub = ic_df[ic_df["horizon_days"] == target_h]
    for _, r in sub.iterrows():
        zcol = FACTOR_TO_ZCOL.get(r["factor"])
        if zcol is None:
            continue
        # Scale: spread is total range; per-z-unit ≈ spread / 2.6
        coefs[zcol] = float(r["spread"]) / 2.6
    log.info("bootstrapped predictor coefs from IC at horizon %dd", target_h)
    return coefs


def _fit_from_forward(forward_signals: pd.DataFrame) -> Tuple[Dict[str, float], Dict[str, Any]]:
    """Refit coefs using realized P&L from logged signals (the real test)."""
    needed = Z_COLS + ["pnl_pct"]
    df = forward_signals.copy()
    missing = [c for c in needed if c not in df.columns]
    if missing:
        # Forward test logs may not have all z-columns if older runs predate this
        log.info("forward refit skipped: missing columns %s", missing)
        return {}, {"reason": "missing_columns", "missing": missing}

    df = df.dropna(subset=needed)
    if len(df) < 50:
        return {}, {"reason": "insufficient_samples", "n": len(df)}

    try:
        from sklearn.linear_model import LassoCV
    except ImportError:
        return {}, {"reason": "sklearn_not_installed"}

    X = df[Z_COLS].values
    y = df["pnl_pct"].values
    try:
        model = LassoCV(cv=min(5, len(df) // 10), max_iter=5000, random_state=42).fit(X, y)
    except Exception as e:
        return {}, {"reason": f"fit_error: {e}"}
    coefs = dict(zip(Z_COLS, model.coef_.astype(float)))
    meta = {
        "reason": "forward_refit_ok",
        "n": len(df),
        "alpha": float(model.alpha_),
        "intercept": float(model.intercept_),
        "r2": float(model.score(X, y)),
    }
    log.info("forward-refit coefs from %d signals (r2=%.3f, alpha=%.4f)",
             len(df), meta["r2"], meta["alpha"])
    return coefs, meta


def fit_return_predictor(forward_signals: pd.DataFrame = None,
                         ic_df: pd.DataFrame = None,
                         horizon: int = DEFAULT_HORIZON_DAYS) -> Dict[str, Any]:
    """Fit/refit and persist the return predictor coefficients."""
    coefs: Dict[str, float] = {}
    meta: Dict[str, Any] = {"horizon": horizon, "fitted_at": datetime.now(timezone.utc).isoformat()}

    if forward_signals is not None and not forward_signals.empty:
        coefs, fwd_meta = _fit_from_forward(forward_signals)
        meta.update(fwd_meta)

    if not coefs and ic_df is not None and not ic_df.empty:
        coefs = _bootstrap_coefs_from_ic(ic_df, horizon=horizon)
        meta["source"] = "ic_bootstrap"
    elif coefs:
        meta["source"] = "forward_refit"
    else:
        coefs = {c: 0.0 for c in Z_COLS}
        meta["source"] = "zero_init"

    # Clamp absurd values: any single coef >|0.05| gets capped (5% / z-unit)
    for k in list(coefs.keys()):
        coefs[k] = max(-0.05, min(0.05, float(coefs[k])))

    payload = {"coefs": coefs, "meta": meta}
    COEFS_PATH.parent.mkdir(exist_ok=True)
    COEFS_PATH.write_text(json.dumps(payload, indent=2))
    return payload


def load_predictor_coefs() -> Dict[str, float]:
    """Load previously-fit coefficients. Returns zeros if none."""
    if not COEFS_PATH.exists():
        return {c: 0.0 for c in Z_COLS}
    try:
        data = json.loads(COEFS_PATH.read_text())
        return {c: float(data.get("coefs", {}).get(c, 0.0)) for c in Z_COLS}
    except Exception:
        return {c: 0.0 for c in Z_COLS}


def predict_returns(ranked: pd.DataFrame, coefs: Dict[str, float] = None) -> pd.Series:
    """Apply coefficients to z-scores, returning predicted % return per row."""
    if coefs is None:
        coefs = load_predictor_coefs()
    if ranked is None or ranked.empty:
        return pd.Series(dtype=float)
    used_cols = [c for c in Z_COLS if c in ranked.columns]
    if not used_cols:
        return pd.Series(0.0, index=ranked.index)
    M = ranked[used_cols].fillna(0).values
    w = np.array([coefs.get(c, 0.0) for c in used_cols])
    return pd.Series(M @ w, index=ranked.index)


def add_predictions_to_options(ranked: pd.DataFrame, coefs: Dict[str, float] = None) -> pd.DataFrame:
    """Attach pred_stock_return_pct and pred_option_return_pct columns."""
    if ranked is None or ranked.empty:
        return ranked
    df = ranked.copy()
    df["pred_stock_return_pct"] = predict_returns(df, coefs)
    # Option leverage ≈ 1 / |delta|, capped to keep things sane
    deltas = df.get("delta", pd.Series(0.5, index=df.index)).abs().clip(0.10, 0.95)
    leverage = 1.0 / deltas
    # Side-aligned: calls profit on +stock_return; puts profit on -stock_return.
    side_mult = np.where(df["side"] == "call", 1.0, -1.0)
    df["pred_option_return_pct"] = df["pred_stock_return_pct"] * leverage * side_mult
    # Cap option predictions at ±200% (per-trade)
    df["pred_option_return_pct"] = df["pred_option_return_pct"].clip(-2.0, 2.0)
    return df


def add_predictions_to_shares(ranked: pd.DataFrame, coefs: Dict[str, float] = None) -> pd.DataFrame:
    """Attach pred_stock_return_pct to shares output."""
    if ranked is None or ranked.empty:
        return ranked
    df = ranked.copy()
    df["pred_stock_return_pct"] = predict_returns(df, coefs)
    return df


# -------- Auto-retrain SIGNAL_WEIGHTS --------------------------------
def update_runtime_weights(forward_signals: pd.DataFrame = None,
                            ic_df: pd.DataFrame = None,
                            min_samples: int = 50) -> Optional[Dict[str, float]]:
    """Refit fusion weights based on what's actually predictive.

    Strategy:
      - Start from config.SIGNAL_WEIGHTS as baseline.
      - For factors with measured IC: multiply baseline weight by adjustment.
        - Positive IC > 0.05  → upweight 1.20×
        - Strong positive IC > 0.10 → upweight 1.50×
        - Negative IC < -0.05 → downweight 0.50×
        - Strong negative IC < -0.10 → downweight 0.25×
      - For factors WITHOUT IC data: keep baseline weight.
      - Renormalize to sum to 1.

    If forward signals have ≥min_samples, use Lasso instead (more precise).
    """
    # Get baseline from the user's config.py
    try:
        import config as _cfg
        baseline = dict(_cfg.SIGNAL_WEIGHTS)
    except Exception:
        baseline = {
            "mispricing": 0.18, "iv_rank": 0.07, "skew": 0.05, "sentiment_d": 0.13,
            "fundamentals": 0.10, "insider": 0.10, "macro": 0.07,
            "news": 0.10, "earnings": 0.10, "value": 0.10,
        }

    # Forward-test refit (most authoritative once we have enough data)
    if forward_signals is not None and not forward_signals.empty and \
       all(c in forward_signals.columns for c in Z_COLS):
        df = forward_signals.dropna(subset=Z_COLS + ["pnl_pct"])
        if len(df) >= min_samples:
            try:
                from sklearn.linear_model import LassoCV
                X = df[Z_COLS].values
                y = df["pnl_pct"].values
                m = LassoCV(cv=min(5, len(df) // 10), max_iter=5000, random_state=42).fit(X, y)
                abs_coef = np.abs(m.coef_)
                if abs_coef.sum() > 0:
                    z_to_weight = dict(zip(Z_COLS, abs_coef / abs_coef.sum()))
                    weight_map = _normalize_to_signal_weights(z_to_weight)
                    _persist_runtime_weights(weight_map, source=f"forward_lasso_n{len(df)}")
                    log.info("weights refit from %d forward samples", len(df))
                    return weight_map
            except Exception as e:
                log.warning("forward weight refit failed: %s", e)

    # IC-based proportional adjustment of the baseline weights
    if ic_df is not None and not ic_df.empty:
        target_h = 7 if 7 in ic_df["horizon_days"].unique() else int(ic_df["horizon_days"].min())
        sub = ic_df[ic_df["horizon_days"] == target_h]

        # Map IC factor name → SIGNAL_WEIGHTS key
        zcol_to_signal = {
            "z_value":   "value",
            "z_fund":    "fundamentals",
            "z_sent":    "sentiment_d",
            "z_insider": "insider",
        }
        ic_lookup: Dict[str, float] = {}
        for _, r in sub.iterrows():
            zcol = FACTOR_TO_ZCOL.get(r["factor"])
            if zcol and zcol in zcol_to_signal:
                ic_lookup[zcol_to_signal[zcol]] = float(r["ic"])

        adjusted = dict(baseline)
        for sig_key, ic in ic_lookup.items():
            if sig_key not in adjusted:
                continue
            if ic > 0.10:
                mult = 1.50
            elif ic > 0.05:
                mult = 1.20
            elif ic < -0.10:
                mult = 0.25
            elif ic < -0.05:
                mult = 0.50
            else:
                mult = 1.0
            adjusted[sig_key] *= mult

        # Renormalize to sum to 1
        s = sum(adjusted.values())
        if s > 0:
            adjusted = {k: round(v / s, 4) for k, v in adjusted.items()}
            _persist_runtime_weights(adjusted, source=f"ic_adjustment_h{target_h}")
            log.info("weights adjusted via IC at h=%dd; %d factors had measured IC",
                     target_h, len(ic_lookup))
            return adjusted

    return None


def _normalize_to_signal_weights(z_weights: Dict[str, float]) -> Dict[str, float]:
    """Map z-column weights back to SIGNAL_WEIGHTS keys, normalize to sum to 1."""
    name_map = {v: k for k, v in {
        "mispricing":   "z_mispricing",
        "iv_rank":      "z_iv_rank",
        "skew":         "z_skew",
        "sentiment_d":  "z_sent",
        "fundamentals": "z_fund",
        "insider":      "z_insider",
        "macro":        "z_macro",
        "news":         "z_news",
        "earnings":     "z_earnings",
        "value":        "z_value",
    }.items()}
    raw = {name_map.get(k): v for k, v in z_weights.items() if name_map.get(k)}
    # Use absolute value for weight magnitude; sign captured elsewhere
    abs_raw = {k: abs(v) for k, v in raw.items()}
    s = sum(abs_raw.values())
    if s == 0:
        # Default fallback
        return {
            "mispricing": 0.20, "iv_rank": 0.08, "skew": 0.05, "sentiment_d": 0.13,
            "fundamentals": 0.10, "insider": 0.10, "macro": 0.07,
            "news": 0.10, "earnings": 0.10, "value": 0.07,
        }
    return {k: round(v / s, 4) for k, v in abs_raw.items()}


def _persist_runtime_weights(weights: Dict[str, float], source: str = "auto"):
    """Write a config_runtime.py that, when imported, overrides SIGNAL_WEIGHTS."""
    lines = [
        f'"""Auto-generated runtime overrides. Source: {source}',
        f"   Generated: {datetime.now(timezone.utc).isoformat()}",
        f'   Delete this file to revert to config.SIGNAL_WEIGHTS defaults.',
        '"""',
        "",
        "SIGNAL_WEIGHTS = {",
    ]
    for k, v in weights.items():
        lines.append(f'    "{k}": {v},')
    lines.append("}")
    RUNTIME_CONFIG_PATH.write_text("\n".join(lines))


def load_runtime_weights() -> Optional[Dict[str, float]]:
    """If config_runtime.py exists, parse it and return the weight dict."""
    if not RUNTIME_CONFIG_PATH.exists():
        return None
    try:
        ns: Dict[str, Any] = {}
        exec(RUNTIME_CONFIG_PATH.read_text(), ns)
        w = ns.get("SIGNAL_WEIGHTS")
        if isinstance(w, dict):
            return w
    except Exception as e:
        log.debug("failed to load config_runtime.py: %s", e)
    return None
