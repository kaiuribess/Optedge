"""Self-improvement scaffold.

Track signals over time. For each logged signal:
  - re-pull underlying close at +1d, +7d, +30d
  - estimate option P&L as Δ in BS-fair value (since live re-quotes may not be available)
  - store outcomes
A retraining hook then refits signal weights via Lasso CV on the accumulated log.
"""
from __future__ import annotations
import json
import logging
import os
from pathlib import Path
from datetime import datetime, timedelta, timezone
from typing import Optional

import numpy as np
import pandas as pd

from utils import bs_price

log = logging.getLogger("optedge.backtest")
LOG_DIR = Path(__file__).resolve().parent.parent / "logs"


def log_signals(df: pd.DataFrame, asof: datetime) -> Path:
    LOG_DIR.mkdir(exist_ok=True)
    fp = LOG_DIR / f"signals_{asof.strftime('%Y%m%d_%H%M%S')}.parquet"
    cols = [
        "ticker", "contract", "side", "strike", "expiry", "dte", "spot",
        "mid", "iv_market", "fair_vol", "vol_premium", "delta",
        "is_buy", "fused_score", "confidence", "signal", "reasoning",
        "z_mispricing", "z_iv_rank", "z_skew", "z_sent", "z_fund", "z_insider", "z_macro",
    ]
    keep = [c for c in cols if c in df.columns]
    df[keep].to_parquet(fp, index=False)
    log.info("logged %d signals to %s", len(df), fp)
    return fp


def evaluate_log(fp: Path, horizon_days: int = 7) -> Optional[pd.DataFrame]:
    """Re-pull spot at horizon, recompute BS price assuming same IV, get P&L."""
    import yfinance as yf
    df = pd.read_parquet(fp)
    out = []
    for _, r in df.iterrows():
        try:
            tk = yf.Ticker(r["ticker"])
            h = tk.history(period=f"{horizon_days+5}d")
            if h.empty:
                continue
            new_spot = float(h["Close"].iloc[-1])
            T_new = max((pd.to_datetime(r["expiry"]) - pd.Timestamp.utcnow()).days, 1) / 365.25
            if T_new <= 0:
                continue
            new_price = bs_price(new_spot, r["strike"], T_new, 0.045,
                                 r["iv_market"], 0.0, call=(r["side"] == "call"))
            pnl_pct = (new_price - r["mid"]) / r["mid"] if r["is_buy"] else (r["mid"] - new_price) / r["mid"]
            out.append({"contract": r["contract"], "fused_score": r["fused_score"], "pnl_pct": pnl_pct})
        except Exception as e:
            log.debug("eval fail %s: %s", r["contract"], e)
    return pd.DataFrame(out) if out else None


def refit_weights(eval_df: pd.DataFrame, signal_log: pd.DataFrame, min_samples: int = 100) -> Optional[dict]:
    """Refit signal weights via Lasso CV. Refuses to update below min_samples."""
    if eval_df is None or len(eval_df) < min_samples:
        log.info("refit deferred: %d samples (need %d)", 0 if eval_df is None else len(eval_df), min_samples)
        return None
    from sklearn.linear_model import LassoCV
    merged = eval_df.merge(signal_log, on="contract", how="inner")
    feats = ["z_mispricing", "z_iv_rank", "z_skew", "z_sent", "z_fund", "z_insider", "z_macro"]
    X = merged[feats].values
    y = merged["pnl_pct"].values
    model = LassoCV(cv=5, max_iter=5000).fit(X, y)
    coefs = dict(zip(feats, model.coef_))
    log.info("refit weights: %s", coefs)
    return coefs
