"""Forward testing — replay logged signals with current prices.

Reads `logs/signals_*.parquet` (written by every run), fetches current spot
for each logged ticker, re-prices any option signals using Black-Scholes at
the entry IV, and computes realized P&L. Outputs a DataFrame stratified by
confidence bucket, signal type, and signal age.

Run: python run.py --forward
"""
from __future__ import annotations
import glob
import logging
import math
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional

import numpy as np
import pandas as pd

import sys
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import data_provider
from utils import bs_price, safe_float, safe_int

log = logging.getLogger("optedge.forward")
LOGS_DIR = ROOT / "logs"


def _load_all_logs() -> pd.DataFrame:
    """Concatenate every logged signal across all runs, deduping by contract."""
    files = sorted(glob.glob(str(LOGS_DIR / "signals_*.parquet")))
    if not files:
        return pd.DataFrame()
    dfs = []
    for f in files:
        try:
            df = pd.read_parquet(f)
            # Stamp file mtime as the log time (we may not have it in the row)
            from pathlib import Path as _P
            mtime = datetime.fromtimestamp(_P(f).stat().st_mtime, tz=timezone.utc)
            df["log_time"] = mtime
            dfs.append(df)
        except Exception as e:
            log.debug("skip %s: %s", f, e)
    if not dfs:
        return pd.DataFrame()
    all_df = pd.concat(dfs, ignore_index=True)
    # Latest log entry wins per (contract, log_time)
    all_df = all_df.drop_duplicates(subset=["contract", "log_time"], keep="last")
    return all_df


def _price_option_now(row: pd.Series, spot_now: float) -> Optional[float]:
    """Re-price a previously-logged option contract at current spot, holding IV constant."""
    try:
        K = safe_float(row.get("strike"))
        is_call = row.get("side") == "call"
        iv = safe_float(row.get("iv_market"))
        if K <= 0 or iv <= 0:
            return None
        # Days to expiry from NOW
        exp_str = row.get("expiry")
        if not exp_str:
            return None
        try:
            exp = datetime.strptime(str(exp_str), "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except Exception:
            return None
        T_days = (exp - datetime.now(timezone.utc)).total_seconds() / 86400
        if T_days <= 0:
            # Expired — use intrinsic
            return max(0.0, (spot_now - K) if is_call else (K - spot_now))
        T = T_days / 365.25
        return bs_price(spot_now, K, T, 0.045, iv, 0.0, call=is_call)
    except Exception:
        return None


def _process_signal(row: pd.Series) -> Dict[str, Any]:
    """Compute realized P&L for one logged signal."""
    ticker = row.get("ticker")
    if not ticker:
        return {}
    log_time = row.get("log_time")
    days_old = None
    if log_time is not None:
        try:
            days_old = (datetime.now(timezone.utc) - pd.to_datetime(log_time, utc=True)).total_seconds() / 86400
        except Exception:
            pass

    # Get current spot via shared provider
    hist = data_provider.get_history(ticker, period="5d")
    spot_now = float(hist["Close"].iloc[-1]) if not hist.empty else None
    if spot_now is None:
        return {}

    out = {
        "ticker": ticker,
        "contract": row.get("contract"),
        "side": row.get("side"),
        "is_buy": bool(row.get("is_buy", True)),
        "confidence": safe_int(row.get("confidence")),
        "log_time": log_time,
        "days_old": round(days_old, 1) if days_old is not None else None,
        "spot_now": spot_now,
    }

    # Option leg
    if row.get("side") in ("call", "put"):
        entry_mid = safe_float(row.get("mid"))
        if entry_mid <= 0:
            return out
        new_price = _price_option_now(row, spot_now)
        if new_price is None or new_price <= 0:
            new_price = 0.0
        if row.get("is_buy", True):
            pnl_pct = (new_price - entry_mid) / entry_mid
        else:
            pnl_pct = (entry_mid - new_price) / entry_mid
        out["entry_price"] = round(entry_mid, 3)
        out["current_price"] = round(new_price, 3)
        out["pnl_pct"] = round(pnl_pct, 4)
    else:
        # Share / generic — compare spot
        entry = safe_float(row.get("spot"))
        if entry <= 0:
            return out
        out["entry_price"] = round(entry, 3)
        out["current_price"] = round(spot_now, 3)
        out["pnl_pct"] = round((spot_now / entry) - 1, 4)
    return out


def run_forward_test(max_workers: int = 8) -> Dict[str, Any]:
    """Re-price every logged signal and return summary stats + raw rows."""
    sigs = _load_all_logs()
    if sigs.empty:
        log.info("no signal logs found yet — run `python run.py` first to log signals")
        return {"signals": pd.DataFrame(), "summary": pd.DataFrame()}

    log.info("forward test: %d logged signals across %d files",
             len(sigs), len(set(sigs["log_time"].astype(str))))

    rows = []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(_process_signal, r): r["contract"] for _, r in sigs.iterrows()}
        for fut in as_completed(futures):
            try:
                r = fut.result()
                if r and r.get("pnl_pct") is not None:
                    rows.append(r)
            except Exception as e:
                log.debug("forward fail: %s", e)
    pnl = pd.DataFrame(rows)
    if pnl.empty:
        return {"signals": pnl, "summary": pd.DataFrame()}

    # Overall stats
    overall = {
        "n_signals": len(pnl),
        "win_rate": (pnl["pnl_pct"] > 0).mean(),
        "avg_pnl_pct": pnl["pnl_pct"].mean(),
        "median_pnl_pct": pnl["pnl_pct"].median(),
        "best": pnl["pnl_pct"].max(),
        "worst": pnl["pnl_pct"].min(),
    }

    # By confidence bucket
    buckets = []
    for lo, hi, lab in [(0, 55, "low (<55)"), (55, 70, "med (55-70)"), (70, 100, "high (≥70)")]:
        sub = pnl[(pnl["confidence"] >= lo) & (pnl["confidence"] < hi)]
        if sub.empty:
            continue
        buckets.append({
            "bucket": lab,
            "n": len(sub),
            "win_rate": float((sub["pnl_pct"] > 0).mean()),
            "avg_pnl": float(sub["pnl_pct"].mean()),
            "median_pnl": float(sub["pnl_pct"].median()),
        })

    # By signal type
    types = []
    for t in ("call", "put"):
        sub = pnl[pnl["side"] == t]
        if sub.empty:
            continue
        types.append({
            "type": t,
            "n": len(sub),
            "win_rate": float((sub["pnl_pct"] > 0).mean()),
            "avg_pnl": float(sub["pnl_pct"].mean()),
        })

    return {
        "signals": pnl,
        "overall": overall,
        "by_confidence": pd.DataFrame(buckets),
        "by_type": pd.DataFrame(types),
    }
