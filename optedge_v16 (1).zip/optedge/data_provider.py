"""Shared data provider — gives every engine a consistent, hardened way
to fetch data. Wraps yfinance with curl_cffi browser fingerprinting (defeats
most rate limiting), adds disk caching, and exposes a uniform API.

If you have a Polygon.io free API key (set POLYGON_API_KEY env var), this
module will prefer Polygon for options chains and prices — Polygon's free
tier is more reliable than yfinance and doesn't get rate-limited the same way.
"""
from __future__ import annotations
import logging
import os
import time
import json
import hashlib
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any

import pandas as pd

log = logging.getLogger("optedge.provider")

CACHE_DIR = Path(__file__).resolve().parent / "data" / "_cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


# -------- Disk cache (light) -----------------------------------------
def _cache_path(key: str) -> Path:
    h = hashlib.sha1(key.encode()).hexdigest()[:16]
    return CACHE_DIR / f"{h}.json"


def cache_get(key: str, max_age_sec: int = 900) -> Optional[Any]:
    fp = _cache_path(key)
    if not fp.exists():
        return None
    age = time.time() - fp.stat().st_mtime
    if age > max_age_sec:
        return None
    try:
        return json.loads(fp.read_text())
    except Exception:
        return None


def cache_put(key: str, value: Any) -> None:
    fp = _cache_path(key)
    try:
        fp.write_text(json.dumps(value, default=str))
    except Exception as e:
        log.debug("cache_put fail: %s", e)


# -------- Session factory ---------------------------------------------
_SESSION = None


def get_session():
    """Return a session that uses curl_cffi if available (better at defeating
    rate limiting), else a plain requests session."""
    global _SESSION
    if _SESSION is not None:
        return _SESSION
    try:
        from curl_cffi import requests as creq
        _SESSION = creq.Session(impersonate="chrome120", timeout=30)
        log.debug("using curl_cffi session (chrome120 impersonation)")
    except ImportError:
        import requests
        _SESSION = requests.Session()
        _SESSION.headers["User-Agent"] = (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5) AppleWebKit/605.1.15 "
            "(KHTML, like Gecko) Version/16.6 Safari/605.1.15"
        )
        log.debug("using plain requests session (curl_cffi unavailable)")
    return _SESSION


# -------- yfinance wrapper --------------------------------------------
def yf_ticker(ticker: str):
    """Return a yfinance Ticker bound to our hardened session."""
    import yfinance as yf
    sess = get_session()
    try:
        return yf.Ticker(ticker, session=sess)
    except TypeError:
        # Older yfinance versions don't accept session kwarg
        return yf.Ticker(ticker)


# -------- Public unified API ------------------------------------------
def get_history(ticker: str, period: str = "1y", interval: str = "1d",
                cache_age: int = 3600) -> pd.DataFrame:
    """Get price history with caching. Returns empty DataFrame on failure."""
    key = f"history:{ticker}:{period}:{interval}"
    cached = cache_get(key, cache_age)
    if cached is not None:
        return pd.DataFrame(cached)
    try:
        tk = yf_ticker(ticker)
        h = tk.history(period=period, interval=interval)
        if h.empty:
            return pd.DataFrame()
        # Convert index to string for cache JSON serialisability
        out = h.reset_index()
        out["Date"] = pd.to_datetime(out["Date"]).dt.strftime("%Y-%m-%d")
        cache_put(key, out.to_dict("records"))
        return h
    except Exception as e:
        log.debug("get_history fail %s: %s", ticker, e)
        return pd.DataFrame()


def get_options_chain(ticker: str, cache_age: int = 600) -> Dict[str, Any]:
    """Get full option chain across all expirations.

    Returns:
      {"spot": float, "div_yield": float, "expirations": List[str], "chains": Dict[expiry, DataFrame]}
      or empty dict on failure.
    """
    key = f"chain:{ticker}"
    cached = cache_get(key, cache_age)
    if cached:
        chains = {exp: pd.DataFrame(rows) for exp, rows in cached["chains"].items()}
        return {**cached, "chains": chains}

    try:
        tk = yf_ticker(ticker)
        h = tk.history(period="5d")
        spot = float(h["Close"].iloc[-1]) if not h.empty else None
        if not spot:
            return {}
        info = getattr(tk, "info", {}) or {}
        dy = info.get("dividendYield") or 0.0
        div_yield = dy if dy is not None and dy < 1 else (dy or 0) / 100.0

        expirations = tk.options or []
        chains = {}
        for exp in expirations:
            try:
                opt = tk.option_chain(exp)
                df_calls = opt.calls.copy(); df_calls["side"] = "call"
                df_puts = opt.puts.copy(); df_puts["side"] = "put"
                chains[exp] = pd.concat([df_calls, df_puts], ignore_index=True)
            except Exception:
                continue
            time.sleep(0.2)  # be polite

        out = {
            "spot": spot,
            "div_yield": div_yield,
            "expirations": expirations,
            "chains": chains,
        }
        # Cache (convert DataFrames to records)
        cache_put(key, {**out, "chains": {k: v.to_dict("records") for k, v in chains.items()}})
        return out
    except Exception as e:
        log.debug("get_options_chain fail %s: %s", ticker, e)
        return {}


def get_fundamentals(ticker: str, cache_age: int = 86400) -> Dict[str, Any]:
    key = f"fundamentals:{ticker}"
    cached = cache_get(key, cache_age)
    if cached is not None:
        return cached
    try:
        tk = yf_ticker(ticker)
        info = getattr(tk, "info", {}) or {}
        # Pick out the fields we actually use
        out = {
            "revenueGrowth": info.get("revenueGrowth"),
            "grossMargins": info.get("grossMargins"),
            "operatingMargins": info.get("operatingMargins"),
            "trailingPE": info.get("trailingPE"),
            "forwardPE": info.get("forwardPE"),
            "priceToSalesTrailing12Months": info.get("priceToSalesTrailing12Months"),
            "enterpriseToEbitda": info.get("enterpriseToEbitda"),
            "freeCashflow": info.get("freeCashflow"),
            "marketCap": info.get("marketCap"),
            "dividendYield": info.get("dividendYield"),
            "earningsTimestamp": info.get("earningsTimestamp"),
            "earningsTimestampStart": info.get("earningsTimestampStart"),
        }
        cache_put(key, out)
        return out
    except Exception as e:
        log.debug("get_fundamentals fail %s: %s", ticker, e)
        return {}


# -------- Health -----------------------------------------------------
def status() -> Dict[str, Any]:
    """Read .optedge_status.json (written by setup_check.py)."""
    fp = Path(__file__).resolve().parent / ".optedge_status.json"
    if not fp.exists():
        return {}
    try:
        return json.loads(fp.read_text())
    except Exception:
        return {}
