"""Render the Optedge quant cockpit as a self-contained HTML file.

Layout:
  - Header + run stats banner
  - Macro regime panel (VIX, yields, regime)
  - Long Calls / Long Puts / Long Shares card grids
  - News flow panel (top recently-newsy names)
  - Earnings calendar (next 14d)
  - Insider activity heatmap (top buyers / top sellers)
  - WSB trending heatmap
  - Ranked tables (full snapshot)
  - TradingView watchlist export
  - Methodology appendix
"""
from __future__ import annotations
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional
import html
import logging
import math

import pandas as pd

log = logging.getLogger("optedge.dashboard")
ROOT = Path(__file__).resolve().parent.parent


def _safe_int(v, default: int = 0) -> int:
    """Convert to int, treating None/NaN/inf as the default. Avoids the
    common 'cannot convert float NaN to integer' crash when DataFrame fields
    are NaN."""
    try:
        if v is None:
            return default
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            return default
        return int(v)
    except (ValueError, TypeError):
        return default


# -------- Tiny formatters ---------------------------------------------
def _fmt_pct(x, digits=1):
    if x is None or pd.isna(x):
        return "—"
    return f"{x*100:+.{digits}f}%"


def _fmt_num(x, digits=2):
    if x is None or pd.isna(x):
        return "—"
    return f"{x:.{digits}f}"


def _fmt_money(x):
    if x is None or pd.isna(x) or x == 0:
        return "—"
    if x >= 1e9:
        return f"${x/1e9:.2f}B"
    if x >= 1e6:
        return f"${x/1e6:.1f}M"
    if x >= 1e3:
        return f"${x/1e3:.0f}K"
    return f"${x:.0f}"


def _badge(label: str, color: str) -> str:
    return f'<span class="badge" style="background:{color}">{label}</span>'


def _confidence_bar(conf: int) -> str:
    width = max(0, min(100, conf))
    color = "#10b981" if conf >= 70 else "#f59e0b" if conf >= 55 else "#94a3b8"
    return (f'<div class="conf-bar"><div class="conf-fill" '
            f'style="width:{width}%;background:{color}"></div>'
            f'<span class="conf-text">{conf}</span></div>')


# -------- Cards --------------------------------------------------------
def _option_card(row: pd.Series) -> str:
    side_color = "#10b981" if row["side"] == "call" else "#f87171"
    side_label = "LONG CALL" if row["side"] == "call" else "LONG PUT"
    moneyness = (row["strike"] / row["spot"] - 1) * 100
    headline = (row.get("top_headline") or "").strip()
    earnings = row.get("days_to_earnings")
    earnings_html = ""
    if earnings is not None and not pd.isna(earnings) and 0 <= earnings <= 60:
        earnings_html = f'<span class="chip earn">📅 EPS in {int(earnings)}d</span>'
    headline_html = ""
    if headline:
        headline_html = f'<div class="headline">📰 {html.escape(headline[:90])}</div>'
    # Predicted return chip
    pred_html = ""
    pred_opt = row.get("pred_option_return_pct")
    if pred_opt is not None and not pd.isna(pred_opt) and abs(pred_opt) > 0.005:
        color = "#10b981" if pred_opt > 0 else "#ef4444"
        pred_html = (f'<span class="chip" style="background:{color}20;color:{color};font-weight:600">'
                     f'pred {pred_opt*100:+.1f}%</span>')
    # EV chip
    ev_html = ""
    ev_pct = row.get("ev_pct")
    if ev_pct is not None and not pd.isna(ev_pct):
        ev_color = "#10b981" if ev_pct > 0 else "#ef4444"
        ev_html = (f'<span class="chip" style="background:{ev_color}20;color:{ev_color}">'
                   f'EV {ev_pct*100:+.0f}%</span>')
    # Congress chip
    congress_html = ""
    cong_score = row.get("congress_score") or 0
    if cong_score and not pd.isna(cong_score) and abs(cong_score) > 0.3:
        c = "#10b981" if cong_score > 0 else "#ef4444"
        n_buys = _safe_int(row.get("congress_buys_n"))
        congress_html = (f'<span class="chip" style="background:{c}20;color:{c}">'
                         f'🏛 Cong {cong_score:+.1f} ({n_buys}P)</span>')
    # Analyst chip
    analyst_html = ""
    analyst_score = row.get("analyst_score") or 0
    if analyst_score and not pd.isna(analyst_score) and abs(analyst_score) > 0.5:
        ac = "#10b981" if analyst_score > 0 else "#ef4444"
        sb = _safe_int(row.get("analyst_strong_buy"))
        bs = _safe_int(row.get("analyst_buy"))
        ss = _safe_int(row.get("analyst_strong_sell")) + _safe_int(row.get("analyst_sell"))
        analyst_html = (f'<span class="chip" style="background:{ac}20;color:{ac}">'
                        f'📊 {sb}SB/{bs}B/{ss}S ({analyst_score:+.1f})</span>')
    # Kelly + sizing
    kelly_pct = row.get("kelly_pct") or 0
    sized_dollars = row.get("actual_dollars") or 0
    sized_contracts = _safe_int(row.get("suggested_contracts"))
    kelly_html = ""
    if kelly_pct and not pd.isna(kelly_pct) and kelly_pct > 0:
        kelly_html = (f'<span class="chip" style="background:#3b82f620;color:#3b82f6">'
                      f'¼Kelly {kelly_pct*100:.1f}%</span>')
    # Exit triggers (option-specific)
    stop_p = row.get("stop_price")
    target_p = row.get("target_price")
    exit_block = ""
    if stop_p is not None and target_p is not None and not pd.isna(stop_p) and stop_p > 0:
        exit_block = f"""
  <div class="exit-block">
    <h4>Exit triggers</h4>
    <div class="exit-row">
      <span class="exit-stop">🛑 Stop @ ${stop_p:.2f} <span class="muted">(−50%)</span></span>
      <span class="exit-target">🎯 Target @ ${target_p:.2f} <span class="muted">(+100%)</span></span>
    </div>
  </div>"""

    sizing_block = ""
    if kelly_pct and kelly_pct > 0 and sized_contracts > 0:
        sizing_block = f"""
  <div class="sizing-block">
    <h4>Position size <span class="muted">(Kelly)</span></h4>
    <div class="sizing-row">
      <span><strong>{sized_contracts}</strong> contract{'s' if sized_contracts != 1 else ''}</span>
      <span class="muted">≈ ${sized_dollars:,.0f}</span>
      <span class="muted">{kelly_pct*100:.1f}% of bankroll</span>
    </div>
  </div>"""
    elif kelly_pct == 0:
        sizing_block = """<div class="sizing-block warn">
    <h4>Position size</h4>
    <p>⚠ Kelly = 0 — predictor disagrees. Skip.</p>
  </div>"""

    return f"""
<article class="card" data-ticker="{html.escape(row["ticker"]).upper()}" data-side="{row["side"]}" data-conf="{_safe_int(row.get("confidence"))}" data-pred="{(pred_opt or 0)*100:.2f}" data-ev="{(ev_pct or 0)*100:.2f}" data-kelly="{(kelly_pct or 0)*100:.2f}" data-dte="{_safe_int(row.get('dte'))}">
  <header class="card-head">
    <div class="ticker-block">
      <span class="ticker">{html.escape(row["ticker"])}</span>
      {_badge(side_label, side_color)}
      {earnings_html}
      {pred_html}
      {ev_html}
      {kelly_html}
      {congress_html}
      {analyst_html}
    </div>
    {_confidence_bar(_safe_int(row.get("confidence")))}
  </header>
  <div class="contract">
    <span class="contract-line">{html.escape(row["contract"])}</span>
    <span class="muted">@ ${_fmt_num(row['mid'])} · spot ${_fmt_num(row['spot'])} · {moneyness:+.1f}% · {_safe_int(row.get('dte'))}d</span>
  </div>
  <div class="grid">
    <div><span class="lab">IV</span><span class="val">{_fmt_pct(row['iv_market'])}</span></div>
    <div><span class="lab">HV30</span><span class="val">{_fmt_pct(row['fair_vol'])}</span></div>
    <div><span class="lab">Vol prem</span><span class="val">{_fmt_pct(row['vol_premium'])}</span></div>
    <div><span class="lab">Δ</span><span class="val">{_fmt_num(row['delta'])}</span></div>
    <div><span class="lab">OI</span><span class="val">{_safe_int(row.get('open_interest')):,}</span></div>
    <div><span class="lab">Spread</span><span class="val">{_fmt_pct(row['spread_pct'])}</span></div>
  </div>
  {headline_html}
  {sizing_block}
  {exit_block}
  <div class="reason">
    <h4>Why</h4>
    <p>{html.escape(row.get("reasoning",""))}</p>
  </div>
  <div class="risks">
    <h4>Risks</h4>
    <p>{html.escape(row.get("risks",""))}</p>
  </div>
</article>
"""


def _value_card(row: pd.Series) -> str:
    """Card for a "good value" play."""
    bucket = row.get("value_bucket") or "—"
    bucket_color = {"deep value": "#10b981", "value": "#3b82f6",
                    "fair": "#94a3b8", "expensive": "#ef4444"}.get(bucket, "#94a3b8")
    pe = row.get("pe")
    pe_str = f"{pe:.1f}" if pe is not None and not pd.isna(pe) and pe > 0 else "—"
    fcf_y = row.get("fcf_yield")
    ey = row.get("earnings_yield")
    insider = row.get("insider_score") or 0
    headline = (row.get("top_headline") or "").strip()
    headline_html = (f'<div class="headline">📰 {html.escape(headline[:90])}</div>'
                     if headline else "")
    insider_chip = ""
    if insider and not pd.isna(insider) and abs(insider) > 0.5:
        ins_color = "#10b981" if insider > 0 else "#ef4444"
        n_buys = _safe_int(row.get("n_buys"))
        n_sells = _safe_int(row.get("n_sells"))
        insider_chip = (f'<span class="chip" style="background:{ins_color}20;color:{ins_color}">'
                        f'Insider {insider:+.1f} ({n_buys}P/{n_sells}S)</span>')
    return f"""
<article class="card">
  <header class="card-head">
    <div class="ticker-block">
      <span class="ticker">{html.escape(row["ticker"])}</span>
      {_badge("VALUE", bucket_color)}
      <span class="chip" style="background:{bucket_color}20;color:{bucket_color}">{html.escape(bucket)}</span>
    </div>
    <div class="muted" style="font-family:'JetBrains Mono', monospace; font-size:13px;">
      score <strong>{row['value_score']:+.2f}</strong>
    </div>
  </header>
  <div class="grid">
    <div><span class="lab">P/E</span><span class="val">{pe_str}</span></div>
    <div><span class="lab">FCF yld</span><span class="val">{_fmt_pct(fcf_y) if fcf_y is not None else '—'}</span></div>
    <div><span class="lab">EY</span><span class="val">{_fmt_pct(ey) if ey is not None else '—'}</span></div>
    <div><span class="lab">EV/EBITDA</span><span class="val">{_fmt_num(row.get('ev_ebitda'),1)}</span></div>
    <div><span class="lab">Op margin</span><span class="val">{_fmt_pct(row.get('roic_proxy')) if row.get('roic_proxy') is not None else '—'}</span></div>
    <div><span class="lab">Graham</span><span class="val">{_safe_int(row.get('graham_score'))}/6</span></div>
  </div>
  <div style="margin-top:8px; display:flex; gap:6px; flex-wrap:wrap;">
    {insider_chip}
  </div>
  {headline_html}
</article>
"""


def _futures_card(row: pd.Series, bankroll: float = 25000) -> str:
    """Real recommended-trade futures card (v16) — micro contract default,
    ATR-based stops, explicit entry/stop/target with $ risk + reward + R:R + margin,
    plus a factor-breakdown chip row showing what's driving the score."""
    score = float(row.get("futures_score") or 0)
    is_long = bool(row.get("is_long")) if "is_long" in row.index else (score > 0)
    side_color = "#10b981" if is_long else "#f87171"
    side_label = "LONG" if is_long else "SHORT"
    sym_full = row.get("symbol", "—")
    sym_micro = row.get("micro_symbol") or sym_full.replace("=F", "")
    name = row.get("name") or ""
    spot = row.get("spot")
    bucket = (row.get("bucket") or "").replace("futures_", "")

    n_contracts = _safe_int(row.get("n_contracts"))
    entry = row.get("entry")
    stop_price = row.get("stop_price")
    target_price = row.get("target_price")
    stop_pts = row.get("stop_pts")
    target_pts = row.get("target_pts")
    rr = row.get("rr") or 0
    margin_required = row.get("margin_required") or 0
    pct_bankroll = row.get("pct_bankroll") or 0
    actual_dollar_risk = row.get("actual_dollar_risk") or 0
    actual_dollar_reward = row.get("actual_dollar_reward") or 0
    expected_pnl = row.get("expected_pnl") or 0
    point_value = row.get("point_value") or 1.0
    atr = row.get("atr14")
    stop_mult = row.get("stop_atr_mult") or 1.5
    target_mult = row.get("target_atr_mult") or 3.0
    margin_per = row.get("margin_per_contract") or 0

    # Trade ticket — only render if a tradable size came out
    if n_contracts > 0 and entry is not None:
        trade_block = f"""
  <div class="trade-block" style="border-left-color:{side_color}">
    <h4>Recommended trade <span class="muted">(self-learning · {bucket})</span></h4>
    <div class="trade-headline" style="color:{side_color}">
      {side_label} <strong>{n_contracts}&times; {html.escape(sym_micro)}</strong> @ ${_fmt_num(entry, 4)}
    </div>
    <div class="trade-row">
      <span class="trade-stop">&#128721; stop ${_fmt_num(stop_price, 4)} <span class="muted">({stop_pts:+.2f} pts &middot; -${_fmt_num(actual_dollar_risk, 0)})</span></span>
      <span class="trade-target">&#127919; target ${_fmt_num(target_price, 4)} <span class="muted">({target_pts:+.2f} pts &middot; +${_fmt_num(actual_dollar_reward, 0)})</span></span>
    </div>
    <div class="trade-foot muted">
      R:R <strong>{rr:.2f}</strong> &middot;
      margin <strong>${margin_required:,.0f}</strong> ({pct_bankroll*100:.1f}% bankroll) &middot;
      expected PnL <strong>${expected_pnl:,.0f}</strong>
    </div>
  </div>"""
    else:
        # No-trade case (score didn't clear gate or sized to zero)
        trade_block = f"""
  <div class="trade-block warn">
    <h4>No trade</h4>
    <div class="muted" style="font-size:12px;">Score {score:+.2f} below conviction gate or position rounded to zero contracts at this bankroll. Watch the underlying — the factor mix isn't aligned enough yet.</div>
  </div>"""

    # Factor breakdown chips
    factor_keys = ["trend", "momentum", "macro_align", "components", "news",
                    "social", "earnings", "congress", "fred_panel", "atr_regime"]
    chips = []
    for k in factor_keys:
        v = row.get(f"factor_{k}")
        if v is None or pd.isna(v):
            continue
        v = float(v)
        if abs(v) < 0.05:
            continue
        c = "#10b981" if v > 0 else "#f87171"
        chips.append(f'<span class="chip" style="background:{c}20;color:{c}">{html.escape(k)} {v:+.2f}</span>')
    factor_chip_row = " ".join(chips) if chips else '<span class="muted" style="font-size:11px;">factors all near zero</span>'

    underlying_note = (f"underlying {html.escape(sym_full)} @ ${_fmt_num(spot)}"
                       f" &middot; 1 {html.escape(sym_micro)} = ${point_value:,.0f}/pt"
                       f" &middot; ATR14 {atr:.2f}" if atr is not None else
                       f"underlying {html.escape(sym_full)} @ ${_fmt_num(spot)}"
                       f" &middot; 1 {html.escape(sym_micro)} = ${point_value:,.0f}/pt")

    return f"""
<article class="card futures-card" data-ticker="{html.escape(sym_full)}" data-side="futures" data-conf="{int(min(99, abs(score)*60))}" data-pred="{score*5:.2f}" data-ev="{(expected_pnl/max(1,bankroll))*100:.2f}" data-kelly="{(row.get('kelly_pct') or 0)*100:.2f}">
  <header class="card-head">
    <div class="ticker-block">
      <span class="ticker">{html.escape(sym_micro)}</span>
      {_badge(side_label, side_color)}
      <span class="chip">{html.escape(bucket or 'futures')}</span>
      <span class="chip" style="background:{'#10b98120' if score > 0 else '#ef444420'};color:{'#10b981' if score > 0 else '#ef4444'};font-weight:600">score {score:+.2f}</span>
    </div>
    <div class="muted" style="font-family:'JetBrains Mono', monospace; font-size:12px; text-align:right;">
      {html.escape(name or '')}
    </div>
  </header>
  <div class="contract">
    <span class="muted" style="font-size:11px; font-family:'JetBrains Mono', monospace;">{underlying_note}</span>
  </div>
  {trade_block}
  <div class="exit-block" style="border-left-color:#94a3b8;">
    <h4>Why this side</h4>
    <div style="display:flex;flex-wrap:wrap;gap:5px;font-size:11px;">{factor_chip_row}</div>
  </div>
  <div class="grid">
    <div><span class="lab">5d</span><span class="val">{_fmt_pct(row.get('ret_5d')) if row.get('ret_5d') is not None else '&mdash;'}</span></div>
    <div><span class="lab">20d</span><span class="val">{_fmt_pct(row.get('ret_20d')) if row.get('ret_20d') is not None else '&mdash;'}</span></div>
    <div><span class="lab">ATR14</span><span class="val">{_fmt_num(atr, 2) if atr is not None else '&mdash;'}</span></div>
    <div><span class="lab">HV20</span><span class="val">{_fmt_pct(row.get('hv20')) if row.get('hv20') is not None else '&mdash;'}</span></div>
    <div><span class="lab">52w pos</span><span class="val">{_fmt_num((row.get('range_pos') or 0)*100, 0)}%</span></div>
    <div><span class="lab">Stops</span><span class="val">{stop_mult:.1f}/{target_mult:.1f} ATR</span></div>
  </div>
</article>
"""


def _share_card(row: pd.Series) -> str:
    cls = row.get("classification") or "—"
    mcap = row.get("market_cap")
    mcap_str = _fmt_money(mcap)
    headline = (row.get("top_headline") or "").strip()
    earnings = row.get("days_to_earnings")
    earnings_html = ""
    if earnings is not None and not pd.isna(earnings) and 0 <= earnings <= 60:
        earnings_html = f'<span class="chip earn">📅 EPS in {int(earnings)}d</span>'
    headline_html = ""
    if headline:
        headline_html = f'<div class="headline">📰 {html.escape(headline[:90])}</div>'
    pred_html = ""
    pred_stk = row.get("pred_stock_return_pct")
    if pred_stk is not None and not pd.isna(pred_stk) and abs(pred_stk) > 0.002:
        color = "#10b981" if pred_stk > 0 else "#ef4444"
        pred_html = (f'<span class="chip" style="background:{color}20;color:{color};font-weight:600">'
                     f'pred {pred_stk*100:+.1f}%</span>')
    ev_pct = row.get("ev_pct")
    ev_html = ""
    if ev_pct is not None and not pd.isna(ev_pct) and abs(ev_pct) > 0.002:
        c = "#10b981" if ev_pct > 0 else "#ef4444"
        ev_html = f'<span class="chip" style="background:{c}20;color:{c}">EV {ev_pct*100:+.1f}%</span>'
    kelly_pct = row.get("kelly_pct") or 0
    sized_dollars = row.get("suggested_dollars") or 0
    kelly_html = ""
    if kelly_pct and not pd.isna(kelly_pct) and kelly_pct > 0:
        kelly_html = (f'<span class="chip" style="background:#3b82f620;color:#3b82f6">'
                      f'¼Kelly {kelly_pct*100:.1f}%</span>')
    # Exit triggers for shares
    stop_pct_v = row.get("stop_pct")
    target_pct_v = row.get("target_pct")
    exit_block = ""
    if stop_pct_v is not None and target_pct_v is not None and not pd.isna(stop_pct_v):
        exit_block = f"""
  <div class="exit-block">
    <h4>Exit triggers</h4>
    <div class="exit-row">
      <span class="exit-stop">🛑 Stop @ {stop_pct_v*100:+.0f}%</span>
      <span class="exit-target">🎯 Target @ {target_pct_v*100:+.0f}%</span>
    </div>
  </div>"""

    sizing_block = ""
    if kelly_pct and kelly_pct > 0 and sized_dollars > 0:
        sizing_block = f"""
  <div class="sizing-block">
    <h4>Position size <span class="muted">(Kelly)</span></h4>
    <div class="sizing-row">
      <span><strong>${sized_dollars:,.0f}</strong></span>
      <span class="muted">{kelly_pct*100:.1f}% of bankroll</span>
    </div>
  </div>"""

    return f"""
<article class="card" data-ticker="{html.escape(row["ticker"]).upper()}" data-side="shares" data-conf="{_safe_int(row.get("confidence"))}" data-pred="{(pred_stk or 0)*100:.2f}" data-ev="{(ev_pct or 0)*100:.2f}" data-kelly="{(kelly_pct or 0)*100:.2f}">
  <header class="card-head">
    <div class="ticker-block">
      <span class="ticker">{html.escape(row["ticker"])}</span>
      {_badge("LONG SHARES", "#3b82f6")}
      {earnings_html}
      {pred_html}
      {ev_html}
      {kelly_html}
    </div>
    {_confidence_bar(_safe_int(row.get("confidence")))}
  </header>
  <div class="contract">
    <span class="contract-line">{html.escape(cls.upper())} · mcap {mcap_str}</span>
    <span class="muted">share score {row['share_score']:+.2f}</span>
  </div>
  <div class="grid">
    <div><span class="lab">Δ Sent</span><span class="val">{_fmt_num(row.get('sentiment_delta'),2)}</span></div>
    <div><span class="lab">Mentions</span><span class="val">{_safe_int(row.get('mentions'))}</span></div>
    <div><span class="lab">Fund</span><span class="val">{_fmt_num(row.get('fund_score'),2)}</span></div>
    <div><span class="lab">Insider</span><span class="val">{_fmt_num(row.get('insider_score'),2)}</span></div>
    <div><span class="lab">News 24h</span><span class="val">{_safe_int(row.get('n_24h'))}</span></div>
    <div><span class="lab">Velocity</span><span class="val">{_safe_int(row.get('velocity')):+d}</span></div>
  </div>
  {headline_html}
  {sizing_block}
  {exit_block}
  <div class="reason">
    <h4>Why</h4>
    <p>{html.escape(row.get("reasoning",""))}</p>
  </div>
  <div class="risks">
    <h4>Risks</h4>
    <p>{html.escape(row.get("risks",""))}</p>
  </div>
</article>
"""


# -------- Macro / stats banner ----------------------------------------
def _macro_banner(macro: Dict[str, Any]) -> str:
    regime = macro.get("regime", "neutral")
    tilt = macro.get("macro_tilt", 0.0)
    color = {"risk_on": "#10b981", "risk_off": "#ef4444"}.get(regime, "#94a3b8")
    vix = macro.get("vix")
    slope = macro.get("yield_curve_slope")
    spy3m = macro.get("spy_3m_return")
    cpi_yoy = macro.get("cpi_yoy")
    unrate = macro.get("unrate")
    hy_spread = macro.get("hy_spread")
    fed_funds = macro.get("fed_funds")
    initial_claims = macro.get("initial_claims")
    t10y3m = macro.get("t10y3m")

    # Second row only renders if FRED data is available
    fred_row = ""
    if any(v is not None for v in (cpi_yoy, unrate, hy_spread, fed_funds, t10y3m)):
        cpi_color = "#ef4444" if (cpi_yoy or 0) > 0.04 else "#10b981" if (cpi_yoy or 0) < 0.025 else "#94a3b8"
        hy_color = "#ef4444" if (hy_spread or 0) > 5 else "#10b981" if (hy_spread or 0) < 3 else "#94a3b8"
        curve_color = "#ef4444" if (t10y3m or 0) < 0 else "#10b981"
        fred_row = f"""
  <div class="macro-grid" style="margin-top:10px;">
    <div><span class="lab">CPI YoY</span><span class="val" style="color:{cpi_color}">{_fmt_pct(cpi_yoy) if cpi_yoy is not None else '—'}</span></div>
    <div><span class="lab">Unemp</span><span class="val">{_fmt_num(unrate, 1) if unrate is not None else '—'}%</span></div>
    <div><span class="lab">Fed Funds</span><span class="val">{_fmt_num(fed_funds, 2) if fed_funds is not None else '—'}%</span></div>
    <div><span class="lab">HY spread</span><span class="val" style="color:{hy_color}">{_fmt_num(hy_spread, 2) if hy_spread is not None else '—'}%</span></div>
    <div><span class="lab">10Y-3M</span><span class="val" style="color:{curve_color}">{_fmt_num(t10y3m, 2) if t10y3m is not None else '—'}%</span></div>
  </div>"""

    return f"""
<section class="macro" style="border-left-color:{color}">
  <div class="macro-head">
    <span class="regime-dot" style="background:{color}"></span>
    <h2>Macro: <strong>{regime.replace('_',' ').upper()}</strong></h2>
    <span class="muted">tilt {tilt:+.2f}</span>
  </div>
  <div class="macro-grid">
    <div><span class="lab">VIX</span><span class="val">{_fmt_num(vix, 1) if vix else '—'}</span></div>
    <div><span class="lab">10Y</span><span class="val">{_fmt_num(macro.get('yield_10y'), 2) if macro.get('yield_10y') else '—'}%</span></div>
    <div><span class="lab">3M</span><span class="val">{_fmt_num(macro.get('yield_3m'), 2) if macro.get('yield_3m') else '—'}%</span></div>
    <div><span class="lab">10Y-3M</span><span class="val">{_fmt_num(slope, 2) if slope is not None else '—'}%</span></div>
    <div><span class="lab">SPY 3m</span><span class="val">{_fmt_pct(spy3m) if spy3m is not None else '—'}</span></div>
  </div>{fred_row}
</section>
"""


def _stats_panel(elapsed: float, universe_size: int, n_calls: int, n_puts: int,
                 n_shares: int, n_news: int, n_earnings: int,
                 trending_count: int) -> str:
    return f"""
<section class="stats-panel">
  <div class="stat"><span class="stat-val">{elapsed:.1f}s</span><span class="stat-lab">runtime</span></div>
  <div class="stat"><span class="stat-val">{universe_size}</span><span class="stat-lab">universe</span></div>
  <div class="stat"><span class="stat-val">{n_calls}</span><span class="stat-lab">calls</span></div>
  <div class="stat"><span class="stat-val">{n_puts}</span><span class="stat-lab">puts</span></div>
  <div class="stat"><span class="stat-val">{n_shares}</span><span class="stat-lab">shares</span></div>
  <div class="stat"><span class="stat-val">{n_news}</span><span class="stat-lab">news rows</span></div>
  <div class="stat"><span class="stat-val">{n_earnings}</span><span class="stat-lab">earnings</span></div>
  <div class="stat"><span class="stat-val">{trending_count}</span><span class="stat-lab">WSB trending</span></div>
</section>
"""


# -------- Heatmaps & panels -------------------------------------------
def _news_flow_panel(news_df: pd.DataFrame, top_n: int = 10) -> str:
    if news_df is None or news_df.empty:
        return ""
    df = news_df.copy()
    # Rank by velocity × |news_delta| + raw count
    df["news_rank"] = df["news_velocity"].abs() + df["news_delta"].abs() * 5 + df["n_24h"] * 0.3
    top = df.sort_values("news_rank", ascending=False).head(top_n)
    rows = []
    for _, r in top.iterrows():
        if not (r.get("n_24h") or 0):
            continue
        sent = r.get("news_delta") or 0
        sent_color = "#10b981" if sent > 0.05 else "#ef4444" if sent < -0.05 else "#94a3b8"
        rows.append(f"""
<div class="news-row">
  <div class="news-tk"><strong>{html.escape(r['ticker'])}</strong></div>
  <div class="news-counts">
    <span class="chip">{int(r['n_24h'])} / 24h</span>
    <span class="chip">{int(r['n_7d'])} / 7d</span>
    <span class="chip" style="background:{sent_color}20;color:{sent_color}">Δ {sent:+.2f}</span>
  </div>
  <div class="news-headline">{html.escape((r.get('top_headline') or '')[:110])}</div>
</div>""")
    if not rows:
        return ""
    return f"""
<section class="panel">
  <h3>📰 News Flow <span class="muted">(top by velocity × Δsentiment)</span></h3>
  <div class="news-list">{''.join(rows)}</div>
</section>
"""


def _earnings_calendar(earnings_df: pd.DataFrame, days: int = 14) -> str:
    """Earnings calendar — collapsible (default closed) to save vertical space."""
    if earnings_df is None or earnings_df.empty:
        return ""
    df = earnings_df.copy()
    df = df[df["days_to_earnings"].notna() & (df["days_to_earnings"] >= 0) & (df["days_to_earnings"] <= days)]
    if df.empty:
        return ""
    df = df.sort_values("days_to_earnings")
    rows = []
    for _, r in df.iterrows():
        sup = r.get("last_eps_surprise_pct")
        sup_color = "#10b981" if (sup or 0) > 0.02 else "#ef4444" if (sup or 0) < -0.02 else "#94a3b8"
        sup_str = f"{sup*100:+.1f}%" if sup is not None else "—"
        rows.append(f"""
<div class="earn-row">
  <div class="earn-tk"><strong>{html.escape(r['ticker'])}</strong></div>
  <div class="earn-date">{html.escape(r.get('next_earnings_date') or '—')}</div>
  <div class="earn-dte"><span class="chip">in {int(r['days_to_earnings'])}d</span></div>
  <div class="earn-sup" style="color:{sup_color}">last surprise {sup_str}</div>
</div>""")
    n = len(df)
    return f"""
<details class="collapsible-panel">
  <summary>
    <span class="cp-arrow">&#9656;</span>
    <span class="cp-title">&#128197; Earnings Calendar</span>
    <span class="cp-count">{n} ticker{'s' if n != 1 else ''} &middot; next {days}d</span>
    <span class="cp-hint muted">click to expand</span>
  </summary>
  <div class="cp-body">
    <div class="earn-list">{''.join(rows)}</div>
  </div>
</details>
"""


def _insider_heatmap(insider_df: pd.DataFrame, n_each: int = 8) -> str:
    if insider_df is None or insider_df.empty:
        return ""
    df = insider_df.copy()
    if "insider_score" not in df.columns:
        return ""
    df = df[df["insider_score"].abs() > 0.1].copy()
    if df.empty:
        return ""
    buyers = df.sort_values("insider_score", ascending=False).head(n_each)
    sellers = df.sort_values("insider_score").head(n_each)

    def _row(r, color):
        val = max(r.get("buys_value", 0) or 0, r.get("sells_value", 0) or 0)
        return f"""
<div class="ins-row">
  <div class="ins-tk"><strong>{html.escape(r['ticker'])}</strong></div>
  <div class="ins-score" style="color:{color}">{r['insider_score']:+.2f}</div>
  <div class="ins-counts"><span class="chip">{_safe_int(r.get('n_buys'))}P / {_safe_int(r.get('n_sells'))}S</span></div>
  <div class="ins-val muted">{_fmt_money(val)}</div>
</div>"""
    buyers_html = "".join(_row(r, "#10b981") for _, r in buyers.iterrows()) or "<p class='muted'>No notable buys</p>"
    sellers_html = "".join(_row(r, "#ef4444") for _, r in sellers.iterrows()) or "<p class='muted'>No notable sells</p>"
    return f"""
<section class="panel">
  <h3>🕴 Insider Activity <span class="muted">(SEC EDGAR, last 90d)</span></h3>
  <div class="two-col">
    <div>
      <h4 class="sub">Top net buyers</h4>
      <div class="ins-list">{buyers_html}</div>
    </div>
    <div>
      <h4 class="sub">Top net sellers</h4>
      <div class="ins-list">{sellers_html}</div>
    </div>
  </div>
</section>
"""


def _wsb_panel(trending: List[str], sentiment_df: pd.DataFrame,
               trending_meta: List = None) -> str:
    """Render the WSB trending tile grid.

    Pulls mention counts from `trending_meta` if provided (WSB engine output),
    otherwise falls back to the sentiment_df (which only counts the past 48h).
    """
    if not trending:
        return ""
    rows = []
    sent_lookup = {}
    if sentiment_df is not None and not sentiment_df.empty and "ticker" in sentiment_df.columns:
        try:
            sent_lookup = sentiment_df.set_index("ticker").to_dict(orient="index")
        except Exception:
            sent_lookup = {}
    meta_lookup = {m["ticker"]: m for m in (trending_meta or [])}

    for t in trending[:25]:
        meta = meta_lookup.get(t, {})
        # Prefer WSB engine mention count (it's the actual source of trending)
        mentions = int(meta.get("mentions", 0))
        ups = int(meta.get("ups", 0))
        # Δsentiment from the sentiment engine
        srow = sent_lookup.get(t, {})
        delta = float(srow.get("sentiment_delta", 0) or 0)
        sent_color = "#10b981" if delta > 0.05 else "#ef4444" if delta < -0.05 else "#94a3b8"
        ups_str = f" · {ups:,} ups" if ups > 0 else ""
        rows.append(f"""
<div class="wsb-tile">
  <span class="wsb-ticker">{html.escape(t)}</span>
  <span class="chip" style="background:{sent_color}20;color:{sent_color}">Δ {delta:+.2f}</span>
  <span class="muted">{mentions} mention{'s' if mentions != 1 else ''}{ups_str}</span>
</div>""")
    return f"""
<section class="panel">
  <h3>🔥 WSB Trending <span class="muted">({len(trending)} discovered live, added to universe)</span></h3>
  <div class="wsb-grid">{''.join(rows)}</div>
</section>
"""


# -------- Tables -------------------------------------------------------
def _options_table(df: pd.DataFrame) -> str:
    if df is None or df.empty:
        return "<p class='muted'>No long-option ideas pass filters.</p>"
    rows = []
    for i, r in df.iterrows():
        side_color = "#10b981" if r["side"] == "call" else "#f87171"
        side_label = "C" if r["side"] == "call" else "P"
        rows.append(f"""
<tr>
  <td>{i+1}</td>
  <td><strong>{html.escape(r['ticker'])}</strong></td>
  <td>{html.escape(r['contract'])}</td>
  <td><span class="dot" style="background:{side_color}"></span>{side_label}</td>
  <td>{int(r['confidence'])}</td>
  <td>{_fmt_pct(r['iv_market'])}</td>
  <td>{_fmt_pct(r['fair_vol'])}</td>
  <td>{_fmt_pct(r['vol_premium'])}</td>
  <td>{int(r['dte'])}d</td>
  <td>${_fmt_num(r['mid'])}</td>
</tr>""")
    return f"""
<table class="ranked">
  <thead><tr>
    <th>#</th><th>Ticker</th><th>Contract</th><th>Side</th>
    <th>Conf</th><th>IV</th><th>HV30</th><th>Vol prem</th><th>DTE</th><th>Mid</th>
  </tr></thead>
  <tbody>{''.join(rows)}</tbody>
</table>
"""


def _shares_table(df: pd.DataFrame) -> str:
    if df is None or df.empty:
        return "<p class='muted'>No share ideas above the score threshold.</p>"
    rows = []
    for i, r in df.iterrows():
        cls = r.get("classification") or "—"
        mcap = r.get("market_cap")
        mcap_str = _fmt_money(mcap)
        rows.append(f"""
<tr>
  <td>{i+1}</td>
  <td><strong>{html.escape(r['ticker'])}</strong></td>
  <td>{html.escape(cls)}</td>
  <td>{mcap_str}</td>
  <td>{int(r['confidence'])}</td>
  <td>{r['share_score']:+.2f}</td>
  <td>{_fmt_num(r.get('sentiment_delta'), 2)}</td>
  <td>{_safe_int(r.get('mentions'))}</td>
  <td>{_fmt_num(r.get('fund_score'), 1)}</td>
  <td>{_fmt_num(r.get('insider_score'), 1)}</td>
</tr>""")
    return f"""
<table class="ranked">
  <thead><tr>
    <th>#</th><th>Ticker</th><th>Class</th><th>Mcap</th>
    <th>Conf</th><th>Score</th><th>ΔSent</th><th>Mentions</th><th>Fund</th><th>Insider</th>
  </tr></thead>
  <tbody>{''.join(rows)}</tbody>
</table>
"""


_CSS = """
:root {
  --bg: #0a0a0b; --panel: #111114; --panel-2: #161619;
  --border: #1f1f24; --text: #e5e5e7; --muted: #8b8b93; --accent: #c8c8d0;
}
* { box-sizing: border-box; }
body {
  margin: 0; background: var(--bg); color: var(--text);
  font-family: -apple-system, "Inter", "Helvetica Neue", Arial, sans-serif;
  font-size: 14px; line-height: 1.55;
}
.wrap { max-width: 1480px; margin: 0 auto; padding: 32px 28px 96px; }
header.top {
  display: flex; align-items: baseline; justify-content: space-between;
  border-bottom: 1px solid var(--border); padding-bottom: 16px; margin-bottom: 24px;
}
header.top h1 { font-size: 28px; letter-spacing: -0.5px; font-weight: 600; margin: 0; }
header.top .meta { color: var(--muted); font-size: 11px; font-family: "JetBrains Mono", monospace; }
.muted { color: var(--muted); }

section.macro {
  background: var(--panel); border: 1px solid var(--border);
  border-left: 4px solid #94a3b8; border-radius: 8px;
  padding: 16px 20px; margin-bottom: 16px;
}
.macro-head { display: flex; align-items: center; gap: 12px; margin-bottom: 10px; }
.macro-head h2 { margin: 0; font-size: 15px; font-weight: 500; }
.regime-dot { width: 10px; height: 10px; border-radius: 50%; display: inline-block; }
.macro-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px; }
.macro-grid .lab, .grid .lab {
  display: block; font-size: 10px; text-transform: uppercase;
  color: var(--muted); letter-spacing: 0.5px; margin-bottom: 2px;
}
.macro-grid .val, .grid .val {
  font-size: 15px; font-family: "JetBrains Mono", monospace;
}

.stats-panel {
  display: grid; grid-template-columns: repeat(8, 1fr); gap: 12px;
  background: var(--panel); border: 1px solid var(--border); border-radius: 8px;
  padding: 12px 16px; margin-bottom: 24px;
}
.stat { display: flex; flex-direction: column; align-items: center; }
.stat-val { font-size: 18px; font-weight: 600; font-family: "JetBrains Mono", monospace; }
.stat-lab { font-size: 9px; text-transform: uppercase; color: var(--muted); letter-spacing: 0.5px; margin-top: 2px; }

h2.section-title {
  font-size: 11px; text-transform: uppercase; letter-spacing: 1.5px;
  color: var(--muted); margin: 32px 0 14px; display: flex; align-items: center; gap: 12px;
}
h2.section-title .count {
  background: var(--panel); padding: 2px 8px; border-radius: 4px;
  font-family: "JetBrains Mono", monospace; color: var(--accent);
}

.cards {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(360px, 1fr));
  gap: 14px;
}
.card {
  background: var(--panel); border: 1px solid var(--border);
  border-radius: 10px; padding: 16px 18px;
}
.card-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; gap: 8px; flex-wrap: wrap; }
.ticker-block { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.ticker { font-size: 18px; font-weight: 700; letter-spacing: -0.5px; }
.badge {
  font-size: 10px; padding: 2px 8px; border-radius: 4px;
  color: #fff; font-weight: 600; letter-spacing: 0.5px;
}
.chip {
  font-size: 10px; padding: 2px 7px; border-radius: 4px;
  background: #1f1f24; color: var(--accent);
}
.chip.earn { background: #422006; color: #fbbf24; }
.contract { margin-bottom: 10px; }
.contract-line {
  display: block; font-family: "JetBrains Mono", monospace;
  font-size: 13px; color: var(--accent);
}
.contract .muted { font-size: 11px; }
.grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px 16px;
  padding: 10px 0; border-top: 1px solid var(--border); border-bottom: 1px solid var(--border);
}
.grid .val { font-size: 13px; }
.headline {
  margin-top: 10px; padding: 8px 10px; background: var(--panel-2);
  border-radius: 4px; font-size: 12px; color: var(--accent);
  border-left: 2px solid #fbbf24;
}
.reason, .risks { margin-top: 10px; }
.reason h4, .risks h4 {
  font-size: 10px; text-transform: uppercase; letter-spacing: 1.5px;
  color: var(--muted); margin: 0 0 4px;
}
.reason p, .risks p { margin: 0; font-size: 12.5px; }
.risks p { color: #fca5a5; }
.conf-bar {
  position: relative; width: 80px; height: 22px;
  background: #1f1f24; border-radius: 4px; overflow: hidden;
}
.conf-fill { height: 100%; transition: width .2s; }
.conf-text {
  position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
  font-size: 11px; font-weight: 600; font-family: "JetBrains Mono", monospace;
  text-shadow: 0 1px 2px rgba(0,0,0,0.6);
}

/* Side panels */
.panel-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin: 16px 0; }
.panel {
  background: var(--panel); border: 1px solid var(--border);
  border-radius: 8px; padding: 16px 18px; margin-bottom: 16px;
}
.panel h3 {
  margin: 0 0 12px; font-size: 13px; font-weight: 600;
  letter-spacing: 0.3px;
}
.panel h3 .muted { font-weight: 400; font-size: 11px; }
.two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
.sub {
  font-size: 10px; text-transform: uppercase; letter-spacing: 1px;
  color: var(--muted); margin: 0 0 8px;
}

.news-list, .earn-list, .ins-list {
  display: flex; flex-direction: column; gap: 6px;
}
.news-row, .earn-row, .ins-row {
  display: grid; align-items: center; gap: 10px;
  padding: 8px 10px; background: var(--panel-2); border-radius: 6px;
  font-size: 12px;
}
.news-row { grid-template-columns: 60px 1fr 2fr; }
.earn-row { grid-template-columns: 70px 100px 80px 1fr; }
.ins-row  { grid-template-columns: 60px 60px 70px 1fr; }
.news-counts { display: flex; gap: 4px; }
.news-headline { color: var(--accent); font-size: 12px; line-height: 1.4; }
.earn-date { font-family: "JetBrains Mono", monospace; }
.earn-sup, .ins-val { font-family: "JetBrains Mono", monospace; font-size: 11px; }
.ins-score { font-family: "JetBrains Mono", monospace; font-weight: 600; }

.wsb-grid {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 8px;
}
.wsb-tile {
  display: flex; align-items: center; gap: 8px;
  padding: 8px 10px; background: var(--panel-2); border-radius: 6px;
  font-size: 12px;
}
.wsb-ticker { font-weight: 600; }

/* Performance panel */
.perf-headline {
  display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px;
  background: var(--panel-2); border-radius: 6px; padding: 14px 18px;
}
.perf-headline .lab {
  display:block; font-size: 10px; text-transform: uppercase;
  color: var(--muted); letter-spacing: 0.5px; margin-bottom: 4px;
}
.perf-headline .val { font-size: 20px; font-family: "JetBrains Mono", monospace; font-weight: 600; }
.perf-row {
  display: grid; grid-template-columns: 100px 60px 80px 1fr; gap: 10px;
  padding: 8px 10px; background: var(--panel-2); border-radius: 6px;
  font-size: 12px; align-items: center; margin-bottom: 4px;
}
.perf-bucket { font-weight: 600; }
.perf-n, .perf-win, .perf-pnl { font-family: "JetBrains Mono", monospace; }

/* Interactive controls */
.controls {
  position: sticky; top: 0; z-index: 100;
  background: var(--bg); padding: 12px 0; margin-bottom: 16px;
  border-bottom: 1px solid var(--border);
  display: flex; flex-wrap: wrap; gap: 12px; align-items: center;
}
.controls input, .controls select {
  background: var(--panel-2); color: var(--text);
  border: 1px solid var(--border); border-radius: 6px;
  padding: 8px 12px; font-size: 13px; font-family: inherit;
}
.controls input { min-width: 220px; }
.controls input:focus, .controls select:focus {
  outline: none; border-color: #3b82f6;
}
.controls .filter-chip {
  cursor: pointer; padding: 6px 12px; border-radius: 16px;
  background: var(--panel-2); border: 1px solid var(--border);
  font-size: 12px; user-select: none;
}
.controls .filter-chip.active {
  background: #3b82f6; border-color: #3b82f6; color: #fff;
}
.controls .filter-chip:hover { border-color: #3b82f6; }
.controls .stats {
  margin-left: auto; font-size: 12px; color: var(--muted);
  font-family: "JetBrains Mono", monospace;
}

/* Sizing block on cards */
.sizing-block {
  margin-top: 10px; padding: 10px 12px;
  background: var(--panel-2); border-radius: 6px;
  border-left: 3px solid #3b82f6;
}
.sizing-block.warn { border-left-color: #f59e0b; }
.sizing-block h4 {
  font-size: 10px; text-transform: uppercase; letter-spacing: 1px;
  color: var(--muted); margin: 0 0 6px;
}
.sizing-block h4 .muted { font-size: 9px; text-transform: none; letter-spacing: 0; }
.sizing-block .sizing-row {
  display: flex; gap: 12px; align-items: baseline; flex-wrap: wrap;
  font-family: "JetBrains Mono", monospace; font-size: 13px;
}
.sizing-block strong { color: var(--accent); font-size: 16px; }
.sizing-block p { margin: 4px 0 0; font-size: 12px; color: #fbbf24; }

/* Exit triggers */
.exit-block {
  margin-top: 10px; padding: 10px 12px;
  background: var(--panel-2); border-radius: 6px;
  border-left: 3px solid #94a3b8;
}
.exit-block h4 {
  font-size: 10px; text-transform: uppercase; letter-spacing: 1px;
  color: var(--muted); margin: 0 0 6px;
}
.exit-row { display: flex; gap: 16px; flex-wrap: wrap; font-size: 12px; }
.exit-stop { color: #fca5a5; }
.exit-target { color: #86efac; }

/* Congress panel */
.cong-row {
  display: grid; grid-template-columns: 60px 60px 110px 1fr; gap: 10px;
  padding: 8px 10px; background: var(--panel-2); border-radius: 6px;
  font-size: 12px; align-items: center; margin-bottom: 4px;
}
.cong-tk { font-weight: 600; }
.cong-score { font-family: "JetBrains Mono", monospace; font-weight: 600; }
.cong-buyer { font-size: 11px; }
.cong-list { display: flex; flex-direction: column; gap: 4px; }

.card.hidden { display: none; }
.empty-msg {
  padding: 32px 16px; text-align: center; color: var(--muted);
  font-style: italic;
}

table.ranked {
  width: 100%; border-collapse: collapse; font-size: 12px;
  font-family: "JetBrains Mono", monospace;
}
table.ranked th, table.ranked td {
  padding: 8px 10px; border-bottom: 1px solid var(--border); text-align: left;
}
table.ranked th {
  color: var(--muted); font-weight: 500; font-size: 10px;
  text-transform: uppercase; letter-spacing: 0.5px;
}
table.ranked tbody tr:hover { background: var(--panel-2); }
.dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; }

.appendix {
  margin-top: 32px; padding: 20px;
  background: var(--panel); border: 1px solid var(--border); border-radius: 8px;
}
.appendix h3 { margin-top: 0; font-size: 13px; }
.appendix code {
  font-family: "JetBrains Mono", monospace; background: #1f1f24;
  padding: 1px 6px; border-radius: 3px; font-size: 12px;
}
.weights { display: grid; grid-template-columns: repeat(2, 1fr); gap: 4px 24px; }
.weights .row { display: flex; justify-content: space-between; padding: 4px 0; border-bottom: 1px dotted #2a2a30; }
.demo-banner {
  background: #422006; border: 1px solid #92400e; color: #fbbf24;
  padding: 10px 16px; border-radius: 6px; margin-bottom: 16px;
  font-size: 12px;
}
.tv-export {
  background: var(--panel); border: 1px solid var(--border); border-radius: 8px;
  padding: 16px 20px; margin: 16px 0; font-family: "JetBrains Mono", monospace;
  font-size: 12px;
}
.tv-export h3 { margin: 0 0 8px; font-family: "Inter"; font-size: 14px; }
.tv-export pre {
  margin: 0; padding: 12px; background: var(--panel-2); border-radius: 4px;
  white-space: pre-wrap; max-height: 200px; overflow-y: auto;
}

/* ---- Collapsible panel (v16) ---- */
details.collapsible-panel {
  background: var(--panel); border: 1px solid var(--border);
  border-radius: 8px; padding: 0; margin-bottom: 16px;
  overflow: hidden;
}
details.collapsible-panel > summary {
  cursor: pointer; user-select: none; list-style: none;
  display: flex; align-items: center; gap: 12px;
  padding: 14px 18px; font-size: 13px; font-weight: 600;
  border-bottom: 1px solid transparent;
  transition: background-color .15s;
}
details.collapsible-panel > summary:hover { background: var(--panel-2); }
details.collapsible-panel > summary::-webkit-details-marker { display: none; }
details.collapsible-panel > summary .cp-arrow {
  display: inline-block; transition: transform .2s;
  font-size: 16px; color: var(--accent); width: 14px;
}
details.collapsible-panel[open] > summary .cp-arrow { transform: rotate(90deg); }
details.collapsible-panel[open] > summary { border-bottom-color: var(--border); }
details.collapsible-panel > summary .cp-title { flex: 0 0 auto; }
details.collapsible-panel > summary .cp-count {
  background: var(--panel-2); padding: 2px 8px; border-radius: 4px;
  font-family: "JetBrains Mono", monospace; font-size: 11px; color: var(--accent);
  font-weight: 500;
}
details.collapsible-panel > summary .cp-hint {
  margin-left: auto; font-size: 10px; font-weight: 400; text-transform: uppercase;
  letter-spacing: 1px;
}
details.collapsible-panel[open] > summary .cp-hint::after { content: " — click to collapse"; }
details.collapsible-panel[open] > summary .cp-hint::before { content: ""; }
details.collapsible-panel > summary .cp-hint::before { content: ""; }
details.collapsible-panel:not([open]) > summary .cp-hint::after { content: ""; }
.cp-body { padding: 14px 18px; }

/* ---- Futures recommended-trade block ---- */
.trade-block {
  margin-top: 10px; padding: 12px 14px;
  background: var(--panel-2); border-radius: 6px;
  border-left: 4px solid #10b981;
}
.trade-block.warn { border-left-color: #f59e0b; opacity: 0.85; }
.trade-block h4 {
  font-size: 10px; text-transform: uppercase; letter-spacing: 1px;
  color: var(--muted); margin: 0 0 8px;
  display: flex; gap: 8px; align-items: center;
}
.trade-block .trade-headline {
  font-family: "JetBrains Mono", monospace; font-size: 15px;
  font-weight: 600; margin-bottom: 6px;
}
.trade-block .trade-headline strong { font-size: 17px; letter-spacing: -0.3px; }
.trade-block .trade-row {
  display: flex; gap: 14px; flex-wrap: wrap; font-size: 12px;
  font-family: "JetBrains Mono", monospace;
  padding: 4px 0;
}
.trade-block .trade-stop { color: #fca5a5; }
.trade-block .trade-target { color: #86efac; }
.trade-block .trade-foot {
  margin-top: 6px; font-size: 11px; font-family: "JetBrains Mono", monospace;
  color: var(--muted);
}
.trade-block .trade-foot strong { color: var(--accent); }
.futures-card { border-left: 2px solid #3b82f6; }

/* ---- Self-learning / backtest / forward-test panels (v16) ---- */
.sl-table { width: 100%; border-collapse: collapse; font-size: 12px;
            font-family: "JetBrains Mono", monospace; }
.sl-table th, .sl-table td { padding: 7px 10px; border-bottom: 1px solid var(--border); text-align: left; }
.sl-table th { color: var(--muted); font-weight: 500; font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
.sl-table td.bucket-name { font-weight: 600; color: var(--accent); }
.sl-mode-priors { color: #94a3b8; }
.sl-mode-ic_bootstrap { color: #fbbf24; }
.sl-mode-lasso_refit { color: #10b981; font-weight: 600; }
.sl-decay { color: #f87171; font-size: 10px; }
.sl-factor-chip { padding: 2px 7px; background: var(--panel-2); border-radius: 4px; margin-right: 4px; font-size: 10px; }
.equity-spark { display: inline-block; vertical-align: middle; }
"""


def _performance_panel(forward_summary) -> str:
    """Render the Performance Tracking panel from a forward-test result."""
    if not forward_summary or forward_summary.get("signals", pd.DataFrame()).empty:
        return f"""
<section class="panel">
  <h3>📊 Performance Tracking <span class="muted">(auto-updated each run)</span></h3>
  <p class="muted">No tracked signals yet. Run <code>python run.py</code> daily and a track record will accumulate here automatically. Each ranked trade is logged to <code>logs/signals_*.parquet</code> and re-priced on every subsequent run.</p>
</section>
"""
    ovr = forward_summary["overall"]
    by_conf = forward_summary.get("by_confidence", pd.DataFrame())
    by_type = forward_summary.get("by_type", pd.DataFrame())
    win_color = "#10b981" if ovr["win_rate"] >= 0.55 else "#f59e0b" if ovr["win_rate"] >= 0.45 else "#ef4444"
    pnl_color = "#10b981" if ovr["avg_pnl_pct"] > 0 else "#ef4444"

    conf_rows = ""
    if not by_conf.empty:
        for _, r in by_conf.iterrows():
            wc = "#10b981" if r["win_rate"] >= 0.55 else "#f59e0b" if r["win_rate"] >= 0.45 else "#ef4444"
            pc = "#10b981" if r["avg_pnl"] > 0 else "#ef4444"
            conf_rows += f"""
<div class="perf-row">
  <div class="perf-bucket">{html.escape(r['bucket'])}</div>
  <div class="perf-n">n={int(r['n'])}</div>
  <div class="perf-win" style="color:{wc}">win {r['win_rate']*100:.0f}%</div>
  <div class="perf-pnl" style="color:{pc}">{r['avg_pnl']*100:+.2f}%</div>
</div>"""

    type_rows = ""
    if not by_type.empty:
        for _, r in by_type.iterrows():
            wc = "#10b981" if r["win_rate"] >= 0.55 else "#f59e0b" if r["win_rate"] >= 0.45 else "#ef4444"
            pc = "#10b981" if r["avg_pnl"] > 0 else "#ef4444"
            type_rows += f"""
<div class="perf-row">
  <div class="perf-bucket">{html.escape(r['type']).upper()}</div>
  <div class="perf-n">n={int(r['n'])}</div>
  <div class="perf-win" style="color:{wc}">win {r['win_rate']*100:.0f}%</div>
  <div class="perf-pnl" style="color:{pc}">{r['avg_pnl']*100:+.2f}%</div>
</div>"""

    return f"""
<section class="panel">
  <h3>📊 Performance Tracking <span class="muted">({int(ovr['n_signals'])} signals from prior runs)</span></h3>
  <div class="perf-headline">
    <div><span class="lab">Win rate</span><span class="val" style="color:{win_color}">{ovr['win_rate']*100:.1f}%</span></div>
    <div><span class="lab">Avg P&amp;L</span><span class="val" style="color:{pnl_color}">{ovr['avg_pnl_pct']*100:+.2f}%</span></div>
    <div><span class="lab">Median</span><span class="val">{ovr['median_pnl_pct']*100:+.2f}%</span></div>
    <div><span class="lab">Best</span><span class="val" style="color:#10b981">{ovr['best']*100:+.1f}%</span></div>
    <div><span class="lab">Worst</span><span class="val" style="color:#ef4444">{ovr['worst']*100:+.1f}%</span></div>
  </div>
  <div class="two-col" style="margin-top:14px;">
    <div>
      <h4 class="sub">By confidence</h4>
      {conf_rows or '<p class="muted">No bucketed data yet.</p>'}
    </div>
    <div>
      <h4 class="sub">By signal type</h4>
      {type_rows or '<p class="muted">No bucketed data yet.</p>'}
    </div>
  </div>
</section>
"""


def _analyst_panel(analyst: pd.DataFrame, top_n: int = 10) -> str:
    """Top tickers by analyst sentiment + momentum (Finnhub data)."""
    if analyst is None or analyst.empty:
        return ""
    df = analyst.copy()
    df = df[df["analyst_total"] >= 5]   # need at least 5 analysts to be meaningful
    if df.empty:
        return ""
    # Top buys ranked by score
    bulls = df[df["analyst_score"] > 0.5].sort_values("analyst_score", ascending=False).head(top_n)
    # Recent upgrades (positive momentum)
    upgrades = df[df["analyst_momentum"] > 0].sort_values("analyst_momentum", ascending=False).head(top_n)
    bears = df[df["analyst_score"] < -0.3].sort_values("analyst_score").head(min(top_n // 2, 5))

    def _row(r, color):
        sb = _safe_int(r.get("analyst_strong_buy"))
        b = _safe_int(r.get("analyst_buy"))
        h = _safe_int(r.get("analyst_hold"))
        s = _safe_int(r.get("analyst_sell")) + _safe_int(r.get("analyst_strong_sell"))
        mom = _safe_int(r.get("analyst_momentum"))
        return f"""
<div class="cong-row">
  <div class="cong-tk"><strong>{html.escape(r['ticker'])}</strong></div>
  <div class="cong-score" style="color:{color}">{r['analyst_score']:+.1f}</div>
  <div class="cong-counts"><span class="chip">{sb}SB / {b}B / {h}H / {s}S</span></div>
  <div class="cong-buyer muted">{'+' if mom > 0 else ''}{mom} this month</div>
</div>"""

    bulls_html = "".join(_row(r, "#10b981") for _, r in bulls.iterrows()) or "<p class='muted'>No strong buys</p>"
    bears_html = "".join(_row(r, "#ef4444") for _, r in bears.iterrows()) or "<p class='muted'>No clear bears</p>"
    return f"""
<section class="panel">
  <h3>📊 Analyst Recommendations <span class="muted">(Finnhub, latest month consensus)</span></h3>
  <div class="two-col">
    <div>
      <h4 class="sub">🚀 Top buy ratings</h4>
      <div class="cong-list">{bulls_html}</div>
    </div>
    <div>
      <h4 class="sub">⚠ Top sell ratings</h4>
      <div class="cong-list">{bears_html}</div>
    </div>
  </div>
</section>
"""


def _social_panel(social: pd.DataFrame, top_n: int = 10) -> str:
    """StockTwits top sentiment + Trump's recent posts touching tickers."""
    if social is None or social.empty:
        return ""
    df = social.copy()
    df = df[df["social_score"].abs() > 0.05].sort_values("social_score", ascending=False)
    if df.empty:
        return ""

    # Top StockTwits-driven tickers (left column)
    st_top = df[df["stocktwits_n"] > 0].head(top_n)
    st_rows = ""
    for _, r in st_top.iterrows():
        n_bull = _safe_int(r.get("stocktwits_n_bull"))
        n_bear = _safe_int(r.get("stocktwits_n_bear"))
        st_avg = float(r.get("stocktwits_avg_sent") or 0)
        sent_color = "#10b981" if st_avg > 0.05 else "#ef4444" if st_avg < -0.05 else "#94a3b8"
        st_rows += f"""
<div class="cong-row">
  <div class="cong-tk"><strong>{html.escape(r['ticker'])}</strong></div>
  <div class="cong-score" style="color:{sent_color}">{st_avg:+.2f}</div>
  <div class="cong-counts"><span class="chip">{_safe_int(r.get('stocktwits_n'))} msgs</span></div>
  <div class="cong-buyer muted">{n_bull}🐂 / {n_bear}🐻</div>
</div>"""

    # Trump posts touching tickers (right column)
    tr_df = df[df["trump_n"] > 0].sort_values("trump_avg_sent", ascending=False).head(top_n)
    tr_rows = ""
    for _, r in tr_df.iterrows():
        tr_avg = float(r.get("trump_avg_sent") or 0)
        sent_color = "#10b981" if tr_avg > 0.05 else "#ef4444" if tr_avg < -0.05 else "#94a3b8"
        excerpt = (r.get("trump_excerpt") or "")[:70]
        tr_rows += f"""
<div class="cong-row">
  <div class="cong-tk"><strong>{html.escape(r['ticker'])}</strong></div>
  <div class="cong-score" style="color:{sent_color}">{tr_avg:+.2f}</div>
  <div class="cong-counts"><span class="chip">{_safe_int(r.get('trump_n'))}× mentioned</span></div>
  <div class="cong-buyer muted">"{html.escape(excerpt)}"</div>
</div>"""
    if not tr_rows:
        tr_rows = "<p class='muted'>No Trump posts mentioning tickers in last 14 days</p>"
    if not st_rows:
        st_rows = "<p class='muted'>No StockTwits messages captured</p>"

    return f"""
<section class="panel">
  <h3>🌐 Social Signal <span class="muted">(StockTwits + Trump Truth Social)</span></h3>
  <div class="two-col">
    <div>
      <h4 class="sub">📈 StockTwits sentiment leaders</h4>
      <div class="cong-list">{st_rows}</div>
    </div>
    <div>
      <h4 class="sub">🇺🇸 Trump posts touching tickers</h4>
      <div class="cong-list">{tr_rows}</div>
    </div>
  </div>
</section>
"""


def _congress_panel(congress: pd.DataFrame, top_n: int = 12) -> str:
    """Top tickers by Congressional net buying."""
    if congress is None or congress.empty:
        return ""
    df = congress.copy()
    df = df[df["congress_score"].abs() > 0.1].sort_values("congress_score", ascending=False)
    if df.empty:
        return ""
    buyers = df.head(top_n)
    sellers = df.sort_values("congress_score").head(min(top_n // 2, 5))

    def _row(r, color):
        n_sens = _safe_int(r.get("congress_n_sens"))
        n_reps = _safe_int(r.get("congress_n_reps"))
        buyer = (r.get("congress_top_buyer") or "")[:38]
        members = []
        if n_sens > 0: members.append(f"{n_sens} 🏛 sen")
        if n_reps > 0: members.append(f"{n_reps} 🏢 rep")
        members_str = ", ".join(members) if members else ""
        return f"""
<div class="cong-row">
  <div class="cong-tk"><strong>{html.escape(r['ticker'])}</strong></div>
  <div class="cong-score" style="color:{color}">{r['congress_score']:+.2f}</div>
  <div class="cong-counts"><span class="chip">{members_str}</span></div>
  <div class="cong-buyer muted">{html.escape(buyer)}</div>
</div>"""
    buyers_html = "".join(_row(r, "#10b981") for _, r in buyers.iterrows()) or "<p class='muted'>No notable buys</p>"
    sellers_html = "".join(_row(r, "#ef4444") for _, r in sellers.iterrows()) or "<p class='muted'>No notable sells</p>"
    return f"""
<section class="panel">
  <h3>🏛 Congressional Activity <span class="muted">(STOCK Act disclosures, last 90d)</span></h3>
  <div class="two-col">
    <div>
      <h4 class="sub">Top net Congressional buyers</h4>
      <div class="cong-list">{buyers_html}</div>
    </div>
    <div>
      <h4 class="sub">Top net Congressional sellers</h4>
      <div class="cong-list">{sellers_html}</div>
    </div>
  </div>
</section>
"""


def _self_learning_panel() -> str:
    """Show per-bucket weight status: source, samples, top factors, decay flags."""
    try:
        from engines import learning
        statuses = learning.list_bucket_status()
    except Exception as e:
        log.debug("self-learning panel skipped: %s", e)
        return ""
    if not statuses:
        return ""

    rows = []
    for s in statuses:
        bucket = s["bucket"]
        mode = s["source"] or "priors"
        n = s["n_samples"]
        fitted = s.get("fitted_at") or "—"
        if isinstance(fitted, str) and "T" in fitted:
            fitted = fitted.split("T")[0]
        top = s.get("top_factors", [])
        top_html = " ".join(
            f'<span class="sl-factor-chip">{html.escape(str(fn))} {w:+.2f}</span>'
            for fn, w in top
        ) or '<span class="muted">none</span>'
        decay = s.get("decay_flags") or []
        decay_html = (f'<span class="sl-decay">decay: {", ".join(decay)}</span>'
                      if decay else "<span class='muted'>—</span>")
        rows.append(f"""
<tr>
  <td class="bucket-name">{html.escape(bucket)}</td>
  <td><span class="sl-mode-{mode}">{html.escape(mode)}</span></td>
  <td>{n}</td>
  <td>{html.escape(str(fitted))}</td>
  <td>{top_html}</td>
  <td>{decay_html}</td>
</tr>""")

    return f"""
<details class="collapsible-panel" open>
  <summary>
    <span class="cp-arrow">&#9656;</span>
    <span class="cp-title">&#129504; Self-Learning Status</span>
    <span class="cp-count">{len(statuses)} buckets</span>
    <span class="cp-hint muted">click to collapse</span>
  </summary>
  <div class="cp-body">
    <p class="muted" style="font-size:11px; margin:0 0 10px;">Per-bucket weight learners. Each bucket starts on hand-crafted priors, switches to <strong>IC bootstrap</strong> at 20+ realized trades, then full <strong>Lasso refit</strong> at 50+. Decay flag = factor IC dropped &gt;50% since last fit.</p>
    <table class="sl-table">
      <thead><tr><th>Bucket</th><th>Mode</th><th># samples</th><th>Last refit</th><th>Top factors</th><th>Decay flags</th></tr></thead>
      <tbody>{''.join(rows)}</tbody>
    </table>
  </div>
</details>
"""


def _backtest_panel() -> str:
    """Walk-forward backtest panel — per bucket OOS stats + equity sparkline."""
    try:
        from engines import backtest_engine
        summary = backtest_engine.load_backtest_summary()
    except Exception as e:
        log.debug("backtest panel skipped: %s", e)
        return ""
    if not summary or "buckets" not in summary:
        return f"""
<details class="collapsible-panel">
  <summary>
    <span class="cp-arrow">&#9656;</span>
    <span class="cp-title">&#128202; Backtest</span>
    <span class="cp-count">no data yet</span>
    <span class="cp-hint muted">click to expand</span>
  </summary>
  <div class="cp-body">
    <p class="muted">No backtest run yet. After signals accumulate, the backtest auto-runs each cycle (or on demand via <code>python run.py --backtest</code>).</p>
  </div>
</details>"""

    rows = []
    n_active = 0
    for bucket, stats in summary["buckets"].items():
        if stats.get("status") != "ok":
            rows.append(f'<tr><td class="bucket-name">{html.escape(bucket)}</td>'
                        f'<td colspan="7" class="muted">{html.escape(stats.get("status",""))} (n={stats.get("n",0)})</td></tr>')
            continue
        n_active += 1
        wr = stats.get("oos_win_rate")
        wr_color = "#10b981" if wr and wr >= 0.55 else "#f59e0b" if wr and wr >= 0.45 else "#ef4444"
        pf = stats.get("oos_profit_factor")
        pnl = stats.get("oos_pnl") or 0
        pnl_color = "#10b981" if pnl > 0 else "#ef4444"
        sharpe = stats.get("oos_sharpe")
        dd = stats.get("oos_max_dd") or 0
        n_oos = stats.get("n_oos", 0)
        eq = stats.get("equity_curve") or []
        spark = _equity_sparkline(eq, color=("#10b981" if pnl > 0 else "#ef4444"))
        top_factor_html = " ".join(
            f'<span class="sl-factor-chip">{html.escape(f["factor"])} {f["weight"]:+.2f}</span>'
            for f in stats.get("top_factors", [])[:3]
        )
        rows.append(f"""
<tr>
  <td class="bucket-name">{html.escape(bucket)}</td>
  <td>{html.escape(stats.get('fit_mode',''))}</td>
  <td>{n_oos}</td>
  <td style="color:{wr_color}">{(wr*100 if wr else 0):.0f}%</td>
  <td style="color:{pnl_color}">${pnl:,.0f}</td>
  <td>{(pf or 0):.2f}</td>
  <td>{(sharpe or 0):.2f}</td>
  <td>${dd:,.0f}</td>
  <td>{spark}</td>
  <td>{top_factor_html}</td>
</tr>""")

    asof = summary.get("asof", "")
    if asof and "T" in asof:
        asof_date = asof.split("T")[0]
    else:
        asof_date = asof
    return f"""
<details class="collapsible-panel" open>
  <summary>
    <span class="cp-arrow">&#9656;</span>
    <span class="cp-title">&#128202; Backtest <span class="muted" style="font-weight:400;">walk-forward 80/20</span></span>
    <span class="cp-count">{n_active} buckets active &middot; asof {html.escape(asof_date)}</span>
    <span class="cp-hint muted">click to collapse</span>
  </summary>
  <div class="cp-body">
    <p class="muted" style="font-size:11px; margin:0 0 10px;">Out-of-sample stats per bucket. Train on first 80%, evaluate on last 20%. Profit Factor = gross wins / gross losses. Sharpe annualized.</p>
    <table class="sl-table">
      <thead><tr>
        <th>Bucket</th><th>Fit</th><th>n OOS</th><th>Win%</th><th>OOS PnL</th>
        <th>PF</th><th>Sharpe</th><th>Max DD</th><th>Equity</th><th>Top factors</th>
      </tr></thead>
      <tbody>{''.join(rows)}</tbody>
    </table>
  </div>
</details>
"""


def _equity_sparkline(curve: List[float], width: int = 80, height: int = 24,
                       color: str = "#10b981") -> str:
    """Inline SVG equity sparkline."""
    if not curve or len(curve) < 2:
        return '<span class="muted">—</span>'
    lo, hi = min(curve), max(curve)
    span = hi - lo if hi > lo else 1
    points = []
    for i, v in enumerate(curve):
        x = (i / (len(curve) - 1)) * width
        y = height - ((v - lo) / span) * height
        points.append(f"{x:.1f},{y:.1f}")
    pts_str = " ".join(points)
    return (f'<svg class="equity-spark" width="{width}" height="{height}" viewBox="0 0 {width} {height}" '
            f'xmlns="http://www.w3.org/2000/svg">'
            f'<polyline points="{pts_str}" fill="none" stroke="{color}" stroke-width="1.5"/>'
            f'</svg>')


def _forward_test_panel() -> str:
    """Rolling 30/60/90d hit rate per bucket."""
    DATA = ROOT / "data"
    p = DATA / "forward_test_status.parquet"
    if not p.exists():
        return f"""
<details class="collapsible-panel">
  <summary>
    <span class="cp-arrow">&#9656;</span>
    <span class="cp-title">&#128300; Forward Test</span>
    <span class="cp-count">no data yet</span>
    <span class="cp-hint muted">click to expand</span>
  </summary>
  <div class="cp-body">
    <p class="muted">No forward-test outcomes yet. Once signals age past 7 days, replay logic computes hit rate + realized PnL automatically each cycle.</p>
  </div>
</details>"""
    try:
        df = pd.read_parquet(p)
    except Exception:
        return ""
    if df is None or df.empty:
        return ""
    rows = []
    n_with_data = 0
    for _, r in df.iterrows():
        bucket = r["bucket"]
        n30 = int(r.get("n_30d") or 0)
        n60 = int(r.get("n_60d") or 0)
        n90 = int(r.get("n_90d") or 0)
        if n30 + n60 + n90 == 0:
            rows.append(f'<tr><td class="bucket-name">{html.escape(bucket)}</td>'
                        f'<td colspan="7" class="muted">no outcomes yet</td></tr>')
            continue
        n_with_data += 1
        wr30 = r.get("win_rate_30d"); wr60 = r.get("win_rate_60d"); wr90 = r.get("win_rate_90d")
        pnl30 = r.get("pnl_30d") or 0; pnl60 = r.get("pnl_60d") or 0; pnl90 = r.get("pnl_90d") or 0
        def _c(wr): return "#10b981" if wr and wr >= 0.55 else "#f59e0b" if wr and wr >= 0.45 else "#ef4444"
        def _pc(p): return "#10b981" if (p or 0) > 0 else "#ef4444"
        rows.append(f"""
<tr>
  <td class="bucket-name">{html.escape(bucket)}</td>
  <td>{n30}</td>
  <td style="color:{_c(wr30)}">{(wr30*100 if wr30 else 0):.0f}%</td>
  <td style="color:{_pc(pnl30)}">${pnl30:,.0f}</td>
  <td>{n60}</td>
  <td style="color:{_c(wr60)}">{(wr60*100 if wr60 else 0):.0f}%</td>
  <td style="color:{_pc(pnl60)}">${pnl60:,.0f}</td>
  <td>{n90}</td>
  <td style="color:{_c(wr90)}">{(wr90*100 if wr90 else 0):.0f}%</td>
  <td style="color:{_pc(pnl90)}">${pnl90:,.0f}</td>
</tr>""")

    return f"""
<details class="collapsible-panel">
  <summary>
    <span class="cp-arrow">&#9656;</span>
    <span class="cp-title">&#128300; Forward Test <span class="muted" style="font-weight:400;">rolling hit rate &amp; PnL</span></span>
    <span class="cp-count">{n_with_data} buckets with outcomes</span>
    <span class="cp-hint muted">click to expand</span>
  </summary>
  <div class="cp-body">
    <p class="muted" style="font-size:11px; margin:0 0 10px;">Realized outcomes from logged signals, replayed against historical price (target/stop/time-stop). Drives the per-bucket Lasso refit each cycle.</p>
    <table class="sl-table">
      <thead><tr>
        <th>Bucket</th>
        <th>n 30d</th><th>Win 30d</th><th>PnL 30d</th>
        <th>n 60d</th><th>Win 60d</th><th>PnL 60d</th>
        <th>n 90d</th><th>Win 90d</th><th>PnL 90d</th>
      </tr></thead>
      <tbody>{''.join(rows)}</tbody>
    </table>
  </div>
</details>
"""


def render(calls: pd.DataFrame, puts: pd.DataFrame, shares: pd.DataFrame,
           ranked_options: pd.DataFrame, ranked_shares: pd.DataFrame,
           macro: Dict[str, Any], asof: datetime, demo: bool = False,
           news: pd.DataFrame = None, earnings: pd.DataFrame = None,
           insider: pd.DataFrame = None, trending: List[str] = None,
           elapsed: float = 0.0, universe_size: int = 0,
           value_plays: pd.DataFrame = None, futures_plays: pd.DataFrame = None,
           forward_summary=None, bankroll: float = 10000,
           aggressive: bool = False, congress: pd.DataFrame = None,
           sentiment: pd.DataFrame = None,
           trending_meta: List = None,
           social: pd.DataFrame = None,
           analyst: pd.DataFrame = None) -> Path:
    """Build a self-contained HTML cockpit. Returns the path."""
    asof_str = asof.strftime("%Y-%m-%d %H:%M UTC")
    trending = trending or []

    cards_calls = "\n".join(_option_card(r) for _, r in calls.iterrows()) if calls is not None and not calls.empty else "<p class='muted'>No long-call ideas pass filters this run.</p>"
    cards_puts = "\n".join(_option_card(r) for _, r in puts.iterrows()) if puts is not None and not puts.empty else "<p class='muted'>No long-put ideas pass filters this run.</p>"
    cards_shares = "\n".join(_share_card(r) for _, r in shares.iterrows()) if shares is not None and not shares.empty else "<p class='muted'>No small-cap share ideas above the score threshold.</p>"
    cards_value = "\n".join(_value_card(r) for _, r in value_plays.iterrows()) if value_plays is not None and not value_plays.empty else "<p class='muted'>No standout value plays above threshold.</p>"
    cards_futures = "\n".join(_futures_card(r, bankroll=bankroll) for _, r in futures_plays.iterrows()) if futures_plays is not None and not futures_plays.empty else "<p class='muted'>No futures with directional bias and macro alignment.</p>"
    table_opts = _options_table(pd.concat([calls, puts], ignore_index=True) if (calls is not None and puts is not None) else None)
    table_sh = _shares_table(shares)

    # New panels
    news_panel = _news_flow_panel(news) if news is not None else ""
    earn_panel = _earnings_calendar(earnings) if earnings is not None else ""
    insider_panel = _insider_heatmap(insider) if insider is not None else ""
    # WSB panel — pulls mention counts from trending_meta (WSB engine) and Δsentiment from sentiment df
    wsb_panel = _wsb_panel(trending, sentiment, trending_meta=trending_meta)

    n_calls = len(calls) if calls is not None else 0
    n_puts = len(puts) if puts is not None else 0
    n_shares = len(shares) if shares is not None else 0
    n_news_rows = len(news) if news is not None else 0
    n_earn_rows = len(earnings[earnings["days_to_earnings"].notna()]) if earnings is not None and not earnings.empty and "days_to_earnings" in earnings.columns else 0

    stats = _stats_panel(elapsed, universe_size, n_calls, n_puts, n_shares,
                         n_news_rows, n_earn_rows, len(trending))

    from config import SIGNAL_WEIGHTS
    weight_rows = "".join(
        f'<div class="row"><span>{k}</span><span>{v:.2f}</span></div>'
        for k, v in SIGNAL_WEIGHTS.items()
    )

    from fusion.rank import to_tv_watchlist
    tv_text = to_tv_watchlist(calls, puts, shares)

    demo_banner = ('<div class="demo-banner"><strong>DEMO/HYBRID MODE</strong> — '
                    'options + sentiment data is synthetic. Insider data is LIVE if SEC EDGAR is reachable. '
                    'Run without <code>--demo</code> on a residential IP for full live mode.</div>') if demo else ""

    html_doc = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Optedge — Quant Cockpit</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>{_CSS}</style>
</head>
<body>
<div class="wrap">
  <header class="top">
    <div>
      <h1>Optedge — Quant Cockpit</h1>
      <div class="muted">Long-only buy list · multi-factor fusion · 9 signals</div>
    </div>
    <div class="meta">
      asof {asof_str}
    </div>
  </header>

  {demo_banner}
  {_macro_banner(macro)}
  {stats}

  <div class="controls" id="controls">
    <input type="text" id="search-box" placeholder="🔍 Search ticker (e.g., NVDA, TSLA)…" autocomplete="off">
    <select id="sort-by">
      <option value="default">Sort: rank</option>
      <option value="confidence">Sort: confidence ↓</option>
      <option value="pred">Sort: predicted return ↓</option>
      <option value="ev">Sort: EV % ↓</option>
      <option value="kelly">Sort: Kelly % ↓</option>
      <option value="ticker">Sort: ticker A-Z</option>
    </select>
    <span class="filter-chip active" data-filter="all">all</span>
    <span class="filter-chip" data-filter="call">calls only</span>
    <span class="filter-chip" data-filter="put">puts only</span>
    <span class="filter-chip" data-filter="shares">shares only</span>
    <span class="filter-chip" data-filter="high-conf">conf ≥ 70</span>
    <span class="filter-chip" data-filter="positive-ev">EV &gt; 0</span>
    <span class="filter-chip" data-filter="positive-kelly">Kelly &gt; 0</span>
    <span class="stats" id="card-counter">— cards visible</span>
  </div>
  <div class="muted" style="font-size:11px; margin-bottom:16px; font-family:'JetBrains Mono', monospace;">
    Bankroll: <strong>${bankroll:,.0f}</strong> ·
    {'<strong style="color:#f87171">AGGRESSIVE MODE</strong> · ½ Kelly · Cap 10% per option / 15% per share' if aggressive else '¼ Kelly · Cap 5% per option / 8% per share'}
  </div>


  <div class="panel-row">
    <div>{news_panel}</div>
    <div>{earn_panel}</div>
  </div>

  {_performance_panel(forward_summary)}
  {_analyst_panel(analyst)}
  {_congress_panel(congress)}
  {_social_panel(social)}
  {insider_panel}
  {wsb_panel}

  <h2 class="section-title">Long Calls <span class="count">{n_calls}</span></h2>
  <div class="cards">{cards_calls}</div>

  <h2 class="section-title">Long Puts <span class="count">{n_puts}</span></h2>
  <div class="cards">{cards_puts}</div>

  <h2 class="section-title">Long Shares <span class="count">{n_shares}</span> <span class="muted">(small caps where options aren't liquid enough)</span></h2>
  <div class="cards">{cards_shares}</div>

  <h2 class="section-title">💎 Value Plays <span class="count">{len(value_plays) if value_plays is not None else 0}</span> <span class="muted">(cheap & quality — Magic Formula + Graham composite)</span></h2>
  <div class="cards">{cards_value}</div>

  <h2 class="section-title">📈 Futures Plays <span class="count">{len(futures_plays) if futures_plays is not None else 0}</span> <span class="muted">(multi-factor self-learning · micro contracts · ATR stops)</span></h2>
  <div class="cards">{cards_futures}</div>

  {_self_learning_panel()}
  {_backtest_panel()}
  {_forward_test_panel()}

  <h2 class="section-title">Ranked option snapshot</h2>
  {table_opts}

  <h2 class="section-title">Ranked share snapshot</h2>
  {table_sh}

  <section class="tv-export">
    <h3>TradingView watchlist</h3>
    <p class="muted" style="font-family:Inter">Save the text below to <code>optedge_watchlist.txt</code> and import via the Watchlist panel → ⋯ menu → Import file.</p>
    <pre>{html.escape(tv_text)}</pre>
  </section>

  <section class="appendix">
    <h3>Methodology</h3>
    <p class="muted">EV = P(win) × predicted gain + P(loss) × max loss. P(win) approximated by |delta| for options. Kelly fraction f* = (b·p − q)/b, then × 0.25 (quarter Kelly per research consensus). Hard caps: 5% bankroll per option trade, 8% per share trade. Negative Kelly = the predictor disagrees with the rank → marked as "skip".</p>
    <p class="muted">Long-only by design. Each contract is z-scored cross-sectionally on nine signals (mispricing, IV-rank, skew, sentiment Δ, fundamentals, insider, macro, news Δ, earnings catalyst) and combined via the prior weights below. Action-aligned scoring: positive secondary signals boost calls + dampen puts, and vice-versa. Max one idea per ticker for diversity.</p>
    <div class="weights">{weight_rows}</div>
    <h3 style="margin-top:20px;">Filters</h3>
    <p class="muted">Options must clear: open interest ≥ 100, daily volume ≥ 25, bid-ask spread ≤ 15%, mid ≥ $0.10, 14 ≤ DTE ≤ 60. Shares must score ≥ 0.6 z-units bullish and not already have an option idea.</p>
    <h3 style="margin-top:20px;">Data sources (all free)</h3>
    <p class="muted">yfinance (options, prices, fundamentals, VIX/yields). Reddit JSON (sentiment + WSB trending). SEC EDGAR Form 4 (insider). Google News RSS (news flow). FRED optional for richer macro. None of this is investment advice.</p>
  </section>
</div>
__JS_PLACEHOLDER__
</body>
</html>
"""
    # Insert JS as a plain string so JS template literals (${...}) don't collide
    # with Python f-string syntax.
    js = _INTERACTIVE_JS
    html_doc = html_doc.replace("__JS_PLACEHOLDER__", js)

    out_path = ROOT / "data" / f"dashboard_{asof.strftime('%Y%m%d_%H%M%S')}.html"
    out_path.write_text(html_doc, encoding="utf-8")
    return out_path


_INTERACTIVE_JS = r"""<script>
(() => {
  const allCards = Array.from(document.querySelectorAll('article.card'));
  const searchBox = document.getElementById('search-box');
  const sortBy = document.getElementById('sort-by');
  const chips = Array.from(document.querySelectorAll('.filter-chip'));
  const counter = document.getElementById('card-counter');
  let activeFilter = 'all';

  function num(card, attr, def) {
    if (def === undefined) def = 0;
    const v = parseFloat(card.dataset[attr]);
    return isFinite(v) ? v : def;
  }

  function applyFilters() {
    const q = (searchBox.value || '').trim().toUpperCase();
    let visible = 0;
    allCards.forEach(card => {
      const ticker = (card.dataset.ticker || '').toUpperCase();
      const side = card.dataset.side;
      const conf = num(card, 'conf');
      const ev = num(card, 'ev');
      const kelly = num(card, 'kelly');

      let show = true;
      if (q && !ticker.includes(q)) show = false;
      if (activeFilter === 'call' && side !== 'call') show = false;
      if (activeFilter === 'put' && side !== 'put') show = false;
      if (activeFilter === 'shares' && side !== 'shares') show = false;
      if (activeFilter === 'high-conf' && conf < 70) show = false;
      if (activeFilter === 'positive-ev' && ev <= 0) show = false;
      if (activeFilter === 'positive-kelly' && kelly <= 0) show = false;

      card.classList.toggle('hidden', !show);
      if (show) visible++;
    });
    counter.textContent = visible + ' card' + (visible !== 1 ? 's' : '') + ' visible';
  }

  function applySort() {
    const mode = sortBy.value;
    if (mode === 'default') return;
    const sectionGroups = new Map();
    allCards.forEach(card => {
      const parent = card.parentElement;
      if (!sectionGroups.has(parent)) sectionGroups.set(parent, []);
      sectionGroups.get(parent).push(card);
    });
    sectionGroups.forEach((cards, parent) => {
      cards.sort((a, b) => {
        if (mode === 'ticker') {
          return (a.dataset.ticker || '').localeCompare(b.dataset.ticker || '');
        }
        const key = mode === 'pred' ? 'pred' :
                    mode === 'ev' ? 'ev' :
                    mode === 'kelly' ? 'kelly' : 'conf';
        return num(b, key) - num(a, key);
      });
      cards.forEach(c => parent.appendChild(c));
    });
  }

  searchBox.addEventListener('input', applyFilters);
  sortBy.addEventListener('change', () => { applySort(); applyFilters(); });
  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      activeFilter = chip.dataset.filter;
      applyFilters();
    });
  });

  applyFilters();
})();
</script>"""
